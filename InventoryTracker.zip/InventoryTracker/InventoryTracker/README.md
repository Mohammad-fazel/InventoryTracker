# Inventory Management System for Android

A comprehensive inventory management system designed for Android mobile devices. Built with Python, Kivy, and KivyMD, this application helps businesses track raw materials, finished products, and visualize inventory data through interactive charts.

## Key Features

- **Material Management**: Add, edit, and track raw materials with quantity, units, and cost information
- **Product Management**: Create products that automatically consume materials, track stock levels
- **Automated Material Consumption**: Automatically deducts materials from inventory when creating products
- **Visualization**: Generate charts for inventory levels, material distributions, and more
- **History Tracking**: Keep records of all inventory changes for review and analysis

## Screenshots

(Screenshots would appear here when generated on an Android device)

## System Architecture

- **main.py**: Main entry point and screen manager
- **database.py**: SQLite database management
- **inventory_manager.py**: Core inventory management logic
- **models.py**: Data model classes
- **chart_manager.py**: Chart generation using matplotlib
- **screens/**: Directory containing different application screens
- **widgets/**: Custom widgets for the application

## Application Screens

1. **Home Screen**: Dashboard with key statistics and recent activity
2. **Materials Screen**: Manage raw materials inventory
3. **Products Screen**: Manage finished products and production
4. **Charts Screen**: Visualizations and inventory analytics

## Building the APK

To convert this project into an installable Android APK, follow these steps on a Linux system:

1. Install Buildozer and its dependencies:
```bash
pip install buildozer
sudo apt-get install -y python3-pip build-essential git python3 python3-dev ffmpeg libsdl2-dev libsdl2-image-dev libsdl2-mixer-dev libsdl2-ttf-dev libportmidi-dev libswscale-dev libavformat-dev libavcodec-dev zlib1g-dev
sudo apt-get install -y libgstreamer1.0-dev gstreamer1.0-plugins-base gstreamer1.0-plugins-good
sudo apt-get install -y build-essential libsqlite3-dev sqlite3 bzip2 libbz2-dev zlib1g-dev libssl-dev openssl libgdbm-dev libgdbm-compat-dev liblzma-dev libreadline-dev libncursesw5-dev libffi-dev uuid-dev
sudo apt-get install -y libffi-dev
```

2. Run the Buildozer command from the project root:
```bash
buildozer android debug
```

3. The APK will be generated in the `bin/` directory.

## Important Notes

- First builds with Buildozer will take a long time as it downloads Android SDK and NDK
- The application requires Kivy 2.1.0 and KivyMD 1.1.1 for optimal compatibility
- This application is designed for mobile devices with touch interfaces
- Windows users should use WSL (Windows Subsystem for Linux) for building APKs

## Development Environment

- Python 3.10+
- Kivy 2.1.0
- KivyMD 1.1.1
- SQLite
- Matplotlib for chart generation
- Buildozer for APK generation

## License

This project is open-source and can be freely used and modified.