from database import DatabaseManager
from models import Material, Product, ProductMaterial, DashboardStats, InventoryHistoryRecord

class InventoryManager:
    """
    High-level inventory management logic that uses the database manager.
    """
    def __init__(self):
        """Initialize with a database manager."""
        self.db_manager = DatabaseManager()
    
    # ---- Material Operations ----
    
    def add_material(self, name, quantity, unit, min_quantity=0, cost_per_unit=0):
        """
        Add a new material to the inventory.
        
        Args:
            name (str): Name of the material
            quantity (float): Initial quantity
            unit (str): Unit of measurement (e.g., kg, pcs)
            min_quantity (float): Minimum quantity threshold for alerts
            cost_per_unit (float): Cost per unit of the material
            
        Returns:
            Material: Newly created material object
        """
        material_id = self.db_manager.add_material(
            name, quantity, unit, min_quantity, cost_per_unit
        )
        
        if material_id:
            return self.get_material(material_id)
        return None
    
    def update_material(self, material_id, **kwargs):
        """
        Update an existing material.
        
        Args:
            material_id (int): ID of the material to update
            **kwargs: Fields to update (name, quantity, unit, min_quantity, cost_per_unit)
            
        Returns:
            Material: Updated material object or None if update failed
        """
        success = self.db_manager.update_material(material_id, **kwargs)
        
        if success:
            return self.get_material(material_id)
        return None
    
    def delete_material(self, material_id):
        """
        Delete a material from the inventory.
        
        Args:
            material_id (int): ID of the material to delete
            
        Returns:
            bool: True if deletion was successful
        """
        return self.db_manager.delete_material(material_id)
    
    def get_material(self, material_id):
        """
        Get a single material by ID.
        
        Args:
            material_id (int): ID of the material to retrieve
            
        Returns:
            Material: Material object or None if not found
        """
        material_dict = self.db_manager.get_material(material_id)
        
        if material_dict:
            return Material.from_dict(material_dict)
        return None
    
    def get_all_materials(self):
        """
        Get all materials in the inventory.
        
        Returns:
            list: List of Material objects
        """
        materials_dict = self.db_manager.get_all_materials()
        return [Material.from_dict(m) for m in materials_dict]
    
    def get_low_stock_materials(self):
        """
        Get materials that are below their minimum quantity threshold.
        
        Returns:
            list: List of low stock Material objects
        """
        materials_dict = self.db_manager.get_low_stock_materials()
        return [Material.from_dict(m) for m in materials_dict]
    
    # ---- Product Operations ----
    
    def add_product(self, name, price=0, materials_needed=None):
        """
        Add a new product to the inventory with its required materials.
        
        Args:
            name (str): Product name
            price (float): Selling price
            materials_needed (list): List of dictionaries with material_id, quantity_needed
            
        Returns:
            Product: Newly created product object
        """
        product_id = self.db_manager.add_product(name, price, materials_needed)
        
        if product_id:
            return self.get_product(product_id)
        return None
    
    def update_product(self, product_id, name=None, price=None):
        """
        Update product details (not quantity).
        
        Args:
            product_id (int): ID of the product to update
            name (str, optional): New product name
            price (float, optional): New selling price
            
        Returns:
            Product: Updated product object or None if update failed
        """
        success = self.db_manager.update_product(product_id, name, price)
        
        if success:
            return self.get_product(product_id)
        return None
    
    def update_product_materials(self, product_id, materials_needed):
        """
        Update the materials required for a product.
        
        Args:
            product_id (int): ID of the product
            materials_needed (list): List of dictionaries with material_id, quantity_needed
            
        Returns:
            Product: Updated product object or None if update failed
        """
        success = self.db_manager.update_product_materials(product_id, materials_needed)
        
        if success:
            return self.get_product(product_id)
        return None
    
    def delete_product(self, product_id):
        """
        Delete a product from the inventory.
        
        Args:
            product_id (int): ID of the product to delete
            
        Returns:
            bool: True if deletion was successful
        """
        return self.db_manager.delete_product(product_id)
    
    def get_product(self, product_id):
        """
        Get a single product by ID.
        
        Args:
            product_id (int): ID of the product to retrieve
            
        Returns:
            Product: Product object or None if not found
        """
        product_dict = self.db_manager.get_product(product_id)
        
        if product_dict:
            return Product.from_dict(product_dict)
        return None
    
    def get_all_products(self):
        """
        Get all products in the inventory.
        
        Returns:
            list: List of Product objects
        """
        products_dict = self.db_manager.get_all_products()
        return [Product.from_dict(p) for p in products_dict]
    
    def check_material_availability(self, product_id, quantity=1):
        """
        Check if enough materials are available to produce a quantity of products.
        
        Args:
            product_id (int): ID of the product to check
            quantity (int): Number of products to check for
            
        Returns:
            tuple: (bool, list) - Success status and list of materials with insufficient quantity
        """
        return self.db_manager.check_material_availability(product_id, quantity)
    
    def create_product_batch(self, product_id, quantity):
        """
        Create a batch of products, deducting required materials.
        
        Args:
            product_id (int): ID of the product to create
            quantity (int): Number of products to create
            
        Returns:
            Product: Updated product object or None if creation failed
        """
        success = self.db_manager.create_product_batch(product_id, quantity)
        
        if success:
            return self.get_product(product_id)
        return None
    
    def use_product(self, product_id, quantity):
        """
        Remove products from inventory (e.g., for sales).
        
        Args:
            product_id (int): ID of the product to use
            quantity (int): Number of products to remove
            
        Returns:
            Product: Updated product object or None if usage failed
        """
        success = self.db_manager.use_product(product_id, quantity)
        
        if success:
            return self.get_product(product_id)
        return None
    
    # ---- History and Reporting ----
    
    def get_inventory_history(self, item_type=None, item_id=None, days=30):
        """
        Get inventory history for reporting.
        
        Args:
            item_type (str, optional): Filter by 'material' or 'product'
            item_id (int, optional): Filter by specific item ID
            days (int): Number of days of history to retrieve
            
        Returns:
            list: List of InventoryHistoryRecord objects
        """
        history_dict = self.db_manager.get_inventory_history(item_type, item_id, days)
        return [InventoryHistoryRecord.from_dict(h) for h in history_dict]
    
    def get_inventory_levels_over_time(self, item_type, item_id, days=30):
        """
        Get inventory level history for a specific item.
        
        Args:
            item_type (str): 'material' or 'product'
            item_id (int): ID of the item
            days (int): Number of days of history to retrieve
            
        Returns:
            list: List of dictionaries with timestamp and quantity
        """
        return self.db_manager.get_inventory_levels_over_time(item_type, item_id, days)
    
    def get_dashboard_stats(self):
        """
        Get summary statistics for the dashboard.
        
        Returns:
            DashboardStats: Statistics including total materials, products, etc.
        """
        stats_dict = self.db_manager.get_dashboard_stats()
        return DashboardStats.from_dict(stats_dict)
