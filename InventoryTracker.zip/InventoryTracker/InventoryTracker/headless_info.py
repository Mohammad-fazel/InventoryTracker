"""
اطلاعات مهم در مورد مدیریت موجودی اندروید

این برنامه یک سیستم مدیریت موجودی تحت اندروید است که با استفاده از Kivy و KivyMD ساخته شده است.

## ویژگی‌های برنامه:
1. مدیریت مواد اولیه (Materials)
2. مدیریت محصولات نهایی (Products)
3. تولید نمودارهای آماری
4. ثبت تاریخچه تغییرات موجودی
5. محاسبه خودکار استفاده از مواد اولیه هنگام تولید محصول

## نمای کلی از معماری برنامه:
- `main.py`: نقطه ورود برنامه و مدیریت صفحات 
- `database.py`: مدیریت پایگاه داده SQLite
- `inventory_manager.py`: منطق اصلی مدیریت موجودی
- `models.py`: کلاس‌های مدل داده
- `chart_manager.py`: تولید نمودارها با استفاده از matplotlib
- `screens/`: پوشه حاوی صفحات مختلف برنامه
- `widgets/`: پوشه حاوی ویجت‌های سفارشی

## صفحات اصلی برنامه:
1. **صفحه اصلی (Home)**: نمایش آمار کلی و فعالیت‌های اخیر
2. **صفحه مواد اولیه (Materials)**: مدیریت مواد اولیه موجود در انبار
3. **صفحه محصولات (Products)**: مدیریت محصولات نهایی
4. **صفحه گزارش‌ها (Charts)**: نمودارها و گزارش‌های آماری

## ساخت نسخه APK:
برای تبدیل این برنامه به فایل APK قابل نصب روی دستگاه‌های اندروید، باید مراحل زیر را روی سیستم لینوکس انجام دهید:

1. نصب buildozer و وابستگی‌های آن:
```bash
pip install buildozer
sudo apt-get install -y python3-pip build-essential git python3 python3-dev ffmpeg libsdl2-dev libsdl2-image-dev libsdl2-mixer-dev libsdl2-ttf-dev libportmidi-dev libswscale-dev libavformat-dev libavcodec-dev zlib1g-dev
sudo apt-get install -y libgstreamer1.0-dev gstreamer1.0-plugins-base gstreamer1.0-plugins-good
sudo apt-get install -y build-essential libsqlite3-dev sqlite3 bzip2 libbz2-dev zlib1g-dev libssl-dev openssl libgdbm-dev libgdbm-compat-dev liblzma-dev libreadline-dev libncursesw5-dev libffi-dev uuid-dev libffi6
sudo apt-get install -y libffi-dev
```

2. اجرای دستور buildozer در مسیر اصلی پروژه:
```bash
buildozer android debug
```

3. فایل APK در پوشه `bin/` قرار خواهد گرفت.

## نکات مهم:
- این برنامه برای اجرا در محیط Replit به دلیل عدم پشتیبانی از رابط گرافیکی با مشکل مواجه می‌شود.
- ساخت APK نیاز به محیط لینوکس دارد.
- اولین اجرای دستور buildozer ممکن است زمان زیادی طول بکشد زیرا نیاز به دانلود SDK و NDK اندروید دارد.

"""