from kivy.lang import Builder
from kivymd.uix.screen import MDScreen
from kivymd.uix.button import MDFlatButton, MDIconButton
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.floatlayout import MDFloatLayout
from kivymd.uix.list import MDList, OneLineIconListItem, TwoLineIconListItem
from kivymd.uix.card import MDCard
from kivymd.uix.label import MDLabel
from kivymd.uix.gridlayout import MDGridLayout

from inventory_manager import InventoryManager

# Define the KV language string for the home screen
Builder.load_string('''
<HomeScreen>:
    name: "home"
    MDBoxLayout:
        orientation: "vertical"
        
        # App Bar
        MDTopAppBar:
            title: "Inventory Manager"
            right_action_items: [["refresh", lambda x: root.refresh_data()]]
            elevation: 4
        
        # Main Content
        MDScrollView:
            id: scroll_view
            MDBoxLayout:
                id: main_container
                orientation: "vertical"
                padding: dp(16)
                spacing: dp(16)
                size_hint_y: None
                height: self.minimum_height
                
                # Dashboard Cards Grid
                MDGridLayout:
                    id: dashboard_grid
                    cols: 2
                    spacing: dp(16)
                    size_hint_y: None
                    height: self.minimum_height
                
                # Recent Activity Card
                MDCard:
                    id: recent_activity_card
                    orientation: "vertical"
                    padding: dp(16)
                    size_hint_y: None
                    height: dp(320)
                    
                    MDLabel:
                        text: "Recent Activity"
                        font_style: "H6"
                        size_hint_y: None
                        height: dp(40)
                    
                    MDScrollView:
                        MDList:
                            id: recent_activity_list
                
                # Navigation Buttons
                MDBoxLayout:
                    orientation: "horizontal"
                    spacing: dp(16)
                    size_hint_y: None
                    height: dp(120)
                    padding: [0, dp(16), 0, dp(16)]
                    
                    MDCard:
                        orientation: "vertical"
                        padding: dp(8)
                        
                        MDIconButton:
                            icon: "factory"
                            pos_hint: {"center_x": .5}
                            icon_size: dp(36)
                            on_press: app.change_screen("materials")
                            
                        MDLabel:
                            text: "Materials"
                            halign: "center"
                    
                    MDCard:
                        orientation: "vertical"
                        padding: dp(8)
                        
                        MDIconButton:
                            icon: "package-variant-closed"
                            pos_hint: {"center_x": .5}
                            icon_size: dp(36)
                            on_press: app.change_screen("products")
                            
                        MDLabel:
                            text: "Products"
                            halign: "center"
                    
                    MDCard:
                        orientation: "vertical"
                        padding: dp(8)
                        
                        MDIconButton:
                            icon: "chart-line"
                            pos_hint: {"center_x": .5}
                            icon_size: dp(36)
                            on_press: app.change_screen("charts")
                            
                        MDLabel:
                            text: "Reports"
                            halign: "center"

<StatCard>:
    orientation: "vertical"
    padding: dp(16)
    size_hint_y: None
    height: dp(120)
    
    MDLabel:
        id: stat_label
        text: root.stat_title
        font_style: "Caption"
        size_hint_y: None
        height: dp(20)
    
    MDLabel:
        id: stat_value
        text: root.stat_value
        font_style: "H5"
        size_hint_y: None
        height: dp(50)
    
    MDLabel:
        id: stat_subtitle
        text: root.stat_subtitle
        theme_text_color: "Secondary"
        font_style: "Body2"
        size_hint_y: None
        height: dp(20)
''')

class StatCard(MDCard):
    """Card widget for displaying statistics on the dashboard."""
    def __init__(self, title="", value="", subtitle="", **kwargs):
        super().__init__(**kwargs)
        self.stat_title = title
        self.stat_value = value
        self.stat_subtitle = subtitle

class HomeScreen(MDScreen):
    """
    Home screen for the inventory management app.
    Displays dashboard statistics and recent activity.
    """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.inventory_manager = InventoryManager()
        self.stat_cards = {}
        
    def on_enter(self):
        """Called when the screen is displayed."""
        self.refresh_data()
        
    def refresh_data(self):
        """Refresh all dashboard data."""
        # Get statistics
        stats = self.inventory_manager.get_dashboard_stats()
        
        # Update or create stat cards
        self._create_stat_cards(stats)
        
        # Update recent activity
        self._update_recent_activity(stats.recent_activity)
    
    def _create_stat_cards(self, stats):
        """
        Create or update the statistic cards on the dashboard.
        
        Args:
            stats: DashboardStats object with current statistics
        """
        # Clear existing cards
        dashboard_grid = self.ids.dashboard_grid
        dashboard_grid.clear_widgets()
        
        # Create the cards
        cards = [
            StatCard(
                title="MATERIALS",
                value=str(stats.total_materials),
                subtitle=f"{stats.low_stock_materials} Low Stock"
            ),
            StatCard(
                title="PRODUCTS",
                value=str(stats.total_products),
                subtitle=f"{stats.out_of_stock_products} Out of Stock"
            ),
            StatCard(
                title="MATERIALS VALUE",
                value=f"${stats.materials_value:.2f}",
                subtitle="Total Value"
            ),
            StatCard(
                title="PRODUCTS VALUE",
                value=f"${stats.products_value:.2f}",
                subtitle="Total Value"
            )
        ]
        
        # Add cards to the grid
        for card in cards:
            dashboard_grid.add_widget(card)
    
    def _update_recent_activity(self, activities):
        """
        Update the recent activity list.
        
        Args:
            activities: List of InventoryHistoryRecord objects
        """
        # Clear the list
        activity_list = self.ids.recent_activity_list
        activity_list.clear_widgets()
        
        # Add each activity
        for activity in activities:
            item_type = "Material" if activity.item_type == "material" else "Product"
            
            # Set icon based on item type and action
            icon = "package-variant"
            if activity.item_type == "material":
                icon = "cube-outline"
            
            if activity.action == "add":
                icon = "plus-circle-outline"
            elif activity.action == "delete":
                icon = "delete-outline"
            elif activity.action == "update":
                icon = "pencil-outline"
            elif activity.action == "create":
                icon = "factory"
            elif activity.action == "use":
                icon = "arrow-down-circle-outline"
            
            # Create and add the list item
            list_item = TwoLineIconListItem(
                text=activity.action_description,
                secondary_text=f"{item_type} • {activity.timestamp}",
            )
            
            # Add the list item
            activity_list.add_widget(list_item)
