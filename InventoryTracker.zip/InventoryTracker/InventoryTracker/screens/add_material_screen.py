from kivy.lang import Builder
from kivy.metrics import dp
from kivymd.uix.screen import MDScreen
from kivymd.uix.button import MDFlatButton, MDRaisedButton
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.textfield import MDTextField

from inventory_manager import InventoryManager

# Define the KV language string for the add material screen
Builder.load_string('''
<AddMaterialScreen>:
    name: "add_material"
    MDBoxLayout:
        orientation: "vertical"
        
        # App Bar
        MDTopAppBar:
            title: "Add Material"
            left_action_items: [["arrow-left", lambda x: app.go_back()]]
            elevation: 4
        
        # Main Content
        MDScrollView:
            MDBoxLayout:
                orientation: "vertical"
                padding: dp(16)
                spacing: dp(16)
                size_hint_y: None
                height: self.minimum_height
                
                # Material Fields
                MDTextField:
                    id: name_field
                    hint_text: "Material Name"
                    helper_text: "Enter the name of the material"
                    helper_text_mode: "on_focus"
                    required: True
                    size_hint_y: None
                    height: dp(48)
                
                MDBoxLayout:
                    orientation: "horizontal"
                    size_hint_y: None
                    height: dp(48)
                    spacing: dp(8)
                    
                    MDTextField:
                        id: quantity_field
                        hint_text: "Quantity"
                        helper_text: "Initial stock quantity"
                        helper_text_mode: "on_focus"
                        input_filter: "float"
                        required: True
                        size_hint_x: 0.7
                    
                    MDTextField:
                        id: unit_field
                        hint_text: "Unit"
                        helper_text: "e.g., kg, pcs"
                        helper_text_mode: "on_focus"
                        required: True
                        size_hint_x: 0.3
                
                MDTextField:
                    id: min_quantity_field
                    hint_text: "Minimum Quantity"
                    helper_text: "Minimum stock level for alerts"
                    helper_text_mode: "on_focus"
                    input_filter: "float"
                    text: "0"
                    size_hint_y: None
                    height: dp(48)
                
                MDTextField:
                    id: cost_field
                    hint_text: "Cost per Unit"
                    helper_text: "Cost price per unit"
                    helper_text_mode: "on_focus"
                    input_filter: "float"
                    text: "0"
                    size_hint_y: None
                    height: dp(48)
                
                # Buttons
                MDBoxLayout:
                    orientation: "horizontal"
                    size_hint_y: None
                    height: dp(48)
                    spacing: dp(8)
                    padding: [0, dp(16), 0, 0]
                    
                    Widget:
                        size_hint_x: 0.5
                    
                    MDRaisedButton:
                        text: "Save"
                        on_release: root.save_material()
                        size_hint_x: 0.5
''')

class AddMaterialScreen(MDScreen):
    """
    Screen for adding a new material to the inventory.
    """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.inventory_manager = InventoryManager()
    
    def on_enter(self):
        """Called when the screen is displayed."""
        # Clear all fields
        self.ids.name_field.text = ""
        self.ids.quantity_field.text = ""
        self.ids.unit_field.text = ""
        self.ids.min_quantity_field.text = "0"
        self.ids.cost_field.text = "0"
    
    def save_material(self):
        """Validate and save the new material."""
        # Get input values
        name = self.ids.name_field.text.strip()
        quantity_text = self.ids.quantity_field.text.strip()
        unit = self.ids.unit_field.text.strip()
        min_quantity_text = self.ids.min_quantity_field.text.strip() or "0"
        cost_text = self.ids.cost_field.text.strip() or "0"
        
        # Validate inputs
        if not name:
            self._show_error("Name is required.")
            return
        
        if not quantity_text:
            self._show_error("Quantity is required.")
            return
        
        if not unit:
            self._show_error("Unit is required.")
            return
        
        # Convert numeric values
        try:
            quantity = float(quantity_text)
            min_quantity = float(min_quantity_text)
            cost_per_unit = float(cost_text)
        except ValueError:
            self._show_error("Invalid numeric values.")
            return
        
        # Validate numeric values
        if quantity < 0:
            self._show_error("Quantity cannot be negative.")
            return
        
        if min_quantity < 0:
            self._show_error("Minimum quantity cannot be negative.")
            return
        
        if cost_per_unit < 0:
            self._show_error("Cost per unit cannot be negative.")
            return
        
        # Save the material
        material = self.inventory_manager.add_material(
            name=name,
            quantity=quantity,
            unit=unit,
            min_quantity=min_quantity,
            cost_per_unit=cost_per_unit
        )
        
        if material:
            # Return to materials screen
            app = self.manager.get_parent_window().children[0]
            app.change_screen("materials")
        else:
            self._show_error("Failed to add material. Please try again.")
    
    def _show_error(self, message):
        """Show an error dialog with the given message."""
        app = self.manager.get_parent_window().children[0]
        app.show_error_dialog("Error", message)
