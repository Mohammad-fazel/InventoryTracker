from kivy.lang import Builder
from kivy.metrics import dp
from kivymd.uix.screen import MDScreen
from kivymd.uix.button import MDFlatButton, MDRaisedButton
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.textfield import MDTextField

from inventory_manager import InventoryManager

# Define the KV language string for the edit item screen
Builder.load_string('''
<EditItemScreen>:
    name: "edit_item"
    MDBoxLayout:
        orientation: "vertical"
        
        # App Bar
        MDTopAppBar:
            id: toolbar
            title: "Edit Item"
            left_action_items: [["arrow-left", lambda x: app.go_back()]]
            elevation: 4
        
        # Main Content
        MDScrollView:
            id: scroll_view
            MDBoxLayout:
                id: main_container
                orientation: "vertical"
                padding: dp(16)
                spacing: dp(16)
                size_hint_y: None
                height: self.minimum_height
                
                # Fields will be added dynamically
                
                # Buttons
                MDBoxLayout:
                    orientation: "horizontal"
                    size_hint_y: None
                    height: dp(48)
                    spacing: dp(8)
                    padding: [0, dp(16), 0, 0]
                    
                    Widget:
                        size_hint_x: 0.5
                    
                    MDRaisedButton:
                        text: "Save"
                        on_release: root.save_item()
                        size_hint_x: 0.5
''')

class EditItemScreen(MDScreen):
    """
    Screen for editing an existing material or product.
    """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.inventory_manager = InventoryManager()
        self.item_data = None
        self.item_type = None
        self.fields = {}
    
    def on_enter(self):
        """Called when the screen is displayed."""
        if not self.item_data:
            # No item to edit, go back
            app = self.manager.get_parent_window().children[0]
            app.go_back()
            return
            
        # Set the toolbar title
        self.item_type = self.item_data.get('type', 'item')
        self.ids.toolbar.title = f"Edit {self.item_type.capitalize()}"
        
        # Create fields based on item type
        if self.item_type == 'material':
            self._create_material_fields()
        elif self.item_type == 'product':
            # For products, it's easier to go to the add_product screen
            # and let it handle the edit
            app = self.manager.get_parent_window().children[0]
            app.change_screen("add_product", item_data=self.item_data)
    
    def _create_material_fields(self):
        """Create fields for editing a material."""
        # Clear the container
        container = self.ids.main_container
        container.clear_widgets()
        
        # Name field
        name_field = MDTextField(
            hint_text="Material Name",
            helper_text="Enter the name of the material",
            helper_text_mode="on_focus",
            required=True,
            size_hint_y=None,
            height=dp(48),
            text=self.item_data.get('name', '')
        )
        container.add_widget(name_field)
        self.fields['name'] = name_field
        
        # Quantity and unit fields
        quantity_box = MDBoxLayout(
            orientation="horizontal",
            size_hint_y=None,
            height=dp(48),
            spacing=dp(8)
        )
        
        quantity_field = MDTextField(
            hint_text="Quantity",
            helper_text="Current stock quantity",
            helper_text_mode="on_focus",
            input_filter="float",
            required=True,
            size_hint_x=0.7,
            text=str(self.item_data.get('quantity', 0))
        )
        quantity_box.add_widget(quantity_field)
        self.fields['quantity'] = quantity_field
        
        unit_field = MDTextField(
            hint_text="Unit",
            helper_text="e.g., kg, pcs",
            helper_text_mode="on_focus",
            required=True,
            size_hint_x=0.3,
            text=self.item_data.get('unit', '')
        )
        quantity_box.add_widget(unit_field)
        self.fields['unit'] = unit_field
        
        container.add_widget(quantity_box)
        
        # Minimum quantity field
        min_quantity_field = MDTextField(
            hint_text="Minimum Quantity",
            helper_text="Minimum stock level for alerts",
            helper_text_mode="on_focus",
            input_filter="float",
            size_hint_y=None,
            height=dp(48),
            text=str(self.item_data.get('min_quantity', 0))
        )
        container.add_widget(min_quantity_field)
        self.fields['min_quantity'] = min_quantity_field
        
        # Cost per unit field
        cost_field = MDTextField(
            hint_text="Cost per Unit",
            helper_text="Cost price per unit",
            helper_text_mode="on_focus",
            input_filter="float",
            size_hint_y=None,
            height=dp(48),
            text=str(self.item_data.get('cost_per_unit', 0))
        )
        container.add_widget(cost_field)
        self.fields['cost_per_unit'] = cost_field
        
        # Add buttons box
        buttons_box = MDBoxLayout(
            orientation="horizontal",
            size_hint_y=None,
            height=dp(48),
            spacing=dp(8),
            padding=[0, dp(16), 0, 0]
        )
        
        # Spacer
        buttons_box.add_widget(Widget(size_hint_x=0.5))
        
        # Save button
        save_button = MDRaisedButton(
            text="Save",
            on_release=lambda x: self.save_item(),
            size_hint_x=0.5
        )
        buttons_box.add_widget(save_button)
        
        container.add_widget(buttons_box)
    
    def save_item(self):
        """Validate and save the edited item."""
        if self.item_type == 'material':
            self._save_material()
    
    def _save_material(self):
        """Validate and save the edited material."""
        # Get input values
        name = self.fields['name'].text.strip()
        quantity_text = self.fields['quantity'].text.strip()
        unit = self.fields['unit'].text.strip()
        min_quantity_text = self.fields['min_quantity'].text.strip() or "0"
        cost_text = self.fields['cost_per_unit'].text.strip() or "0"
        
        # Validate inputs
        if not name:
            self._show_error("Name is required.")
            return
        
        if not quantity_text:
            self._show_error("Quantity is required.")
            return
        
        if not unit:
            self._show_error("Unit is required.")
            return
        
        # Convert numeric values
        try:
            quantity = float(quantity_text)
            min_quantity = float(min_quantity_text)
            cost_per_unit = float(cost_text)
        except ValueError:
            self._show_error("Invalid numeric values.")
            return
        
        # Validate numeric values
        if quantity < 0:
            self._show_error("Quantity cannot be negative.")
            return
        
        if min_quantity < 0:
            self._show_error("Minimum quantity cannot be negative.")
            return
        
        if cost_per_unit < 0:
            self._show_error("Cost per unit cannot be negative.")
            return
        
        # Update the material
        material = self.inventory_manager.update_material(
            material_id=self.item_data['id'],
            name=name,
            quantity=quantity,
            unit=unit,
            min_quantity=min_quantity,
            cost_per_unit=cost_per_unit
        )
        
        if material:
            # Return to materials screen
            app = self.manager.get_parent_window().children[0]
            app.change_screen("materials")
        else:
            self._show_error("Failed to update material. Please try again.")
    
    def _show_error(self, message):
        """Show an error dialog with the given message."""
        app = self.manager.get_parent_window().children[0]
        app.show_error_dialog("Error", message)
