from kivy.lang import Builder
from kivy.metrics import dp
from kivymd.uix.screen import MDScreen
from kivymd.uix.button import MDFlatButton, MDRaisedButton, MDIconButton
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.textfield import MDTextField
from kivymd.uix.dialog import MDDialog
from kivymd.uix.label import MDLabel
from kivymd.uix.list import MDList, OneLineIconListItem, IconLeftWidget

from inventory_manager import InventoryManager

# Define the KV language string for the add product screen
Builder.load_string('''
<AddProductScreen>:
    name: "add_product"
    MDBoxLayout:
        orientation: "vertical"
        
        # App Bar
        MDTopAppBar:
            title: "Add Product"
            left_action_items: [["arrow-left", lambda x: app.go_back()]]
            elevation: 4
        
        # Main Content
        MDScrollView:
            MDBoxLayout:
                orientation: "vertical"
                padding: dp(16)
                spacing: dp(16)
                size_hint_y: None
                height: self.minimum_height
                
                # Product Fields
                MDTextField:
                    id: name_field
                    hint_text: "Product Name"
                    helper_text: "Enter the name of the product"
                    helper_text_mode: "on_focus"
                    required: True
                    size_hint_y: None
                    height: dp(48)
                
                MDTextField:
                    id: price_field
                    hint_text: "Price"
                    helper_text: "Selling price per unit"
                    helper_text_mode: "on_focus"
                    input_filter: "float"
                    text: "0"
                    size_hint_y: None
                    height: dp(48)
                
                # Materials Section
                MDBoxLayout:
                    orientation: "vertical"
                    size_hint_y: None
                    height: dp(48)
                    spacing: dp(8)
                    
                    MDLabel:
                        text: "Required Materials"
                        font_style: "H6"
                
                # Materials List
                MDBoxLayout:
                    id: materials_container
                    orientation: "vertical"
                    size_hint_y: None
                    height: self.minimum_height
                    spacing: dp(8)
                
                # Add Material Button
                MDRaisedButton:
                    text: "Add Material Requirement"
                    on_release: root.show_add_material_dialog()
                    size_hint_x: 1
                
                # Buttons
                MDBoxLayout:
                    orientation: "horizontal"
                    size_hint_y: None
                    height: dp(48)
                    spacing: dp(8)
                    padding: [0, dp(16), 0, 0]
                    
                    Widget:
                        size_hint_x: 0.5
                    
                    MDRaisedButton:
                        text: "Save"
                        on_release: root.save_product()
                        size_hint_x: 0.5

<MaterialRequirementItem>:
    orientation: "horizontal"
    size_hint_y: None
    height: dp(56)
    spacing: dp(8)
    padding: [dp(8), 0, dp(8), 0]
    
    MDLabel:
        id: material_name
        text: root.material_name
        size_hint_x: 0.4
    
    MDLabel:
        id: quantity_label
        text: f"{root.quantity} {root.unit}"
        size_hint_x: 0.4
    
    MDIconButton:
        icon: "delete"
        size_hint_x: 0.2
        on_release: root.on_delete()
''')

class MaterialRequirementItem(MDBoxLayout):
    """Widget for displaying a material requirement in the list."""
    def __init__(self, material_id, material_name, quantity, unit, on_delete, **kwargs):
        super().__init__(**kwargs)
        self.material_id = material_id
        self.material_name = material_name
        self.quantity = quantity
        self.unit = unit
        self.delete_callback = on_delete
    
    def on_delete(self):
        """Call the delete callback when delete button is pressed."""
        if self.delete_callback:
            self.delete_callback(self.material_id)

class AddProductScreen(MDScreen):
    """
    Screen for adding a new product to the inventory.
    """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.inventory_manager = InventoryManager()
        self.dialog = None
        self.material_requirements = {}  # {material_id: {'name': name, 'quantity': qty, 'unit': unit}}
        # For editing existing product
        self.item_data = None
    
    def on_enter(self):
        """Called when the screen is displayed."""
        if self.item_data and 'materials' in self.item_data:
            # We're editing a product that was passed from another screen
            self.ids.name_field.text = self.item_data.get('name', '')
            self.ids.price_field.text = str(self.item_data.get('price', 0))
            
            # Process materials
            self.material_requirements = {}
            for material in self.item_data.get('materials', []):
                self.material_requirements[material['material_id']] = {
                    'name': material['name'],
                    'quantity': material['quantity_needed'],
                    'unit': material['unit']
                }
            
            # Update the UI
            self._update_materials_list()
            
            # Clear item_data to prevent re-populating on next enter
            self.item_data = None
        else:
            # Clear all fields for new product
            self.ids.name_field.text = ""
            self.ids.price_field.text = "0"
            self.material_requirements = {}
            self._update_materials_list()
    
    def show_add_material_dialog(self):
        """Show dialog to add a material requirement."""
        if self.dialog:
            self.dialog.dismiss()
        
        # Get all materials
        materials = self.inventory_manager.get_all_materials()
        
        # Create content for the dialog
        content = MDBoxLayout(
            orientation="vertical",
            spacing=dp(10),
            size_hint_y=None,
            height=dp(400)
        )
        
        # Title
        title_label = MDLabel(
            text="Select Material",
            font_style="H6",
            size_hint_y=None,
            height=dp(48)
        )
        content.add_widget(title_label)
        
        # Search field
        search_field = MDTextField(
            hint_text="Search materials",
            size_hint_y=None,
            height=dp(48)
        )
        content.add_widget(search_field)
        
        # Materials list
        scroll_view = MDBoxLayout(
            orientation="vertical",
            size_hint_y=None,
            height=dp(280)
        )
        
        materials_list = MDList()
        
        # Add materials to list
        for material in materials:
            # Skip materials already added
            if material.id in self.material_requirements:
                continue
                
            item = OneLineIconListItem(
                text=f"{material.name} ({material.unit})",
                on_release=lambda x, m=material: self._on_material_selected(m)
            )
            icon = IconLeftWidget(icon="cube-outline")
            item.add_widget(icon)
            materials_list.add_widget(item)
        
        scroll_view.add_widget(materials_list)
        content.add_widget(scroll_view)
        
        # Create the dialog
        self.dialog = MDDialog(
            title="Add Material Requirement",
            type="custom",
            content_cls=content,
            buttons=[
                MDFlatButton(
                    text="CANCEL",
                    on_release=lambda x: self.dialog.dismiss()
                )
            ]
        )
        
        # Set up search functionality
        def filter_materials(text):
            materials_list.clear_widgets()
            for material in materials:
                if material.id in self.material_requirements:
                    continue
                    
                if text.lower() in material.name.lower():
                    item = OneLineIconListItem(
                        text=f"{material.name} ({material.unit})",
                        on_release=lambda x, m=material: self._on_material_selected(m)
                    )
                    icon = IconLeftWidget(icon="cube-outline")
                    item.add_widget(icon)
                    materials_list.add_widget(item)
        
        search_field.bind(text=lambda instance, text: filter_materials(text))
        
        self.dialog.open()
    
    def _on_material_selected(self, material):
        """
        Handle material selection from the dialog.
        
        Args:
            material: Material object that was selected
        """
        self.dialog.dismiss()
        self.dialog = None
        
        # Show dialog to enter quantity
        self._show_quantity_dialog(material)
    
    def _show_quantity_dialog(self, material):
        """
        Show dialog to enter quantity for the selected material.
        
        Args:
            material: Material object to add
        """
        content = MDBoxLayout(
            orientation="vertical",
            spacing=dp(10),
            padding=dp(20),
            size_hint_y=None,
            height=dp(120)
        )
        
        # Add a text field for quantity
        quantity_field = MDTextField(
            hint_text=f"Quantity needed (in {material.unit})",
            input_filter="float",
            text="1"
        )
        content.add_widget(quantity_field)
        
        # Create the dialog
        self.dialog = MDDialog(
            title=f"Quantity of {material.name}",
            type="custom",
            content_cls=content,
            buttons=[
                MDFlatButton(
                    text="CANCEL",
                    on_release=lambda x: self.dialog.dismiss()
                ),
                MDFlatButton(
                    text="ADD",
                    on_release=lambda x: self._add_material_requirement(material, quantity_field.text)
                )
            ]
        )
        self.dialog.open()
    
    def _add_material_requirement(self, material, quantity_text):
        """
        Add a material requirement to the product.
        
        Args:
            material: Material object to add
            quantity_text: Text from the quantity field
        """
        self.dialog.dismiss()
        self.dialog = None
        
        # Convert quantity to float
        try:
            quantity = float(quantity_text)
            if quantity <= 0:
                raise ValueError("Quantity must be positive")
        except ValueError:
            app = self.manager.get_parent_window().children[0]
            app.show_error_dialog(
                title="Invalid Quantity",
                text="Please enter a positive number for quantity."
            )
            return
        
        # Add to requirements
        self.material_requirements[material.id] = {
            'name': material.name,
            'quantity': quantity,
            'unit': material.unit
        }
        
        # Update the UI
        self._update_materials_list()
    
    def _update_materials_list(self):
        """Update the materials list in the UI."""
        # Clear the container
        container = self.ids.materials_container
        container.clear_widgets()
        
        # Add each material requirement
        for material_id, data in self.material_requirements.items():
            item = MaterialRequirementItem(
                material_id=material_id,
                material_name=data['name'],
                quantity=data['quantity'],
                unit=data['unit'],
                on_delete=self._delete_material_requirement
            )
            container.add_widget(item)
    
    def _delete_material_requirement(self, material_id):
        """
        Delete a material requirement.
        
        Args:
            material_id: ID of the material to delete
        """
        if material_id in self.material_requirements:
            del self.material_requirements[material_id]
            self._update_materials_list()
    
    def save_product(self):
        """Validate and save the new product."""
        # Get input values
        name = self.ids.name_field.text.strip()
        price_text = self.ids.price_field.text.strip() or "0"
        
        # Validate inputs
        if not name:
            self._show_error("Name is required.")
            return
        
        # Convert numeric values
        try:
            price = float(price_text)
        except ValueError:
            self._show_error("Invalid price value.")
            return
        
        # Validate numeric values
        if price < 0:
            self._show_error("Price cannot be negative.")
            return
        
        # Check if there are any material requirements
        if not self.material_requirements:
            self._show_error("At least one material is required.")
            return
        
        # Format materials_needed for the database
        materials_needed = []
        for material_id, data in self.material_requirements.items():
            materials_needed.append({
                'material_id': material_id,
                'quantity_needed': data['quantity']
            })
        
        # Save the product
        product = self.inventory_manager.add_product(
            name=name,
            price=price,
            materials_needed=materials_needed
        )
        
        if product:
            # Return to products screen
            app = self.manager.get_parent_window().children[0]
            app.change_screen("products")
        else:
            self._show_error("Failed to add product. Please try again.")
    
    def _show_error(self, message):
        """Show an error dialog with the given message."""
        app = self.manager.get_parent_window().children[0]
        app.show_error_dialog("Error", message)
