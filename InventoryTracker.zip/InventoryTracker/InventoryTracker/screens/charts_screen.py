from kivy.lang import Builder
from kivy.metrics import dp
from kivy.uix.image import Image
from kivymd.uix.screen import MDScreen
from kivymd.uix.button import MDFlatButton, MDRoundFlatIconButton
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.card import MDCard
from kivymd.uix.dialog import MDDialog
from kivymd.uix.list import MDList, OneLineIconListItem, IconLeftWidget
from kivymd.uix.label import MDLabel
from kivymd.uix.tab import MDTabsBase
from kivymd.uix.floatlayout import MDFloatLayout

from inventory_manager import InventoryManager
from chart_manager import ChartManager
from widgets.chart_widget import ChartWidget

# Define the KV language string for the charts screen
Builder.load_string('''
<ChartsScreen>:
    name: "charts"
    MDBoxLayout:
        orientation: "vertical"
        
        # App Bar
        MDTopAppBar:
            title: "Reports & Charts"
            left_action_items: [["arrow-left", lambda x: app.go_back()]]
            elevation: 4
        
        # Tabs
        MDTabs:
            id: tabs
            on_tab_switch: root.on_tab_switch(*args)
            
<Tab>:
    MDScrollView:
        id: scroll_view
        MDBoxLayout:
            id: container
            orientation: "vertical"
            padding: dp(16)
            spacing: dp(16)
            size_hint_y: None
            height: self.minimum_height

<ChartCard>:
    orientation: "vertical"
    padding: dp(16)
    size_hint_y: None
    height: dp(400)
    
    MDBoxLayout:
        orientation: "horizontal"
        size_hint_y: None
        height: dp(40)
        
        MDLabel:
            id: title_label
            text: root.title
            font_style: "H6"
            size_hint_x: 0.8
            
        MDFlatButton:
            id: refresh_button
            text: "Refresh"
            size_hint_x: 0.2
            on_release: root.refresh_chart()
    
    # Chart container
    MDBoxLayout:
        id: chart_container
        orientation: "vertical"
        size_hint_y: None
        height: dp(300)
''')

class Tab(MDFloatLayout, MDTabsBase):
    """Class representing a tab in the chart screen."""
    pass

class ChartCard(MDCard):
    """Card widget for displaying charts."""
    def __init__(self, title="", chart_function=None, chart_params=None, **kwargs):
        super().__init__(**kwargs)
        self.title = title
        self.chart_function = chart_function
        self.chart_params = chart_params or {}
        self.chart_manager = ChartManager()
        self.chart_widget = None
        
        # Schedule the chart generation after initialization
        from kivy.clock import Clock
        Clock.schedule_once(lambda dt: self.refresh_chart())
    
    def refresh_chart(self):
        """Generate and display the chart."""
        if self.chart_function:
            # Generate chart data
            chart_data = self.chart_function(**self.chart_params)
            
            # Clear existing chart
            chart_container = self.ids.chart_container
            chart_container.clear_widgets()
            
            if chart_data:
                # Create new chart widget
                self.chart_widget = ChartWidget(
                    chart_data=chart_data,
                    size_hint_y=None,
                    height=dp(300)
                )
                chart_container.add_widget(self.chart_widget)
            else:
                # Show empty state
                label = MDLabel(
                    text="No data available",
                    halign="center",
                    valign="middle",
                    size_hint_y=None,
                    height=dp(300)
                )
                chart_container.add_widget(label)

class ChartsScreen(MDScreen):
    """
    Screen for displaying charts and reports about inventory.
    """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.inventory_manager = InventoryManager()
        self.chart_manager = ChartManager()
        self.tabs = {}
        
    def on_enter(self):
        """Called when the screen is displayed."""
        # Initialize tabs if not already done
        if not self.tabs:
            self._create_tabs()
            
        # Refresh data for the current tab
        self.refresh_current_tab()
    
    def _create_tabs(self):
        """Create the tabs for different chart categories."""
        tabs_container = self.ids.tabs
        
        # Create tabs
        self.tabs = {
            "overview": Tab(title="Overview"),
            "materials": Tab(title="Materials"),
            "products": Tab(title="Products"),
            "history": Tab(title="History")
        }
        
        # Add tabs to the tab container
        for tab in self.tabs.values():
            tabs_container.add_widget(tab)
    
    def refresh_current_tab(self):
        """Refresh data for the current tab."""
        current_tab = self.ids.tabs.get_current_tab()
        if current_tab:
            self._load_tab_content(current_tab)
    
    def on_tab_switch(self, instance_tabs, instance_tab, instance_tab_label, tab_text):
        """Called when a tab is switched."""
        self._load_tab_content(instance_tab)
    
    def _load_tab_content(self, tab):
        """
        Load the appropriate content for the selected tab.
        
        Args:
            tab: The tab instance to load content for
        """
        # Clear the tab container
        container = tab.ids.container
        container.clear_widgets()
        
        # Load content based on tab name
        if tab.title == "Overview":
            self._load_overview_tab(container)
        elif tab.title == "Materials":
            self._load_materials_tab(container)
        elif tab.title == "Products":
            self._load_products_tab(container)
        elif tab.title == "History":
            self._load_history_tab(container)
    
    def _load_overview_tab(self, container):
        """Load content for the overview tab."""
        # Get dashboard stats
        stats = self.inventory_manager.get_dashboard_stats()
        
        # Summary card
        summary_card = MDCard(
            orientation="vertical",
            padding=dp(16),
            size_hint_y=None,
            height=dp(160)
        )
        
        # Add title
        title_label = MDLabel(
            text="Inventory Summary",
            font_style="H6",
            size_hint_y=None,
            height=dp(40)
        )
        summary_card.add_widget(title_label)
        
        # Add stats
        stats_layout = MDBoxLayout(
            orientation="horizontal",
            size_hint_y=None,
            height=dp(100)
        )
        
        # Create columns for stats
        left_column = MDBoxLayout(
            orientation="vertical",
            size_hint_x=0.5
        )
        right_column = MDBoxLayout(
            orientation="vertical",
            size_hint_x=0.5
        )
        
        # Add stats to columns
        left_column.add_widget(MDLabel(text=f"Materials: {stats.total_materials}"))
        left_column.add_widget(MDLabel(text=f"Low Stock: {stats.low_stock_materials}"))
        left_column.add_widget(MDLabel(text=f"Material Value: ${stats.materials_value:.2f}"))
        
        right_column.add_widget(MDLabel(text=f"Products: {stats.total_products}"))
        right_column.add_widget(MDLabel(text=f"Out of Stock: {stats.out_of_stock_products}"))
        right_column.add_widget(MDLabel(text=f"Product Value: ${stats.products_value:.2f}"))
        
        stats_layout.add_widget(left_column)
        stats_layout.add_widget(right_column)
        summary_card.add_widget(stats_layout)
        
        # Add to container
        container.add_widget(summary_card)
        
        # Add material distribution chart
        materials = self.inventory_manager.get_all_materials()
        container.add_widget(
            ChartCard(
                title="Material Value Distribution",
                chart_function=self.chart_manager.generate_materials_distribution_chart,
                chart_params={"materials": materials}
            )
        )
        
        # Add product distribution chart
        products = self.inventory_manager.get_all_products()
        container.add_widget(
            ChartCard(
                title="Product Value Distribution",
                chart_function=self.chart_manager.generate_products_distribution_chart,
                chart_params={"products": products}
            )
        )
        
        # Add low stock materials chart
        container.add_widget(
            ChartCard(
                title="Low Stock Materials",
                chart_function=self.chart_manager.generate_low_stock_chart,
                chart_params={"materials": materials}
            )
        )
    
    def _load_materials_tab(self, container):
        """Load content for the materials tab."""
        # Get all materials
        materials = self.inventory_manager.get_all_materials()
        
        # Get material usage data
        history = self.inventory_manager.get_inventory_history(item_type="material", days=30)
        
        # Add material usage chart
        container.add_widget(
            ChartCard(
                title="Material Usage (Last 30 Days)",
                chart_function=self.chart_manager.generate_materials_usage_chart,
                chart_params={
                    "history_data": [record.to_dict() for record in history],
                    "title": "Material Usage"
                }
            )
        )
        
        # Add charts for each material
        for material in materials[:5]:  # Limit to first 5 materials for performance
            container.add_widget(
                ChartCard(
                    title=f"{material.name} Inventory Levels",
                    chart_function=self.chart_manager.generate_inventory_level_chart,
                    chart_params={
                        "history_data": self.inventory_manager.get_inventory_levels_over_time("material", material.id),
                        "title": "Inventory Level",
                        "item_name": material.name
                    }
                )
            )
    
    def _load_products_tab(self, container):
        """Load content for the products tab."""
        # Get all products
        products = self.inventory_manager.get_all_products()
        
        # Get product creation data
        history = self.inventory_manager.get_inventory_history(item_type="product", days=30)
        
        # Add product creation chart
        container.add_widget(
            ChartCard(
                title="Product Creation (Last 30 Days)",
                chart_function=self.chart_manager.generate_product_creation_chart,
                chart_params={
                    "history_data": [record.to_dict() for record in history],
                    "title": "Product Creation"
                }
            )
        )
        
        # Add charts for each product
        for product in products[:5]:  # Limit to first 5 products for performance
            container.add_widget(
                ChartCard(
                    title=f"{product.name} Inventory Levels",
                    chart_function=self.chart_manager.generate_inventory_level_chart,
                    chart_params={
                        "history_data": self.inventory_manager.get_inventory_levels_over_time("product", product.id),
                        "title": "Inventory Level",
                        "item_name": product.name
                    }
                )
            )
    
    def _load_history_tab(self, container):
        """Load content for the history tab."""
        # Get recent activity
        history = self.inventory_manager.get_inventory_history(days=30)
        
        # Create history card
        history_card = MDCard(
            orientation="vertical",
            padding=dp(16),
            size_hint_y=None,
            height=dp(500)
        )
        
        # Add title
        title_label = MDLabel(
            text="Recent Activity (Last 30 Days)",
            font_style="H6",
            size_hint_y=None,
            height=dp(40)
        )
        history_card.add_widget(title_label)
        
        # Create scrollable list for history
        scroll_view = MDBoxLayout(
            orientation="vertical",
            size_hint_y=None,
            height=dp(440)
        )
        
        # Create and add list
        history_list = MDList()
        
        if not history:
            # Show empty state
            empty_label = MDLabel(
                text="No recent activity",
                halign="center",
                valign="middle"
            )
            scroll_view.add_widget(empty_label)
        else:
            # Add each history item to the list
            for item in history:
                # Determine icon based on action and item type
                icon = "package-variant"
                if item.item_type == "material":
                    icon = "cube-outline"
                
                if item.action == "add":
                    icon = "plus-circle-outline"
                elif item.action == "delete":
                    icon = "delete-outline"
                elif item.action == "update":
                    icon = "pencil-outline"
                elif item.action == "create":
                    icon = "factory"
                elif item.action == "use":
                    icon = "arrow-down-circle-outline"
                
                # Create and add list item
                list_item = OneLineIconListItem(
                    text=f"{item.action_description} ({item.timestamp})"
                )
                
                icon_widget = IconLeftWidget(icon=icon)
                list_item.add_widget(icon_widget)
                
                history_list.add_widget(list_item)
            
            scroll_view.add_widget(history_list)
        
        history_card.add_widget(scroll_view)
        
        # Add to container
        container.add_widget(history_card)
