from kivy.lang import Builder
from kivy.metrics import dp
from kivymd.uix.screen import MDScreen
from kivymd.uix.button import MDFlatButton, MDRaisedButton
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.dialog import MDDialog
from kivymd.uix.textfield import MDTextField
from kivymd.uix.list import MDList

from inventory_manager import InventoryManager
from widgets.inventory_item import ProductListItem

# Define the KV language string for the products screen
Builder.load_string('''
<ProductsScreen>:
    name: "products"
    MDBoxLayout:
        orientation: "vertical"
        
        # App Bar
        MDTopAppBar:
            title: "Finished Products"
            left_action_items: [["arrow-left", lambda x: app.go_back()]]
            right_action_items: [["plus", lambda x: app.change_screen("add_product")], ["refresh", lambda x: root.refresh_data()]]
            elevation: 4
        
        # Search Bar
        MDBoxLayout:
            orientation: "horizontal"
            size_hint_y: None
            height: dp(56)
            padding: dp(8)
            
            MDTextField:
                id: search_field
                hint_text: "Search products..."
                on_text: root.filter_products(self.text)
                icon_right: "magnify"
                
        # Products List
        MDScrollView:
            id: scroll_view
            
            MDList:
                id: products_list
                padding: dp(8)
                
        # Empty State
        MDBoxLayout:
            id: empty_state
            orientation: "vertical"
            padding: dp(16)
            spacing: dp(8)
            size_hint_y: None
            height: dp(200)
            pos_hint: {"center_y": 0.5}
            opacity: 0
            
            MDLabel:
                text: "No Products Found"
                font_style: "H5"
                halign: "center"
                
            MDLabel:
                text: "Add your first product to get started"
                theme_text_color: "Secondary"
                halign: "center"
                
            MDRaisedButton:
                text: "Add Product"
                pos_hint: {"center_x": 0.5}
                on_press: app.change_screen("add_product")
''')

class ProductsScreen(MDScreen):
    """
    Screen for displaying and managing finished products.
    """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.inventory_manager = InventoryManager()
        self.all_products = []
        self.dialog = None
        
    def on_enter(self):
        """Called when the screen is displayed."""
        self.refresh_data()
        
    def refresh_data(self):
        """Refresh the products list."""
        # Clear the search field
        self.ids.search_field.text = ""
        
        # Get all products
        self.all_products = self.inventory_manager.get_all_products()
        
        # Refresh the list
        self._update_products_list(self.all_products)
    
    def _update_products_list(self, products):
        """
        Update the products list with the provided products.
        
        Args:
            products: List of Product objects to display
        """
        # Clear the list
        products_list = self.ids.products_list
        products_list.clear_widgets()
        
        # Update empty state visibility
        if not products:
            self.ids.empty_state.opacity = 1
            self.ids.scroll_view.opacity = 0
        else:
            self.ids.empty_state.opacity = 0
            self.ids.scroll_view.opacity = 1
            
            # Add each product
            for product in products:
                # Create list item
                list_item = ProductListItem(
                    product=product,
                    on_edit=lambda p=product: self._edit_product(p),
                    on_delete=lambda p=product: self._confirm_delete(p),
                    on_create=lambda p=product: self._show_create_dialog(p),
                    on_use=lambda p=product: self._show_use_dialog(p)
                )
                
                # Add the list item
                products_list.add_widget(list_item)
    
    def filter_products(self, search_text):
        """
        Filter the products list based on search text.
        
        Args:
            search_text: Text to search for in product names
        """
        if not search_text:
            # If search is empty, show all products
            self._update_products_list(self.all_products)
        else:
            # Filter products by name
            search_text = search_text.lower()
            filtered_products = [
                p for p in self.all_products
                if search_text in p.name.lower()
            ]
            self._update_products_list(filtered_products)
    
    def _edit_product(self, product):
        """
        Navigate to the edit screen for a product.
        
        Args:
            product: Product object to edit
        """
        # Prepare data for edit screen
        item_data = {
            'id': product.id,
            'name': product.name,
            'price': product.price,
            'materials': [material.to_dict() for material in product.materials],
            'type': 'product'
        }
        
        # Navigate to edit screen
        app = self.manager.get_parent_window().children[0]
        app.change_screen("edit_item", item_data=item_data)
    
    def _confirm_delete(self, product):
        """
        Show confirmation dialog before deleting a product.
        
        Args:
            product: Product object to delete
        """
        app = self.manager.get_parent_window().children[0]
        app.show_confirmation_dialog(
            title="Delete Product",
            text=f"Are you sure you want to delete {product.name}? This action cannot be undone.",
            on_confirm=lambda: self._delete_product(product.id)
        )
    
    def _delete_product(self, product_id):
        """
        Delete a product from the inventory.
        
        Args:
            product_id: ID of the product to delete
        """
        success = self.inventory_manager.delete_product(product_id)
        
        if success:
            # Refresh the list
            self.refresh_data()
        else:
            # Show error
            app = self.manager.get_parent_window().children[0]
            app.show_error_dialog(
                title="Error",
                text="Could not delete product."
            )
    
    def _show_create_dialog(self, product):
        """
        Show dialog to create batches of a product.
        
        Args:
            product: Product object to create
        """
        if self.dialog:
            self.dialog.dismiss()
            self.dialog = None
        
        # Create content for the dialog
        content = MDBoxLayout(
            orientation="vertical",
            spacing=dp(10),
            padding=dp(20),
            size_hint_y=None,
            height=dp(120)
        )
        
        # Add a text field for quantity
        quantity_field = MDTextField(
            hint_text="Quantity to create",
            input_filter="int",
            text="1"
        )
        content.add_widget(quantity_field)
        
        # Create the dialog
        self.dialog = MDDialog(
            title=f"Create {product.name}",
            type="custom",
            content_cls=content,
            buttons=[
                MDFlatButton(
                    text="CANCEL",
                    on_release=lambda x: self.dialog.dismiss()
                ),
                MDFlatButton(
                    text="CREATE",
                    on_release=lambda x: self._create_product_batch(product.id, quantity_field.text)
                )
            ]
        )
        self.dialog.open()
    
    def _create_product_batch(self, product_id, quantity_text):
        """
        Create a batch of products.
        
        Args:
            product_id: ID of the product to create
            quantity_text: Text from the quantity field
        """
        self.dialog.dismiss()
        self.dialog = None
        
        # Convert quantity to integer
        try:
            quantity = int(quantity_text)
            if quantity <= 0:
                raise ValueError("Quantity must be positive")
        except ValueError:
            app = self.manager.get_parent_window().children[0]
            app.show_error_dialog(
                title="Invalid Quantity",
                text="Please enter a positive number for quantity."
            )
            return
        
        # Check if enough materials are available
        is_available, insufficient = self.inventory_manager.check_material_availability(product_id, quantity)
        
        if not is_available:
            # Show error with details of insufficient materials
            error_msg = "Not enough materials available:\n"
            for item in insufficient:
                error_msg += f"• {item['name']}: Need {item['needed']} {item['unit']}, have {item['available']} {item['unit']}\n"
            
            app = self.manager.get_parent_window().children[0]
            app.show_error_dialog(
                title="Insufficient Materials",
                text=error_msg
            )
            return
        
        # Create the product batch
        result = self.inventory_manager.create_product_batch(product_id, quantity)
        
        if result:
            # Refresh the list
            self.refresh_data()
        else:
            # Show error
            app = self.manager.get_parent_window().children[0]
            app.show_error_dialog(
                title="Error",
                text="Could not create product batch."
            )
    
    def _show_use_dialog(self, product):
        """
        Show dialog to use (consume) products from inventory.
        
        Args:
            product: Product object to use
        """
        if self.dialog:
            self.dialog.dismiss()
            self.dialog = None
        
        # Create content for the dialog
        content = MDBoxLayout(
            orientation="vertical",
            spacing=dp(10),
            padding=dp(20),
            size_hint_y=None,
            height=dp(120)
        )
        
        # Add a text field for quantity
        quantity_field = MDTextField(
            hint_text="Quantity to use",
            input_filter="int",
            text="1"
        )
        content.add_widget(quantity_field)
        
        # Create the dialog
        self.dialog = MDDialog(
            title=f"Use {product.name}",
            type="custom",
            content_cls=content,
            buttons=[
                MDFlatButton(
                    text="CANCEL",
                    on_release=lambda x: self.dialog.dismiss()
                ),
                MDFlatButton(
                    text="USE",
                    on_release=lambda x: self._use_product(product.id, quantity_field.text)
                )
            ]
        )
        self.dialog.open()
    
    def _use_product(self, product_id, quantity_text):
        """
        Use (consume) products from inventory.
        
        Args:
            product_id: ID of the product to use
            quantity_text: Text from the quantity field
        """
        self.dialog.dismiss()
        self.dialog = None
        
        # Convert quantity to integer
        try:
            quantity = int(quantity_text)
            if quantity <= 0:
                raise ValueError("Quantity must be positive")
        except ValueError:
            app = self.manager.get_parent_window().children[0]
            app.show_error_dialog(
                title="Invalid Quantity",
                text="Please enter a positive number for quantity."
            )
            return
        
        # Use the product
        result = self.inventory_manager.use_product(product_id, quantity)
        
        if result:
            # Refresh the list
            self.refresh_data()
        else:
            # Show error
            app = self.manager.get_parent_window().children[0]
            app.show_error_dialog(
                title="Error",
                text="Not enough products in inventory."
            )
