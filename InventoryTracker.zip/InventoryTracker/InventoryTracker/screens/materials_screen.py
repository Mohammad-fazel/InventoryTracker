from kivy.lang import Builder
from kivy.metrics import dp
from kivymd.uix.screen import MDScreen
from kivymd.uix.button import MDFlatButton, MDRaisedButton, MDIconButton
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.list import MDList, OneLineIconListItem, ThreeLineAvatarIconListItem, IconLeftWidget
from kivymd.uix.dialog import MDDialog
from kivymd.uix.textfield import MDTextField

from inventory_manager import InventoryManager
from widgets.inventory_item import MaterialListItem

# Define the KV language string for the materials screen
Builder.load_string('''
<MaterialsScreen>:
    name: "materials"
    MDBoxLayout:
        orientation: "vertical"
        
        # App Bar
        MDTopAppBar:
            title: "Raw Materials"
            left_action_items: [["arrow-left", lambda x: app.go_back()]]
            right_action_items: [["plus", lambda x: app.change_screen("add_material")], ["refresh", lambda x: root.refresh_data()]]
            elevation: 4
        
        # Search Bar
        MDBoxLayout:
            orientation: "horizontal"
            size_hint_y: None
            height: dp(56)
            padding: dp(8)
            
            MDTextField:
                id: search_field
                hint_text: "Search materials..."
                on_text: root.filter_materials(self.text)
                icon_right: "magnify"
                
        # Materials List
        MDScrollView:
            id: scroll_view
            
            MDList:
                id: materials_list
                padding: dp(8)
                
        # Empty State
        MDBoxLayout:
            id: empty_state
            orientation: "vertical"
            padding: dp(16)
            spacing: dp(8)
            size_hint_y: None
            height: dp(200)
            pos_hint: {"center_y": 0.5}
            opacity: 0
            
            MDLabel:
                text: "No Materials Found"
                font_style: "H5"
                halign: "center"
                
            MDLabel:
                text: "Add your first material to get started"
                theme_text_color: "Secondary"
                halign: "center"
                
            MDRaisedButton:
                text: "Add Material"
                pos_hint: {"center_x": 0.5}
                on_press: app.change_screen("add_material")
''')

class MaterialsScreen(MDScreen):
    """
    Screen for displaying and managing raw materials.
    """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.inventory_manager = InventoryManager()
        self.all_materials = []
        self.dialog = None
        
    def on_enter(self):
        """Called when the screen is displayed."""
        self.refresh_data()
        
    def refresh_data(self):
        """Refresh the materials list."""
        # Clear the search field
        self.ids.search_field.text = ""
        
        # Get all materials
        self.all_materials = self.inventory_manager.get_all_materials()
        
        # Refresh the list
        self._update_materials_list(self.all_materials)
    
    def _update_materials_list(self, materials):
        """
        Update the materials list with the provided materials.
        
        Args:
            materials: List of Material objects to display
        """
        # Clear the list
        materials_list = self.ids.materials_list
        materials_list.clear_widgets()
        
        # Update empty state visibility
        if not materials:
            self.ids.empty_state.opacity = 1
            self.ids.scroll_view.opacity = 0
        else:
            self.ids.empty_state.opacity = 0
            self.ids.scroll_view.opacity = 1
            
            # Add each material
            for material in materials:
                # Create list item
                list_item = MaterialListItem(
                    material=material,
                    on_edit=lambda m=material: self._edit_material(m),
                    on_delete=lambda m=material: self._confirm_delete(m)
                )
                
                # Add the list item
                materials_list.add_widget(list_item)
    
    def filter_materials(self, search_text):
        """
        Filter the materials list based on search text.
        
        Args:
            search_text: Text to search for in material names
        """
        if not search_text:
            # If search is empty, show all materials
            self._update_materials_list(self.all_materials)
        else:
            # Filter materials by name
            search_text = search_text.lower()
            filtered_materials = [
                m for m in self.all_materials
                if search_text in m.name.lower()
            ]
            self._update_materials_list(filtered_materials)
    
    def _edit_material(self, material):
        """
        Navigate to the edit screen for a material.
        
        Args:
            material: Material object to edit
        """
        # Prepare data for edit screen
        item_data = {
            'id': material.id,
            'name': material.name,
            'quantity': material.quantity,
            'unit': material.unit,
            'min_quantity': material.min_quantity,
            'cost_per_unit': material.cost_per_unit,
            'type': 'material'
        }
        
        # Navigate to edit screen
        app = self.manager.get_parent_window().children[0]
        app.change_screen("edit_item", item_data=item_data)
    
    def _confirm_delete(self, material):
        """
        Show confirmation dialog before deleting a material.
        
        Args:
            material: Material object to delete
        """
        app = self.manager.get_parent_window().children[0]
        app.show_confirmation_dialog(
            title="Delete Material",
            text=f"Are you sure you want to delete {material.name}? This action cannot be undone.",
            on_confirm=lambda: self._delete_material(material.id)
        )
    
    def _delete_material(self, material_id):
        """
        Delete a material from the inventory.
        
        Args:
            material_id: ID of the material to delete
        """
        success = self.inventory_manager.delete_material(material_id)
        
        if success:
            # Refresh the list
            self.refresh_data()
        else:
            # Show error
            app = self.manager.get_parent_window().children[0]
            app.show_error_dialog(
                title="Error",
                text="Could not delete material. It may be in use by one or more products."
            )
