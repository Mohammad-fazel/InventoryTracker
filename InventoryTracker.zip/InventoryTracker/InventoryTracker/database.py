import sqlite3
import os
from datetime import datetime

class DatabaseManager:
    """
    Manages all database operations for the inventory management system.
    """
    def __init__(self, db_name="inventory.db"):
        """
        Initialize database connection and cursor.
        
        Args:
            db_name (str): Name of the SQLite database file
        """
        # Determine the application directory to store the database
        if getattr(sys, 'frozen', False):
            # Running as a bundled application
            app_dir = os.path.dirname(sys.executable)
        else:
            # Running in a development environment
            app_dir = os.path.dirname(os.path.abspath(__file__))
            
        # Create database path
        self.db_path = os.path.join(app_dir, db_name)
        
        # Initialize connection and cursor as None until needed
        self.conn = None
        self.cursor = None
        
    def _connect(self):
        """
        Create a connection to the SQLite database.
        """
        if self.conn is None:
            self.conn = sqlite3.connect(self.db_path)
            # Enable foreign keys
            self.conn.execute("PRAGMA foreign_keys = ON")
            # Configure connection to return rows as dictionaries
            self.conn.row_factory = sqlite3.Row
            self.cursor = self.conn.cursor()
            
    def _disconnect(self):
        """
        Close the database connection.
        """
        if self.conn:
            self.conn.close()
            self.conn = None
            self.cursor = None
    
    def create_tables(self):
        """
        Create the database tables if they don't exist.
        """
        self._connect()
        
        # Materials table
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS materials (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            quantity REAL NOT NULL,
            unit TEXT NOT NULL,
            min_quantity REAL DEFAULT 0,
            cost_per_unit REAL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        ''')
        
        # Products table
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            quantity INTEGER NOT NULL DEFAULT 0,
            price REAL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        ''')
        
        # Product materials (linking table for materials needed per product)
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS product_materials (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER,
            material_id INTEGER,
            quantity_needed REAL NOT NULL,
            FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
            FOREIGN KEY (material_id) REFERENCES materials(id) ON DELETE CASCADE
        )
        ''')
        
        # Inventory history for tracking changes
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS inventory_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            item_type TEXT NOT NULL,
            item_id INTEGER NOT NULL,
            action TEXT NOT NULL,
            quantity REAL NOT NULL,
            previous_quantity REAL,
            current_quantity REAL,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        ''')
        
        self.conn.commit()
    
    # ---- Material Operations ----
    
    def add_material(self, name, quantity, unit, min_quantity=0, cost_per_unit=0):
        """
        Add a new material to the inventory.
        
        Args:
            name (str): Name of the material
            quantity (float): Initial quantity
            unit (str): Unit of measurement (e.g., kg, pcs)
            min_quantity (float): Minimum quantity threshold for alerts
            cost_per_unit (float): Cost per unit of the material
            
        Returns:
            int: ID of the newly inserted material
        """
        self._connect()
        
        current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        self.cursor.execute('''
        INSERT INTO materials (name, quantity, unit, min_quantity, cost_per_unit, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (name, quantity, unit, min_quantity, cost_per_unit, current_time, current_time))
        
        material_id = self.cursor.lastrowid
        
        # Record in history
        self.cursor.execute('''
        INSERT INTO inventory_history 
        (item_type, item_id, action, quantity, previous_quantity, current_quantity)
        VALUES (?, ?, ?, ?, ?, ?)
        ''', ('material', material_id, 'add', quantity, 0, quantity))
        
        self.conn.commit()
        return material_id
    
    def update_material(self, material_id, name=None, quantity=None, unit=None, 
                        min_quantity=None, cost_per_unit=None):
        """
        Update an existing material.
        
        Args:
            material_id (int): ID of the material to update
            name (str, optional): New name
            quantity (float, optional): New quantity
            unit (str, optional): New unit of measurement
            min_quantity (float, optional): New minimum quantity threshold
            cost_per_unit (float, optional): New cost per unit
            
        Returns:
            bool: True if update was successful
        """
        self._connect()
        
        # Get current material data for history tracking
        self.cursor.execute("SELECT * FROM materials WHERE id = ?", (material_id,))
        current_material = dict(self.cursor.fetchone())
        
        # Build update query dynamically based on provided parameters
        update_fields = []
        params = []
        
        if name is not None:
            update_fields.append("name = ?")
            params.append(name)
        
        if quantity is not None:
            update_fields.append("quantity = ?")
            params.append(quantity)
        
        if unit is not None:
            update_fields.append("unit = ?")
            params.append(unit)
        
        if min_quantity is not None:
            update_fields.append("min_quantity = ?")
            params.append(min_quantity)
        
        if cost_per_unit is not None:
            update_fields.append("cost_per_unit = ?")
            params.append(cost_per_unit)
        
        # Add updated_at timestamp
        update_fields.append("updated_at = ?")
        params.append(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        
        # Add material_id parameter
        params.append(material_id)
        
        # Execute update query
        query = f"UPDATE materials SET {', '.join(update_fields)} WHERE id = ?"
        self.cursor.execute(query, params)
        
        # Record in history if quantity changed
        if quantity is not None and quantity != current_material['quantity']:
            self.cursor.execute('''
            INSERT INTO inventory_history 
            (item_type, item_id, action, quantity, previous_quantity, current_quantity)
            VALUES (?, ?, ?, ?, ?, ?)
            ''', ('material', material_id, 'update', 
                  quantity - current_material['quantity'],  # Change amount
                  current_material['quantity'],  # Previous quantity
                  quantity))  # New quantity
        
        self.conn.commit()
        return True
    
    def delete_material(self, material_id):
        """
        Delete a material from the inventory.
        
        Args:
            material_id (int): ID of the material to delete
            
        Returns:
            bool: True if deletion was successful
        """
        self._connect()
        
        # Get current quantity for history record
        self.cursor.execute("SELECT quantity FROM materials WHERE id = ?", (material_id,))
        result = self.cursor.fetchone()
        
        if not result:
            return False
        
        current_quantity = result['quantity']
        
        # Record in history
        self.cursor.execute('''
        INSERT INTO inventory_history 
        (item_type, item_id, action, quantity, previous_quantity, current_quantity)
        VALUES (?, ?, ?, ?, ?, ?)
        ''', ('material', material_id, 'delete', current_quantity, current_quantity, 0))
        
        # Delete the material
        self.cursor.execute("DELETE FROM materials WHERE id = ?", (material_id,))
        
        self.conn.commit()
        return True
    
    def get_material(self, material_id):
        """
        Get a single material by ID.
        
        Args:
            material_id (int): ID of the material to retrieve
            
        Returns:
            dict: Material data or None if not found
        """
        self._connect()
        
        self.cursor.execute("SELECT * FROM materials WHERE id = ?", (material_id,))
        material = self.cursor.fetchone()
        
        if material:
            return dict(material)
        return None
    
    def get_all_materials(self):
        """
        Get all materials in the inventory.
        
        Returns:
            list: List of material dictionaries
        """
        self._connect()
        
        self.cursor.execute("SELECT * FROM materials ORDER BY name")
        materials = self.cursor.fetchall()
        
        return [dict(material) for material in materials]
    
    def get_low_stock_materials(self):
        """
        Get materials that are below their minimum quantity threshold.
        
        Returns:
            list: List of low stock material dictionaries
        """
        self._connect()
        
        self.cursor.execute("""
        SELECT * FROM materials 
        WHERE quantity <= min_quantity
        ORDER BY name
        """)
        materials = self.cursor.fetchall()
        
        return [dict(material) for material in materials]
    
    # ---- Product Operations ----
    
    def add_product(self, name, price=0, materials_needed=None):
        """
        Add a new product to the inventory with its required materials.
        
        Args:
            name (str): Product name
            price (float): Selling price
            materials_needed (list): List of dictionaries with material_id, quantity_needed
            
        Returns:
            int: ID of the newly created product
        """
        self._connect()
        
        current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        # Create the product with zero initial quantity
        self.cursor.execute('''
        INSERT INTO products (name, quantity, price, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?)
        ''', (name, 0, price, current_time, current_time))
        
        product_id = self.cursor.lastrowid
        
        # Add material requirements if provided
        if materials_needed:
            for material in materials_needed:
                self.cursor.execute('''
                INSERT INTO product_materials (product_id, material_id, quantity_needed)
                VALUES (?, ?, ?)
                ''', (product_id, material['material_id'], material['quantity_needed']))
        
        # Record in history
        self.cursor.execute('''
        INSERT INTO inventory_history 
        (item_type, item_id, action, quantity, previous_quantity, current_quantity)
        VALUES (?, ?, ?, ?, ?, ?)
        ''', ('product', product_id, 'add', 0, 0, 0))
        
        self.conn.commit()
        return product_id
    
    def update_product(self, product_id, name=None, price=None):
        """
        Update product details (not quantity).
        
        Args:
            product_id (int): ID of the product to update
            name (str, optional): New product name
            price (float, optional): New selling price
            
        Returns:
            bool: True if update was successful
        """
        self._connect()
        
        # Build update query dynamically based on provided parameters
        update_fields = []
        params = []
        
        if name is not None:
            update_fields.append("name = ?")
            params.append(name)
        
        if price is not None:
            update_fields.append("price = ?")
            params.append(price)
        
        # Add updated_at timestamp
        update_fields.append("updated_at = ?")
        params.append(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        
        # Add product_id parameter
        params.append(product_id)
        
        # Execute update query
        query = f"UPDATE products SET {', '.join(update_fields)} WHERE id = ?"
        self.cursor.execute(query, params)
        
        self.conn.commit()
        return True
    
    def update_product_materials(self, product_id, materials_needed):
        """
        Update the materials required for a product.
        
        Args:
            product_id (int): ID of the product
            materials_needed (list): List of dictionaries with material_id, quantity_needed
            
        Returns:
            bool: True if update was successful
        """
        self._connect()
        
        # Remove existing material requirements
        self.cursor.execute("DELETE FROM product_materials WHERE product_id = ?", (product_id,))
        
        # Add new material requirements
        for material in materials_needed:
            self.cursor.execute('''
            INSERT INTO product_materials (product_id, material_id, quantity_needed)
            VALUES (?, ?, ?)
            ''', (product_id, material['material_id'], material['quantity_needed']))
        
        self.conn.commit()
        return True
    
    def delete_product(self, product_id):
        """
        Delete a product from the inventory.
        
        Args:
            product_id (int): ID of the product to delete
            
        Returns:
            bool: True if deletion was successful
        """
        self._connect()
        
        # Get current quantity for history record
        self.cursor.execute("SELECT quantity FROM products WHERE id = ?", (product_id,))
        result = self.cursor.fetchone()
        
        if not result:
            return False
        
        current_quantity = result['quantity']
        
        # Record in history
        self.cursor.execute('''
        INSERT INTO inventory_history 
        (item_type, item_id, action, quantity, previous_quantity, current_quantity)
        VALUES (?, ?, ?, ?, ?, ?)
        ''', ('product', product_id, 'delete', current_quantity, current_quantity, 0))
        
        # Delete the product
        self.cursor.execute("DELETE FROM products WHERE id = ?", (product_id,))
        
        self.conn.commit()
        return True
    
    def get_product(self, product_id):
        """
        Get a single product by ID.
        
        Args:
            product_id (int): ID of the product to retrieve
            
        Returns:
            dict: Product data or None if not found
        """
        self._connect()
        
        self.cursor.execute("SELECT * FROM products WHERE id = ?", (product_id,))
        product = self.cursor.fetchone()
        
        if not product:
            return None
        
        product_dict = dict(product)
        
        # Get the materials needed for this product
        self.cursor.execute("""
        SELECT pm.material_id, m.name, pm.quantity_needed, m.unit
        FROM product_materials pm
        JOIN materials m ON pm.material_id = m.id
        WHERE pm.product_id = ?
        """, (product_id,))
        
        materials = self.cursor.fetchall()
        product_dict['materials'] = [dict(material) for material in materials]
        
        return product_dict
    
    def get_all_products(self):
        """
        Get all products in the inventory.
        
        Returns:
            list: List of product dictionaries
        """
        self._connect()
        
        self.cursor.execute("SELECT * FROM products ORDER BY name")
        products = self.cursor.fetchall()
        
        result = []
        for product in products:
            product_dict = dict(product)
            
            # Get the materials needed for this product
            self.cursor.execute("""
            SELECT pm.material_id, m.name, pm.quantity_needed, m.unit
            FROM product_materials pm
            JOIN materials m ON pm.material_id = m.id
            WHERE pm.product_id = ?
            """, (product_dict['id'],))
            
            materials = self.cursor.fetchall()
            product_dict['materials'] = [dict(material) for material in materials]
            
            result.append(product_dict)
        
        return result
    
    def check_material_availability(self, product_id, quantity=1):
        """
        Check if enough materials are available to produce a quantity of products.
        
        Args:
            product_id (int): ID of the product to check
            quantity (int): Number of products to check for
            
        Returns:
            tuple: (bool, list) - Success status and list of materials with insufficient quantity
        """
        self._connect()
        
        # Get materials needed for this product
        self.cursor.execute("""
        SELECT pm.material_id, m.name, pm.quantity_needed, m.quantity as available, m.unit
        FROM product_materials pm
        JOIN materials m ON pm.material_id = m.id
        WHERE pm.product_id = ?
        """, (product_id,))
        
        materials = self.cursor.fetchall()
        insufficient = []
        
        for material in materials:
            needed = material['quantity_needed'] * quantity
            if material['available'] < needed:
                insufficient.append({
                    'id': material['material_id'],
                    'name': material['name'],
                    'needed': needed,
                    'available': material['available'],
                    'unit': material['unit']
                })
        
        return (len(insufficient) == 0, insufficient)
    
    def create_product_batch(self, product_id, quantity):
        """
        Create a batch of products, deducting required materials.
        
        Args:
            product_id (int): ID of the product to create
            quantity (int): Number of products to create
            
        Returns:
            bool: True if product creation was successful
        """
        self._connect()
        
        # Check if enough materials are available
        is_available, _ = self.check_material_availability(product_id, quantity)
        
        if not is_available:
            return False
        
        # Begin transaction
        self.conn.execute("BEGIN TRANSACTION")
        
        try:
            # Get current product quantity
            self.cursor.execute("SELECT quantity FROM products WHERE id = ?", (product_id,))
            current_quantity = self.cursor.fetchone()['quantity']
            
            # Update product quantity
            new_quantity = current_quantity + quantity
            self.cursor.execute("""
            UPDATE products 
            SET quantity = ?, updated_at = ?
            WHERE id = ?
            """, (new_quantity, datetime.now().strftime('%Y-%m-%d %H:%M:%S'), product_id))
            
            # Record product creation in history
            self.cursor.execute('''
            INSERT INTO inventory_history 
            (item_type, item_id, action, quantity, previous_quantity, current_quantity)
            VALUES (?, ?, ?, ?, ?, ?)
            ''', ('product', product_id, 'create', quantity, current_quantity, new_quantity))
            
            # Get and deduct required materials
            self.cursor.execute("""
            SELECT pm.material_id, pm.quantity_needed, m.quantity as available
            FROM product_materials pm
            JOIN materials m ON pm.material_id = m.id
            WHERE pm.product_id = ?
            """, (product_id,))
            
            materials = self.cursor.fetchall()
            
            for material in materials:
                material_id = material['material_id']
                needed = material['quantity_needed'] * quantity
                current_material_qty = material['available']
                new_material_qty = current_material_qty - needed
                
                # Update material quantity
                self.cursor.execute("""
                UPDATE materials 
                SET quantity = ?, updated_at = ?
                WHERE id = ?
                """, (new_material_qty, datetime.now().strftime('%Y-%m-%d %H:%M:%S'), material_id))
                
                # Record material usage in history
                self.cursor.execute('''
                INSERT INTO inventory_history 
                (item_type, item_id, action, quantity, previous_quantity, current_quantity)
                VALUES (?, ?, ?, ?, ?, ?)
                ''', ('material', material_id, 'use', -needed, current_material_qty, new_material_qty))
            
            # Commit transaction
            self.conn.commit()
            return True
            
        except Exception as e:
            # Roll back changes on error
            self.conn.rollback()
            print(f"Error creating product batch: {e}")
            return False
    
    def use_product(self, product_id, quantity):
        """
        Remove products from inventory (e.g., for sales).
        
        Args:
            product_id (int): ID of the product to use
            quantity (int): Number of products to remove
            
        Returns:
            bool: True if product usage was successful
        """
        self._connect()
        
        # Get current product quantity
        self.cursor.execute("SELECT quantity FROM products WHERE id = ?", (product_id,))
        result = self.cursor.fetchone()
        
        if not result:
            return False
        
        current_quantity = result['quantity']
        
        # Check if enough products are available
        if current_quantity < quantity:
            return False
        
        # Update product quantity
        new_quantity = current_quantity - quantity
        self.cursor.execute("""
        UPDATE products 
        SET quantity = ?, updated_at = ?
        WHERE id = ?
        """, (new_quantity, datetime.now().strftime('%Y-%m-%d %H:%M:%S'), product_id))
        
        # Record product usage in history
        self.cursor.execute('''
        INSERT INTO inventory_history 
        (item_type, item_id, action, quantity, previous_quantity, current_quantity)
        VALUES (?, ?, ?, ?, ?, ?)
        ''', ('product', product_id, 'use', -quantity, current_quantity, new_quantity))
        
        self.conn.commit()
        return True
    
    # ---- History and Reporting ----
    
    def get_inventory_history(self, item_type=None, item_id=None, days=30):
        """
        Get inventory history for reporting.
        
        Args:
            item_type (str, optional): Filter by 'material' or 'product'
            item_id (int, optional): Filter by specific item ID
            days (int): Number of days of history to retrieve
            
        Returns:
            list: List of history records
        """
        self._connect()
        
        query = """
        SELECT h.*, 
               CASE 
                   WHEN h.item_type = 'material' THEN m.name 
                   WHEN h.item_type = 'product' THEN p.name 
               END as item_name
        FROM inventory_history h
        LEFT JOIN materials m ON h.item_type = 'material' AND h.item_id = m.id
        LEFT JOIN products p ON h.item_type = 'product' AND h.item_id = p.id
        WHERE timestamp >= date('now', ?)
        """
        params = [f'-{days} days']
        
        if item_type:
            query += " AND h.item_type = ?"
            params.append(item_type)
        
        if item_id:
            query += " AND h.item_id = ?"
            params.append(item_id)
        
        query += " ORDER BY h.timestamp DESC"
        
        self.cursor.execute(query, params)
        history = self.cursor.fetchall()
        
        return [dict(record) for record in history]
    
    def get_inventory_levels_over_time(self, item_type, item_id, days=30):
        """
        Get inventory level history for a specific item.
        
        Args:
            item_type (str): 'material' or 'product'
            item_id (int): ID of the item
            days (int): Number of days of history to retrieve
            
        Returns:
            list: List of quantity records with timestamps
        """
        self._connect()
        
        # This query gets inventory events and calculates a running quantity
        query = """
        WITH timeline AS (
            SELECT timestamp, current_quantity
            FROM inventory_history
            WHERE item_type = ? AND item_id = ?
            AND timestamp >= date('now', ?)
            ORDER BY timestamp
        )
        SELECT timestamp, current_quantity
        FROM timeline
        """
        
        self.cursor.execute(query, (item_type, item_id, f'-{days} days'))
        levels = self.cursor.fetchall()
        
        return [dict(record) for record in levels]
    
    def get_dashboard_stats(self):
        """
        Get summary statistics for the dashboard.
        
        Returns:
            dict: Statistics including total materials, products, etc.
        """
        self._connect()
        
        stats = {}
        
        # Count total materials
        self.cursor.execute("SELECT COUNT(*) as count FROM materials")
        stats['total_materials'] = self.cursor.fetchone()['count']
        
        # Count low stock materials
        self.cursor.execute("SELECT COUNT(*) as count FROM materials WHERE quantity <= min_quantity")
        stats['low_stock_materials'] = self.cursor.fetchone()['count']
        
        # Count total products
        self.cursor.execute("SELECT COUNT(*) as count FROM products")
        stats['total_products'] = self.cursor.fetchone()['count']
        
        # Count products with zero inventory
        self.cursor.execute("SELECT COUNT(*) as count FROM products WHERE quantity = 0")
        stats['out_of_stock_products'] = self.cursor.fetchone()['count']
        
        # Get total inventory value (materials)
        self.cursor.execute("SELECT SUM(quantity * cost_per_unit) as value FROM materials")
        result = self.cursor.fetchone()
        stats['materials_value'] = result['value'] if result['value'] is not None else 0
        
        # Get total inventory value (products)
        self.cursor.execute("SELECT SUM(quantity * price) as value FROM products")
        result = self.cursor.fetchone()
        stats['products_value'] = result['value'] if result['value'] is not None else 0
        
        # Recent activity
        self.cursor.execute("""
        SELECT h.*, 
               CASE 
                   WHEN h.item_type = 'material' THEN m.name 
                   WHEN h.item_type = 'product' THEN p.name 
               END as item_name
        FROM inventory_history h
        LEFT JOIN materials m ON h.item_type = 'material' AND h.item_id = m.id
        LEFT JOIN products p ON h.item_type = 'product' AND h.item_id = p.id
        ORDER BY h.timestamp DESC
        LIMIT 5
        """)
        stats['recent_activity'] = [dict(record) for record in self.cursor.fetchall()]
        
        return stats
