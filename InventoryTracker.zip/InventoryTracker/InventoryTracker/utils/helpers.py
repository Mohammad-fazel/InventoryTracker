"""
Helper functions used throughout the application.
"""
import re
from datetime import datetime

def format_currency(value, symbol="$", decimal_places=2):
    """
    Format a number as currency.
    
    Args:
        value (float): The value to format
        symbol (str): Currency symbol to use
        decimal_places (int): Number of decimal places to show
        
    Returns:
        str: Formatted currency string
    """
    return f"{symbol}{value:.{decimal_places}f}"

def format_quantity(quantity, unit=""):
    """
    Format a quantity with its unit.
    
    Args:
        quantity (float): The quantity to format
        unit (str): Unit of measurement
        
    Returns:
        str: Formatted quantity string
    """
    # Use whole numbers for integer quantities
    if quantity == int(quantity):
        formatted = f"{int(quantity)}"
    else:
        formatted = f"{quantity:.2f}"
    
    if unit:
        formatted += f" {unit}"
    
    return formatted

def parse_quantity(text):
    """
    Parse a quantity string to a float.
    
    Args:
        text (str): Text to parse
        
    Returns:
        float: Parsed quantity or 0 if invalid
    """
    try:
        # Remove any non-numeric characters except decimal point
        clean_text = re.sub(r'[^\d.]', '', text)
        return float(clean_text)
    except (ValueError, TypeError):
        return 0.0

def format_datetime(dt, include_time=True):
    """
    Format a datetime object as a string.
    
    Args:
        dt: Datetime object or string
        include_time (bool): Whether to include time in the output
        
    Returns:
        str: Formatted datetime string
    """
    if isinstance(dt, str):
        try:
            dt = datetime.strptime(dt, '%Y-%m-%d %H:%M:%S')
        except ValueError:
            return dt
    
    if not dt:
        return ""
    
    if include_time:
        return dt.strftime('%Y-%m-%d %H:%M:%S')
    else:
        return dt.strftime('%Y-%m-%d')

def calculate_days_difference(date_str):
    """
    Calculate the number of days between a date string and today.
    
    Args:
        date_str (str): Date string in format '%Y-%m-%d %H:%M:%S'
        
    Returns:
        int: Number of days difference
    """
    try:
        date = datetime.strptime(date_str, '%Y-%m-%d %H:%M:%S')
        today = datetime.now()
        delta = today - date
        return delta.days
    except (ValueError, TypeError):
        return 0

def validate_input(text, input_type="text", allow_empty=False):
    """
    Validate user input based on type.
    
    Args:
        text (str): Text to validate
        input_type (str): Type of input ('text', 'number', 'email', etc.)
        allow_empty (bool): Whether empty input is allowed
        
    Returns:
        tuple: (is_valid, error_message)
    """
    if not text and not allow_empty:
        return False, "This field is required."
    
    if not text and allow_empty:
        return True, ""
    
    if input_type == "number":
        try:
            float(text)
            return True, ""
        except ValueError:
            return False, "Please enter a valid number."
    
    elif input_type == "email":
        email_regex = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        if re.match(email_regex, text):
            return True, ""
        else:
            return False, "Please enter a valid email address."
    
    elif input_type == "phone":
        # Simple phone validation (adjust based on your requirements)
        phone_regex = r'^\+?[0-9]{10,15}$'
        if re.match(phone_regex, text):
            return True, ""
        else:
            return False, "Please enter a valid phone number."
    
    # Default case for text
    return True, ""

def truncate_text(text, max_length=50):
    """
    Truncate text if it exceeds the maximum length.
    
    Args:
        text (str): Text to truncate
        max_length (int): Maximum length before truncation
        
    Returns:
        str: Truncated text
    """
    if not text:
        return ""
    
    if len(text) <= max_length:
        return text
    
    return text[:max_length-3] + "..."

def get_status_color(status):
    """
    Get a color based on status.
    
    Args:
        status (str): Status string (e.g., 'low', 'normal', 'high')
        
    Returns:
        list: RGBA color values
    """
    status = status.lower()
    
    if status == "low" or status == "error":
        return [0.9, 0.3, 0.3, 1.0]  # Red
    elif status == "medium" or status == "warning":
        return [1.0, 0.6, 0.0, 1.0]  # Orange
    elif status == "high" or status == "success":
        return [0.3, 0.7, 0.3, 1.0]  # Green
    else:
        return [0.3, 0.3, 0.9, 1.0]  # Blue (default)
