"""
Constants used throughout the application.
"""

# App information
APP_NAME = "Inventory Manager"
APP_VERSION = "1.0.0"

# Database
DEFAULT_DB_NAME = "inventory.db"

# Material units
COMMON_UNITS = [
    "pcs",  # pieces
    "kg",   # kilograms
    "g",    # grams
    "l",    # liters
    "ml",   # milliliters
    "m",    # meters
    "cm",   # centimeters
    "m²",   # square meters
    "m³",   # cubic meters
    "box",  # boxes
    "roll", # rolls
    "sheet" # sheets
]

# Inventory actions
ACTIONS = {
    "ADD": "add",
    "UPDATE": "update",
    "DELETE": "delete",
    "CREATE": "create",
    "USE": "use"
}

# Item types
ITEM_TYPES = {
    "MATERIAL": "material",
    "PRODUCT": "product"
}

# Colors
COLORS = {
    "PRIMARY": "#2196F3",     # Blue
    "SECONDARY": "#FFC107",   # Amber
    "SUCCESS": "#4CAF50",     # Green
    "WARNING": "#FF9800",     # Orange
    "ERROR": "#F44336",       # Red
    "INFO": "#00BCD4",        # Cyan
    "LIGHT": "#F5F5F5",       # Light Gray
    "DARK": "#212121",        # Dark Gray
    "LOW_STOCK": "#FFCDD2",   # Light Red
    "OUT_OF_STOCK": "#FFCDD2" # Light Red
}

# Styles
THEME = {
    "PRIMARY_PALETTE": "Blue",
    "ACCENT_PALETTE": "Amber",
    "THEME_STYLE": "Light"
}

# Chart settings
CHART_SETTINGS = {
    "DEFAULT_DAYS": 30,
    "MAX_ITEMS_IN_CHART": 10,
    "CHART_WIDTH": 800,
    "CHART_HEIGHT": 600,
    "CHART_DPI": 100
}
