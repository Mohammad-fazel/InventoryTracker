from dataclasses import dataclass
from typing import List, Dict, Optional, Union
from datetime import datetime

@dataclass
class Material:
    """Represents a raw material in the inventory."""
    id: Optional[int] = None
    name: str = ""
    quantity: float = 0.0
    unit: str = ""
    min_quantity: float = 0.0
    cost_per_unit: float = 0.0
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'Material':
        """Create a Material instance from a dictionary."""
        return cls(
            id=data.get('id'),
            name=data.get('name', ''),
            quantity=float(data.get('quantity', 0.0)),
            unit=data.get('unit', ''),
            min_quantity=float(data.get('min_quantity', 0.0)),
            cost_per_unit=float(data.get('cost_per_unit', 0.0)),
            created_at=data.get('created_at'),
            updated_at=data.get('updated_at')
        )
    
    def to_dict(self) -> Dict:
        """Convert Material instance to a dictionary."""
        return {
            'id': self.id,
            'name': self.name,
            'quantity': self.quantity,
            'unit': self.unit,
            'min_quantity': self.min_quantity,
            'cost_per_unit': self.cost_per_unit,
            'created_at': self.created_at,
            'updated_at': self.updated_at
        }
    
    @property
    def total_value(self) -> float:
        """Calculate the total value of this material."""
        return self.quantity * self.cost_per_unit
    
    @property
    def is_low_stock(self) -> bool:
        """Check if the material is below minimum stock level."""
        return self.quantity <= self.min_quantity

@dataclass
class ProductMaterial:
    """Represents a material requirement for a product."""
    material_id: int
    name: str = ""
    quantity_needed: float = 0.0
    unit: str = ""
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'ProductMaterial':
        """Create a ProductMaterial instance from a dictionary."""
        return cls(
            material_id=data.get('material_id'),
            name=data.get('name', ''),
            quantity_needed=float(data.get('quantity_needed', 0.0)),
            unit=data.get('unit', '')
        )
    
    def to_dict(self) -> Dict:
        """Convert ProductMaterial instance to a dictionary."""
        return {
            'material_id': self.material_id,
            'name': self.name,
            'quantity_needed': self.quantity_needed,
            'unit': self.unit
        }

@dataclass
class Product:
    """Represents a finished product in the inventory."""
    id: Optional[int] = None
    name: str = ""
    quantity: int = 0
    price: float = 0.0
    materials: List[ProductMaterial] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    
    def __post_init__(self):
        """Initialize materials list if None."""
        if self.materials is None:
            self.materials = []
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'Product':
        """Create a Product instance from a dictionary."""
        materials = []
        if 'materials' in data:
            materials = [ProductMaterial.from_dict(m) for m in data['materials']]
            
        return cls(
            id=data.get('id'),
            name=data.get('name', ''),
            quantity=int(data.get('quantity', 0)),
            price=float(data.get('price', 0.0)),
            materials=materials,
            created_at=data.get('created_at'),
            updated_at=data.get('updated_at')
        )
    
    def to_dict(self) -> Dict:
        """Convert Product instance to a dictionary."""
        return {
            'id': self.id,
            'name': self.name,
            'quantity': self.quantity,
            'price': self.price,
            'materials': [m.to_dict() for m in self.materials],
            'created_at': self.created_at,
            'updated_at': self.updated_at
        }
    
    @property
    def total_value(self) -> float:
        """Calculate the total value of this product inventory."""
        return self.quantity * self.price
    
    @property
    def is_out_of_stock(self) -> bool:
        """Check if the product is out of stock."""
        return self.quantity <= 0

@dataclass
class InventoryHistoryRecord:
    """Represents a record in the inventory history."""
    id: Optional[int] = None
    item_type: str = ""  # 'material' or 'product'
    item_id: int = 0
    item_name: str = ""  # Not stored in DB, but included for display
    action: str = ""  # 'add', 'update', 'delete', 'create', 'use'
    quantity: float = 0.0
    previous_quantity: float = 0.0
    current_quantity: float = 0.0
    timestamp: Optional[datetime] = None
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'InventoryHistoryRecord':
        """Create an InventoryHistoryRecord instance from a dictionary."""
        return cls(
            id=data.get('id'),
            item_type=data.get('item_type', ''),
            item_id=data.get('item_id', 0),
            item_name=data.get('item_name', ''),
            action=data.get('action', ''),
            quantity=float(data.get('quantity', 0.0)),
            previous_quantity=float(data.get('previous_quantity', 0.0)),
            current_quantity=float(data.get('current_quantity', 0.0)),
            timestamp=data.get('timestamp')
        )
    
    def to_dict(self) -> Dict:
        """Convert InventoryHistoryRecord instance to a dictionary."""
        return {
            'id': self.id,
            'item_type': self.item_type,
            'item_id': self.item_id,
            'item_name': self.item_name,
            'action': self.action,
            'quantity': self.quantity,
            'previous_quantity': self.previous_quantity,
            'current_quantity': self.current_quantity,
            'timestamp': self.timestamp
        }
    
    @property
    def action_description(self) -> str:
        """Get a human-readable description of the action."""
        if self.action == 'add':
            return f"Added {abs(self.quantity)} of {self.item_name}"
        elif self.action == 'update':
            if self.quantity > 0:
                return f"Increased {self.item_name} by {abs(self.quantity)}"
            else:
                return f"Decreased {self.item_name} by {abs(self.quantity)}"
        elif self.action == 'delete':
            return f"Deleted {self.item_name}"
        elif self.action == 'create':
            return f"Created {abs(self.quantity)} units of {self.item_name}"
        elif self.action == 'use':
            return f"Used {abs(self.quantity)} units of {self.item_name}"
        return f"{self.action.capitalize()} {self.item_name}"

@dataclass
class DashboardStats:
    """Represents summary statistics for the dashboard."""
    total_materials: int = 0
    low_stock_materials: int = 0
    total_products: int = 0
    out_of_stock_products: int = 0
    materials_value: float = 0.0
    products_value: float = 0.0
    recent_activity: List[InventoryHistoryRecord] = None
    
    def __post_init__(self):
        """Initialize recent_activity list if None."""
        if self.recent_activity is None:
            self.recent_activity = []
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'DashboardStats':
        """Create a DashboardStats instance from a dictionary."""
        recent_activity = []
        if 'recent_activity' in data:
            recent_activity = [InventoryHistoryRecord.from_dict(r) for r in data['recent_activity']]
            
        return cls(
            total_materials=data.get('total_materials', 0),
            low_stock_materials=data.get('low_stock_materials', 0),
            total_products=data.get('total_products', 0),
            out_of_stock_products=data.get('out_of_stock_products', 0),
            materials_value=float(data.get('materials_value', 0.0)),
            products_value=float(data.get('products_value', 0.0)),
            recent_activity=recent_activity
        )
    
    @property
    def total_inventory_value(self) -> float:
        """Calculate the total value of all inventory."""
        return self.materials_value + self.products_value
