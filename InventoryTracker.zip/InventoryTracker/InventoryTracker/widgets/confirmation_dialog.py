from kivy.lang import Builder
from kivy.metrics import dp
from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDFlatButton
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.label import MDLabel

# Define the KV language string for the confirmation dialog
Builder.load_string('''
<ConfirmationContent>:
    orientation: "vertical"
    size_hint_y: None
    height: self.minimum_height
    padding: dp(20)
    spacing: dp(10)
    
    MDLabel:
        id: message_label
        text: root.message
        size_hint_y: None
        height: self.texture_size[1]
        valign: "top"
''')

class ConfirmationContent(MDBoxLayout):
    """Content widget for the confirmation dialog."""
    def __init__(self, message="", **kwargs):
        super().__init__(**kwargs)
        self.message = message

class ConfirmationDialog:
    """
    A utility class to display confirmation dialogs.
    """
    def __init__(self):
        self.dialog = None
    
    def show(self, title, message, on_confirm, on_cancel=None):
        """
        Show a confirmation dialog.
        
        Args:
            title (str): Dialog title
            message (str): Dialog message
            on_confirm (callable): Function to call when confirmed
            on_cancel (callable, optional): Function to call when canceled
        """
        if self.dialog:
            self.dialog.dismiss()
            self.dialog = None
        
        # Create content
        content = ConfirmationContent(message=message)
        
        # Create buttons
        buttons = [
            MDFlatButton(
                text="CANCEL",
                on_release=lambda x: self._on_cancel(on_cancel)
            ),
            MDFlatButton(
                text="CONFIRM",
                on_release=lambda x: self._on_confirm(on_confirm)
            )
        ]
        
        # Create dialog
        self.dialog = MDDialog(
            title=title,
            type="custom",
            content_cls=content,
            buttons=buttons
        )
        
        self.dialog.open()
    
    def _on_confirm(self, callback):
        """Handle confirm button press."""
        self.dialog.dismiss()
        self.dialog = None
        if callback:
            callback()
    
    def _on_cancel(self, callback):
        """Handle cancel button press."""
        self.dialog.dismiss()
        self.dialog = None
        if callback:
            callback()
