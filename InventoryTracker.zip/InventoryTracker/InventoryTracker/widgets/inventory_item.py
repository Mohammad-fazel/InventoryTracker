from kivy.lang import Builder
from kivy.metrics import dp
from kivymd.uix.card import MDCard
from kivymd.uix.button import MDIconButton
from kivymd.uix.label import MDLabel
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.menu import MDDropdownMenu
from kivy.properties import ObjectProperty, StringProperty, BooleanProperty, NumericProperty

# Define the KV language string for the inventory item widgets
Builder.load_string('''
<MaterialListItem>:
    orientation: "vertical"
    size_hint_y: None
    height: dp(120)
    padding: dp(8)
    spacing: dp(4)
    
    MDBoxLayout:
        orientation: "horizontal"
        size_hint_y: None
        height: dp(40)
        
        MDLabel:
            id: name_label
            text: root.material.name
            font_style: "H6"
            size_hint_x: 0.8
            
        MDIconButton:
            icon: "dots-vertical"
            size_hint_x: 0.2
            on_release: root.show_menu(self)
    
    MDBoxLayout:
        orientation: "horizontal"
        size_hint_y: None
        height: dp(20)
        
        MDLabel:
            text: f"Quantity: {root.material.quantity} {root.material.unit}"
            theme_text_color: "Secondary"
    
    MDBoxLayout:
        orientation: "horizontal"
        size_hint_y: None
        height: dp(20)
        
        MDLabel:
            text: f"Minimum: {root.material.min_quantity} {root.material.unit}"
            theme_text_color: "Secondary"
    
    MDBoxLayout:
        orientation: "horizontal"
        size_hint_y: None
        height: dp(20)
        
        MDLabel:
            text: f"Cost: ${root.material.cost_per_unit:.2f} per {root.material.unit}"
            theme_text_color: "Secondary"
            
        MDLabel:
            text: f"Value: ${root.material.total_value:.2f}" if root.material.quantity > 0 else "Value: $0.00"
            theme_text_color: "Secondary"
            halign: "right"

<ProductListItem>:
    orientation: "vertical"
    size_hint_y: None
    height: dp(160)
    padding: dp(8)
    spacing: dp(4)
    
    MDBoxLayout:
        orientation: "horizontal"
        size_hint_y: None
        height: dp(40)
        
        MDLabel:
            id: name_label
            text: root.product.name
            font_style: "H6"
            size_hint_x: 0.8
            
        MDIconButton:
            icon: "dots-vertical"
            size_hint_x: 0.2
            on_release: root.show_menu(self)
    
    MDBoxLayout:
        orientation: "horizontal"
        size_hint_y: None
        height: dp(20)
        
        MDLabel:
            text: f"Quantity: {root.product.quantity} units"
            theme_text_color: "Secondary"
    
    MDBoxLayout:
        orientation: "horizontal"
        size_hint_y: None
        height: dp(20)
        
        MDLabel:
            text: f"Price: ${root.product.price:.2f} per unit"
            theme_text_color: "Secondary"
            
        MDLabel:
            text: f"Value: ${root.product.total_value:.2f}" if root.product.quantity > 0 else "Value: $0.00"
            theme_text_color: "Secondary"
            halign: "right"
    
    MDLabel:
        text: "Materials Needed:"
        theme_text_color: "Secondary"
        size_hint_y: None
        height: dp(20)
        
    MDBoxLayout:
        id: materials_container
        orientation: "vertical"
        size_hint_y: None
        height: dp(50)
        padding: [dp(16), 0, 0, 0]
''')

class MaterialListItem(MDCard):
    """Widget for displaying a material in a list."""
    material = ObjectProperty()
    
    def __init__(self, material, on_edit=None, on_delete=None, **kwargs):
        super().__init__(**kwargs)
        self.material = material
        self.on_edit = on_edit
        self.on_delete = on_delete
        
        # Set the background color based on stock level
        if self.material.is_low_stock:
            self.md_bg_color = [0.9, 0.7, 0.7, 1]  # Light red for low stock
    
    def show_menu(self, button):
        """Show the options menu for this material."""
        menu_items = [
            {
                "text": "Edit",
                "viewclass": "OneLineListItem",
                "on_release": self._edit_material,
            },
            {
                "text": "Delete",
                "viewclass": "OneLineListItem",
                "on_release": self._delete_material,
            }
        ]
        
        self.menu = MDDropdownMenu(
            caller=button,
            items=menu_items,
            width_mult=3,
        )
        self.menu.open()
    
    def _edit_material(self, *args):
        """Call the edit callback."""
        self.menu.dismiss()
        if self.on_edit:
            self.on_edit()
    
    def _delete_material(self, *args):
        """Call the delete callback."""
        self.menu.dismiss()
        if self.on_delete:
            self.on_delete()

class ProductListItem(MDCard):
    """Widget for displaying a product in a list."""
    product = ObjectProperty()
    
    def __init__(self, product, on_edit=None, on_delete=None, on_create=None, on_use=None, **kwargs):
        super().__init__(**kwargs)
        self.product = product
        self.on_edit = on_edit
        self.on_delete = on_delete
        self.on_create = on_create
        self.on_use = on_use
        
        # Set the background color based on stock level
        if self.product.is_out_of_stock:
            self.md_bg_color = [0.9, 0.7, 0.7, 1]  # Light red for out of stock
            
        # Add material requirements to the container
        container = self.ids.materials_container
        for material in self.product.materials[:3]:  # Show max 3 materials
            label = MDLabel(
                text=f"• {material.name}: {material.quantity_needed} {material.unit}",
                theme_text_color="Secondary",
                size_hint_y=None,
                height=dp(16)
            )
            container.add_widget(label)
            
        # If there are more materials, show a "more" indicator
        if len(self.product.materials) > 3:
            more_label = MDLabel(
                text=f"• ... {len(self.product.materials) - 3} more materials",
                theme_text_color="Secondary",
                size_hint_y=None,
                height=dp(16)
            )
            container.add_widget(more_label)
    
    def show_menu(self, button):
        """Show the options menu for this product."""
        menu_items = [
            {
                "text": "Create Batch",
                "viewclass": "OneLineListItem",
                "on_release": self._create_product,
            },
            {
                "text": "Use Product",
                "viewclass": "OneLineListItem",
                "on_release": self._use_product,
            },
            {
                "text": "Edit",
                "viewclass": "OneLineListItem",
                "on_release": self._edit_product,
            },
            {
                "text": "Delete",
                "viewclass": "OneLineListItem",
                "on_release": self._delete_product,
            }
        ]
        
        self.menu = MDDropdownMenu(
            caller=button,
            items=menu_items,
            width_mult=3,
        )
        self.menu.open()
    
    def _create_product(self, *args):
        """Call the create callback."""
        self.menu.dismiss()
        if self.on_create:
            self.on_create()
    
    def _use_product(self, *args):
        """Call the use callback."""
        self.menu.dismiss()
        if self.on_use:
            self.on_use()
    
    def _edit_product(self, *args):
        """Call the edit callback."""
        self.menu.dismiss()
        if self.on_edit:
            self.on_edit()
    
    def _delete_product(self, *args):
        """Call the delete callback."""
        self.menu.dismiss()
        if self.on_delete:
            self.on_delete()
