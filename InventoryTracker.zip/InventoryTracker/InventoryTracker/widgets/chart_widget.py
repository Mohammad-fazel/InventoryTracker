from kivy.lang import Builder
from kivy.uix.image import Image
from kivy.core.image import Image as CoreImage
from kivy.metrics import dp
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.spinner import MDSpinner
from kivymd.uix.label import MDLabel
from io import BytesIO

# Define the KV language string for the chart widget
Builder.load_string('''
<ChartWidget>:
    orientation: "vertical"
    
    Image:
        id: chart_image
        size_hint_y: None
        height: dp(300)
        allow_stretch: True
        keep_ratio: True
        
    MDSpinner:
        id: loading_spinner
        size_hint: None, None
        size: dp(46), dp(46)
        pos_hint: {'center_x': .5, 'center_y': .5}
        active: False
        
    MDLabel:
        id: error_label
        text: "No data available"
        halign: "center"
        valign: "middle"
        opacity: 0
''')

class ChartWidget(MDBoxLayout):
    """Widget for displaying a chart image."""
    def __init__(self, chart_data=None, **kwargs):
        super().__init__(**kwargs)
        self.chart_data = chart_data
        
        # Schedule the chart loading after initialization
        from kivy.clock import Clock
        Clock.schedule_once(lambda dt: self.load_chart())
    
    def load_chart(self):
        """Load and display the chart."""
        # Show loading spinner
        self.ids.loading_spinner.active = True
        self.ids.error_label.opacity = 0
        
        # Schedule actual loading (to allow UI to update)
        from kivy.clock import Clock
        Clock.schedule_once(self._load_chart_data, 0.1)
    
    def _load_chart_data(self, dt):
        """Load chart data and display it."""
        try:
            if self.chart_data:
                # Convert binary data to kivy image
                buf = BytesIO(self.chart_data)
                coreimg = CoreImage(buf, ext="png")
                self.ids.chart_image.texture = coreimg.texture
                self.ids.chart_image.opacity = 1
                self.ids.error_label.opacity = 0
            else:
                # Show error if no data
                self.ids.chart_image.opacity = 0
                self.ids.error_label.opacity = 1
        except Exception as e:
            # Show error on failure
            print(f"Error loading chart: {e}")
            self.ids.chart_image.opacity = 0
            self.ids.error_label.text = "Error loading chart"
            self.ids.error_label.opacity = 1
        
        # Hide loading spinner
        self.ids.loading_spinner.active = False
