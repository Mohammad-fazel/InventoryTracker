from kivy.lang import Builder
from kivy.metrics import dp
from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDFlatButton
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.label import MDLabel

# Define the KV language string for the error dialog
Builder.load_string('''
<ErrorContent>:
    orientation: "vertical"
    size_hint_y: None
    height: self.minimum_height
    padding: dp(20)
    spacing: dp(10)
    
    MDLabel:
        id: message_label
        text: root.message
        size_hint_y: None
        height: self.texture_size[1]
        valign: "top"
''')

class ErrorContent(MDBoxLayout):
    """Content widget for the error dialog."""
    def __init__(self, message="", **kwargs):
        super().__init__(**kwargs)
        self.message = message

class ErrorDialog:
    """
    A utility class to display error dialogs.
    """
    def __init__(self):
        self.dialog = None
    
    def show(self, title, message, on_dismiss=None):
        """
        Show an error dialog.
        
        Args:
            title (str): Dialog title
            message (str): Error message
            on_dismiss (callable, optional): Function to call when dismissed
        """
        if self.dialog:
            self.dialog.dismiss()
            self.dialog = None
        
        # Create content
        content = ErrorContent(message=message)
        
        # Create buttons
        buttons = [
            MDFlatButton(
                text="OK",
                on_release=lambda x: self._on_dismiss(on_dismiss)
            )
        ]
        
        # Create dialog
        self.dialog = MDDialog(
            title=title,
            type="custom",
            content_cls=content,
            buttons=buttons
        )
        
        self.dialog.open()
    
    def _on_dismiss(self, callback):
        """Handle dismiss button press."""
        self.dialog.dismiss()
        self.dialog = None
        if callback:
            callback()
