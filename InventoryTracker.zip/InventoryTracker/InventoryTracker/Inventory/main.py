from kivymd.app import MDApp
from kivy.core.text import LabelBase
from ui.screens.main_screen import MainScreen

class InventoryApp(MDApp):
    def build(self):
        # تنظیم تم و فونت فارسی
        self.theme_cls.theme_style = "Light"
        self.theme_cls.primary_palette = "Teal"
        
        # ثبت فونت فارسی
        LabelBase.register(
            name='Vazir',
            fn_regular='assets/fonts/Vazir.ttf'
        )
        
        return MainScreen()

if __name__ == '__main__':
    InventoryApp().run()