from datetime import datetime, timedelta
from core.database import InventoryDB

class InventoryManager:
    def __init__(self):
        self.db = InventoryDB()
    
    def add_material(self, name, quantity, unit):
        material = RawMaterial(
            name=name,
            quantity=quantity,
            unit=unit
        )
        self.db.add_material(material)
    
    def get_inventory_status(self):
        materials = self.db.get_raw_materials()
        products = self.db.get_finished_products()
        
        return {
            'materials': materials,
            'products': products,
            'last_updated': datetime.now()
        }
    
    # سایر متدهای مدیریت انبار...