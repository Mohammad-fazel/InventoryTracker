from dataclasses import dataclass
from datetime import datetime

@dataclass
class RawMaterial:
    id: int = None
    name: str = ""
    quantity: float = 0.0
    unit: str = "عدد"
    min_stock_level: float = None
    last_updated: datetime = None

@dataclass
class FinishedProduct:
    id: int = None
    name: str = ""
    quantity: int = 0
    last_updated: datetime = None

@dataclass
class InventoryOperation:
    id: int = None
    type: str = ""
    item_id: int = None
    amount: float = 0.0
    timestamp: datetime = None
    notes: str = None