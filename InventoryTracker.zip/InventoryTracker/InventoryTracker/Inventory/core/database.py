import sqlite3
from datetime import datetime
from core.models import RawMaterial, FinishedProduct

class InventoryDB:
    def __init__(self, db_name='inventory.db'):
        self.conn = sqlite3.connect(db_name)
        self._create_tables()
    
    def _create_tables(self):
        cursor = self.conn.cursor()
        
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS raw_materials (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            quantity REAL NOT NULL,
            unit TEXT NOT NULL,
            min_stock_level REAL,
            last_updated TEXT
        )''')
        
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS finished_products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            quantity INTEGER NOT NULL,
            last_updated TEXT
        )''')
        
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS operations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            type TEXT NOT NULL,
            item_id INTEGER,
            amount REAL,
            timestamp TEXT,
            notes TEXT
        )''')
        
        self.conn.commit()
    
    def add_material(self, material: RawMaterial):
        cursor = self.conn.cursor()
        cursor.execute('''
        INSERT INTO raw_materials 
        (name, quantity, unit, min_stock_level, last_updated)
        VALUES (?, ?, ?, ?, ?)
        ''', (
            material.name,
            material.quantity,
            material.unit,
            material.min_stock_level,
            datetime.now().isoformat()
        ))
        self.conn.commit()
    
    def get_raw_materials(self):
        cursor = self.conn.cursor()
        cursor.execute('SELECT * FROM raw_materials')
        return [
            RawMaterial(*row) for row in cursor.fetchall()
        ]
    
    # سایر متدها...