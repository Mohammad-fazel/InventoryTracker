from kivymd.uix.screen import MDScreen
from kivymd.uix.tab import MDTabs
from ui.screens.inventory import InventoryScreen
from ui.screens.charts import ChartsScreen
from ui.screens.operations import OperationsScreen

class MainScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._setup_tabs()
    
    def _setup_tabs(self):
        tabs = MDTabs()
        tabs.add_widget(InventoryScreen(name='inventory'))
        tabs.add_widget(ChartsScreen(name='charts'))
        tabs.add_widget(OperationsScreen(name='operations'))
        self.add_widget(tabs)