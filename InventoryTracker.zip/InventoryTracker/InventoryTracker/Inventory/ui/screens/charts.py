from kivymd.uix.screen import MDScreen
from kivy.uix.boxlayout import BoxLayout
import matplotlib.pyplot as plt
from io import BytesIO
from kivy.core.image import Image as CoreImage
from core.inventory import InventoryManager

class ChartsScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.inventory = InventoryManager()
        self._setup_charts()
    
    def _setup_charts(self):
        layout = BoxLayout(orientation='vertical')
        
        # ایجاد نمودار مصرف مواد
        plt.figure(figsize=(8, 4))
        data = self.inventory.get_consumption_data(30)
        plt.plot(data['dates'], data['amounts'], color='red')
        plt.title('مصرف مواد در 30 روز گذشته')
        
        # ذخیره نمودار
        buf = BytesIO()
        plt.savefig(buf, format='png')
        buf.seek(0)
        
        # نمایش نمودار
        chart_image = CoreImage(BytesIO(buf.read()), ext='png')
        image_widget = CoreImage(texture=chart_image.texture)
        layout.add_widget(image_widget)
        
        self.add_widget(layout)