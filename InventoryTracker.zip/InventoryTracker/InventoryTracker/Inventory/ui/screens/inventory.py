from kivymd.uix.screen import MDScreen
from kivymd.uix.datatables import MDDataTable
from kivy.metrics import dp
from core.inventory import InventoryManager

class InventoryScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.inventory = InventoryManager()
        self._setup_ui()
    
    def _setup_ui(self):
        data = self.inventory.get_inventory_status()
        
        self.data_table = MDDataTable(
            size_hint=(1, 1),
            column_data=[
                ("ID", dp(20)),
                ("نام", dp(40)),
                ("مقدار", dp(30)),
                ("واحد", dp(20))
            ],
            row_data=self._prepare_data(data['materials'])
        )
        self.add_widget(self.data_table)
    
    def _prepare_data(self, items):
        return [
            (item.id, item.name, str(item.quantity), item.unit)
            for item in items
        ]