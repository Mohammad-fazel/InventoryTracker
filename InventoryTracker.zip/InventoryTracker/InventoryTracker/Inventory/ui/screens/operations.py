from kivymd.uix.screen import MDScreen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.button import MDRaisedButton
from kivymd.uix.textfield import MDTextField

class OperationsScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._setup_form()
    
    def _setup_form(self):
        layout = MDBoxLayout(orientation='vertical', padding=20, spacing=15)
        
        self.product_name = MDTextField(
            hint_text="نام محصول",
            font_name='Vazir'
        )
        
        self.quantity = MDTextField(
            hint_text="تعداد",
            input_filter='int'
        )
        
        submit_btn = MDRaisedButton(
            text="ثبت تولید",
            on_release=self._submit_production
        )
        
        layout.add_widget(self.product_name)
        layout.add_widget(self.quantity)
        layout.add_widget(submit_btn)
        self.add_widget(layout)
    
    def _submit_production(self, *args):
        # منطق ثبت تولید
        pass