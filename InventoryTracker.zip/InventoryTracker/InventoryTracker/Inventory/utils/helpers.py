from datetime import datetime

def persian_number(number):
    """تبدیل اعداد انگلیسی به فارسی"""
    persian_nums = ('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹')
    return ''.join(persian_nums[int(d)] for d in str(number))

def format_date(date_obj):
    """قالب‌بندی تاریخ به صورت خوانا"""
    return date_obj.strftime('%Y/%m/%d %H:%M')

def validate_material_data(data):
    """اعتبارسنجی داده‌های مواد اولیه"""
    required_fields = ['name', 'quantity', 'unit']
    return all(field in data for field in required_fields)