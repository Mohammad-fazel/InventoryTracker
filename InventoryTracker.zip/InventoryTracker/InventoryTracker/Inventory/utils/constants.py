# رنگ‌ها
COLORS = {
    'primary': '#009688',  # Teal
    'secondary': '#FF9800', # Orange
    'danger': '#F44336'    # Red
}

# پیام‌ها
MESSAGES = {
    'add_success': 'با موفقیت اضافه شد',
    'delete_confirm': 'آیا مطمئن هستید؟'
}

# تنظیمات پایگاه داده
DB_CONFIG = {
    'name': 'inventory.db',
    'tables': ['raw_materials', 'finished_products', 'operations']
}