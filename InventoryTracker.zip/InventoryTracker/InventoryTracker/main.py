import os
import sys
import platform
from kivy.config import Config

# Set headless mode for Replit environment
if 'REPL_ID' in os.environ or 'REPLIT_DEPLOYMENT' in os.environ:
    os.environ['KIVY_NO_ARGS'] = '1'
    os.environ['KIVY_NO_CONSOLELOG'] = '1'
    os.environ['KIVY_HEADLESS'] = '1'
    Config.set('graphics', 'headless', '1')
    Config.set('graphics', 'width', '360')
    Config.set('graphics', 'height', '640')
    Config.set('graphics', 'resizable', False)
else:
    # Set window size and make it non-resizable for development
    Config.set('graphics', 'width', '360')
    Config.set('graphics', 'height', '640')
    Config.set('graphics', 'resizable', False)

from kivy.core.window import Window
from kivy.lang import Builder
from kivymd.app import MDApp
from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDFlatButton

from database import DatabaseManager
from screens.home_screen import HomeScreen
from screens.materials_screen import MaterialsScreen
from screens.products_screen import ProductsScreen
from screens.charts_screen import ChartsScreen
from screens.add_material_screen import AddMaterialScreen
from screens.add_product_screen import AddProductScreen
from screens.edit_item_screen import EditItemScreen

# Main application class
class InventoryManagerApp(MDApp):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # Initialize database
        self.database_manager = DatabaseManager()
        # Initialize dialogs to None
        self.dialog = None
        
        # Store application screens
        self.screens = {}
        
        # Track current screen for navigation
        self.current_screen_name = "home"
        
    def build(self):
        # Set app theme
        self.theme_cls.primary_palette = "Blue"
        self.theme_cls.accent_palette = "Amber"
        self.theme_cls.theme_style = "Light"
        
        # Create screens dictionary
        self.screens = {
            "home": HomeScreen(name="home"),
            "materials": MaterialsScreen(name="materials"),
            "products": ProductsScreen(name="products"),
            "charts": ChartsScreen(name="charts"),
            "add_material": AddMaterialScreen(name="add_material"),
            "add_product": AddProductScreen(name="add_product"),
            "edit_item": EditItemScreen(name="edit_item"),
        }
        
        # Build the navigation structure
        from kivymd.uix.screenmanager import MDScreenManager
        screen_manager = MDScreenManager()
        
        # Add all screens to the manager
        for screen_name, screen_instance in self.screens.items():
            screen_manager.add_widget(screen_instance)
            
        # Initialize starting screen
        screen_manager.current = "home"
        
        return screen_manager
    
    def on_start(self):
        """Called when the application starts."""
        # Ensure database tables exist
        self.database_manager.create_tables()
    
    def change_screen(self, screen_name, direction='left', item_data=None):
        """
        Change to the specified screen with optional transition direction.
        
        Args:
            screen_name (str): Name of the screen to switch to
            direction (str): Direction of the transition ('left' or 'right')
            item_data (dict, optional): Data to pass to the screen
        """
        screen_manager = self.root
        
        # Pass data to screen if needed
        if item_data and screen_name in ["edit_item", "add_product"]:
            self.screens[screen_name].item_data = item_data
            
        # Set transition direction
        screen_manager.transition.direction = direction
        
        # Switch to new screen
        screen_manager.current = screen_name
        self.current_screen_name = screen_name
        
        # Refresh data on the screen if it has a refresh method
        if hasattr(self.screens[screen_name], "refresh_data"):
            self.screens[screen_name].refresh_data()
    
    def go_back(self):
        """Navigate back to the previous screen."""
        if self.current_screen_name in ["add_material", "add_product", "edit_item"]:
            # If we're in an add/edit screen, go back to the appropriate list screen
            if self.current_screen_name == "add_material" or (
                self.current_screen_name == "edit_item" and self.screens["edit_item"].item_type == "material"
            ):
                self.change_screen("materials", direction="right")
            else:
                self.change_screen("products", direction="right")
        else:
            # Otherwise go to the home screen
            self.change_screen("home", direction="right")
    
    def show_error_dialog(self, title, text):
        """
        Show an error dialog with the provided title and text.
        
        Args:
            title (str): Dialog title
            text (str): Dialog content text
        """
        if self.dialog:
            self.dialog.dismiss()
            self.dialog = None
            
        self.dialog = MDDialog(
            title=title,
            text=text,
            buttons=[
                MDFlatButton(
                    text="OK",
                    on_release=lambda x: self.dialog.dismiss()
                )
            ]
        )
        self.dialog.open()
    
    def show_confirmation_dialog(self, title, text, on_confirm):
        """
        Show a confirmation dialog with the provided title, text, and confirmation callback.
        
        Args:
            title (str): Dialog title
            text (str): Dialog content text
            on_confirm (callable): Function to call when user confirms
        """
        if self.dialog:
            self.dialog.dismiss()
            self.dialog = None
            
        self.dialog = MDDialog(
            title=title,
            text=text,
            buttons=[
                MDFlatButton(
                    text="Cancel",
                    on_release=lambda x: self.dialog.dismiss()
                ),
                MDFlatButton(
                    text="Confirm",
                    on_release=lambda x: self._handle_confirm(on_confirm)
                )
            ]
        )
        self.dialog.open()
    
    def _handle_confirm(self, on_confirm):
        """
        Handle confirmation dialog confirm button press.
        
        Args:
            on_confirm (callable): Function to call
        """
        self.dialog.dismiss()
        self.dialog = None
        on_confirm()

if __name__ == "__main__":
    InventoryManagerApp().run()
