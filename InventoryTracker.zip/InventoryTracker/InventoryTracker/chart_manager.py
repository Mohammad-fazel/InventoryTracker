import io
import matplotlib
matplotlib.use('Agg')  # Use Agg backend for non-interactive plotting
import matplotlib.pyplot as plt
from matplotlib.dates import DateFormatter
import matplotlib.dates as mdates
from datetime import datetime, timedelta
import numpy as np

class ChartManager:
    """
    Handles chart generation for inventory visualization.
    """
    def __init__(self):
        # Set common styling for all charts
        plt.style.use('seaborn-v0_8-whitegrid')
        self.colors = {
            'primary': '#2196F3',  # Blue
            'secondary': '#FFC107',  # Amber
            'danger': '#F44336',  # Red
            'success': '#4CAF50',  # Green
            'warning': '#FF9800',  # Orange
            'info': '#00BCD4',  # Cyan
        }
        
    def _convert_dates(self, dates):
        """
        Convert string date/times to datetime objects.
        
        Args:
            dates (list): List of date strings
            
        Returns:
            list: List of datetime objects
        """
        return [datetime.strptime(date, '%Y-%m-%d %H:%M:%S') if isinstance(date, str) else date for date in dates]
    
    def generate_inventory_level_chart(self, history_data, title, item_name):
        """
        Generate a line chart showing inventory levels over time.
        
        Args:
            history_data (list): List of dictionaries with timestamp and current_quantity
            title (str): Chart title
            item_name (str): Name of the item being charted
            
        Returns:
            bytes: PNG image data
        """
        if not history_data:
            return None
            
        # Extract data
        dates = [item['timestamp'] for item in history_data]
        dates = self._convert_dates(dates)
        quantities = [item['current_quantity'] for item in history_data]
        
        # Create figure and axes
        fig, ax = plt.subplots(figsize=(10, 6))
        
        # Plot data
        ax.plot(dates, quantities, marker='o', color=self.colors['primary'], linewidth=2)
        
        # Set labels and title
        ax.set_xlabel('Date')
        ax.set_ylabel('Quantity')
        ax.set_title(f"{title}: {item_name}")
        
        # Format x-axis dates
        date_formatter = DateFormatter('%Y-%m-%d')
        ax.xaxis.set_major_formatter(date_formatter)
        ax.xaxis.set_major_locator(mdates.DayLocator(interval=max(1, len(dates)//10)))
        plt.xticks(rotation=45)
        
        # Add grid
        ax.grid(True, linestyle='--', alpha=0.7)
        
        # Tight layout to avoid cutting off labels
        plt.tight_layout()
        
        # Convert to PNG image
        buf = io.BytesIO()
        plt.savefig(buf, format='png', dpi=100)
        plt.close(fig)
        buf.seek(0)
        
        return buf.getvalue()
    
    def generate_materials_usage_chart(self, history_data, title):
        """
        Generate a bar chart showing material usage over time.
        
        Args:
            history_data (list): List of dictionaries with item_name, action, quantity
            title (str): Chart title
            
        Returns:
            bytes: PNG image data
        """
        if not history_data:
            return None
            
        # Filter for 'use' actions
        usage_data = [item for item in history_data if item['action'] == 'use' and item['item_type'] == 'material']
        
        if not usage_data:
            return None
            
        # Group by material name
        materials = {}
        for item in usage_data:
            name = item['item_name']
            quantity = abs(item['quantity'])  # Use abs since usage is typically negative
            if name in materials:
                materials[name] += quantity
            else:
                materials[name] = quantity
        
        # Extract data for plotting
        names = list(materials.keys())
        quantities = list(materials.values())
        
        # Create figure and axes
        fig, ax = plt.subplots(figsize=(10, 6))
        
        # Plot data
        bars = ax.bar(names, quantities, color=self.colors['primary'])
        
        # Add values on top of bars
        for bar in bars:
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height + 0.1,
                    f'{height:.1f}', ha='center', va='bottom')
        
        # Set labels and title
        ax.set_xlabel('Materials')
        ax.set_ylabel('Quantity Used')
        ax.set_title(title)
        
        # Rotate x-axis labels for better readability
        plt.xticks(rotation=45, ha='right')
        
        # Add grid
        ax.grid(True, linestyle='--', alpha=0.7, axis='y')
        
        # Tight layout to avoid cutting off labels
        plt.tight_layout()
        
        # Convert to PNG image
        buf = io.BytesIO()
        plt.savefig(buf, format='png', dpi=100)
        plt.close(fig)
        buf.seek(0)
        
        return buf.getvalue()
    
    def generate_product_creation_chart(self, history_data, title):
        """
        Generate a bar chart showing product creation over time.
        
        Args:
            history_data (list): List of dictionaries with timestamp, item_name, action, quantity
            title (str): Chart title
            
        Returns:
            bytes: PNG image data
        """
        if not history_data:
            return None
            
        # Filter for 'create' actions
        creation_data = [item for item in history_data if item['action'] == 'create' and item['item_type'] == 'product']
        
        if not creation_data:
            return None
            
        # Group by product name
        products = {}
        for item in creation_data:
            name = item['item_name']
            quantity = item['quantity']
            if name in products:
                products[name] += quantity
            else:
                products[name] = quantity
        
        # Extract data for plotting
        names = list(products.keys())
        quantities = list(products.values())
        
        # Create figure and axes
        fig, ax = plt.subplots(figsize=(10, 6))
        
        # Plot data
        bars = ax.bar(names, quantities, color=self.colors['success'])
        
        # Add values on top of bars
        for bar in bars:
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height + 0.1,
                    f'{height:.0f}', ha='center', va='bottom')
        
        # Set labels and title
        ax.set_xlabel('Products')
        ax.set_ylabel('Quantity Created')
        ax.set_title(title)
        
        # Rotate x-axis labels for better readability
        plt.xticks(rotation=45, ha='right')
        
        # Add grid
        ax.grid(True, linestyle='--', alpha=0.7, axis='y')
        
        # Tight layout to avoid cutting off labels
        plt.tight_layout()
        
        # Convert to PNG image
        buf = io.BytesIO()
        plt.savefig(buf, format='png', dpi=100)
        plt.close(fig)
        buf.seek(0)
        
        return buf.getvalue()
    
    def generate_materials_distribution_chart(self, materials):
        """
        Generate a pie chart showing the distribution of materials by value.
        
        Args:
            materials (list): List of Material objects
            
        Returns:
            bytes: PNG image data
        """
        if not materials:
            return None
            
        # Calculate values
        names = [m.name for m in materials]
        values = [m.total_value for m in materials]
        
        # Filter out materials with zero value
        filtered_names = []
        filtered_values = []
        for i, value in enumerate(values):
            if value > 0:
                filtered_names.append(names[i])
                filtered_values.append(value)
        
        if not filtered_values:
            return None
            
        # Create figure and axes
        fig, ax = plt.subplots(figsize=(10, 8))
        
        # Plot data
        patches, texts, autotexts = ax.pie(
            filtered_values, 
            labels=None,  # We'll add a legend instead
            autopct='%1.1f%%',
            startangle=90,
            shadow=False,
            explode=[0.05] * len(filtered_values),  # Explode all slices slightly
            colors=plt.cm.tab20.colors[:len(filtered_values)]
        )
        
        # Make text more readable
        for text in autotexts:
            text.set_color('white')
            text.set_fontsize(10)
        
        # Equal aspect ratio ensures that pie is drawn as a circle
        ax.axis('equal')
        
        # Add title
        plt.title('Material Value Distribution')
        
        # Add legend
        plt.legend(
            patches, 
            [f"{name} (${value:.2f})" for name, value in zip(filtered_names, filtered_values)],
            loc="center left",
            bbox_to_anchor=(1, 0.5)
        )
        
        # Tight layout to avoid cutting off labels
        plt.tight_layout()
        
        # Convert to PNG image
        buf = io.BytesIO()
        plt.savefig(buf, format='png', dpi=100)
        plt.close(fig)
        buf.seek(0)
        
        return buf.getvalue()
    
    def generate_products_distribution_chart(self, products):
        """
        Generate a pie chart showing the distribution of products by value.
        
        Args:
            products (list): List of Product objects
            
        Returns:
            bytes: PNG image data
        """
        if not products:
            return None
            
        # Calculate values
        names = [p.name for p in products]
        values = [p.total_value for p in products]
        
        # Filter out products with zero value
        filtered_names = []
        filtered_values = []
        for i, value in enumerate(values):
            if value > 0:
                filtered_names.append(names[i])
                filtered_values.append(value)
        
        if not filtered_values:
            return None
            
        # Create figure and axes
        fig, ax = plt.subplots(figsize=(10, 8))
        
        # Plot data
        patches, texts, autotexts = ax.pie(
            filtered_values, 
            labels=None,  # We'll add a legend instead
            autopct='%1.1f%%',
            startangle=90,
            shadow=False,
            explode=[0.05] * len(filtered_values),  # Explode all slices slightly
            colors=plt.cm.tab20.colors[:len(filtered_values)]
        )
        
        # Make text more readable
        for text in autotexts:
            text.set_color('white')
            text.set_fontsize(10)
        
        # Equal aspect ratio ensures that pie is drawn as a circle
        ax.axis('equal')
        
        # Add title
        plt.title('Product Value Distribution')
        
        # Add legend
        plt.legend(
            patches, 
            [f"{name} (${value:.2f})" for name, value in zip(filtered_names, filtered_values)],
            loc="center left",
            bbox_to_anchor=(1, 0.5)
        )
        
        # Tight layout to avoid cutting off labels
        plt.tight_layout()
        
        # Convert to PNG image
        buf = io.BytesIO()
        plt.savefig(buf, format='png', dpi=100)
        plt.close(fig)
        buf.seek(0)
        
        return buf.getvalue()
    
    def generate_low_stock_chart(self, materials):
        """
        Generate a horizontal bar chart showing materials that are near or below
        their minimum threshold.
        
        Args:
            materials (list): List of Material objects
            
        Returns:
            bytes: PNG image data
        """
        # Filter for low stock materials
        low_stock = [m for m in materials if m.quantity <= m.min_quantity * 1.2]
        
        if not low_stock:
            return None
            
        # Sort by the ratio of current to minimum quantity (ascending)
        low_stock.sort(key=lambda m: (m.quantity / max(m.min_quantity, 0.001)) if m.min_quantity > 0 else float('inf'))
        
        # Take at most 10 materials
        low_stock = low_stock[:10]
            
        # Extract data
        names = [m.name for m in low_stock]
        current_quantities = [m.quantity for m in low_stock]
        min_quantities = [m.min_quantity for m in low_stock]
        
        # Create figure and axes
        fig, ax = plt.subplots(figsize=(10, max(6, len(names) * 0.5)))
        
        # Create y-position for bars
        y_pos = np.arange(len(names))
        
        # Plot minimum quantities (background bars)
        ax.barh(y_pos, min_quantities, color=self.colors['warning'], alpha=0.3)
        
        # Plot current quantities
        bars = ax.barh(y_pos, current_quantities, color=self.colors['primary'])
        
        # Add labels for current quantities
        for i, bar in enumerate(bars):
            width = bar.get_width()
            unit = low_stock[i].unit
            ax.text(
                width + 0.3, 
                bar.get_y() + bar.get_height()/2, 
                f'{width:.1f} {unit}', 
                ha='left', 
                va='center'
            )
        
        # Set labels and title
        ax.set_yticks(y_pos)
        ax.set_yticklabels(names)
        ax.set_xlabel('Quantity')
        ax.set_title('Low Stock Materials')
        
        # Add legend
        ax.legend(['Minimum Quantity', 'Current Quantity'])
        
        # Add grid
        ax.grid(True, linestyle='--', alpha=0.7, axis='x')
        
        # Tight layout to avoid cutting off labels
        plt.tight_layout()
        
        # Convert to PNG image
        buf = io.BytesIO()
        plt.savefig(buf, format='png', dpi=100)
        plt.close(fig)
        buf.seek(0)
        
        return buf.getvalue()
