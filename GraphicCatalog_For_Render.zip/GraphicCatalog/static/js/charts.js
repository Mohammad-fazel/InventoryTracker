// Charts.js - Functions for initializing and managing charts

// Initialize Inventory Chart
function initInventoryChart() {
    const chartElement = document.getElementById('inventory-chart');
    if (!chartElement) return;
    
    // The chart data is loaded from the server-side rendered JSON
    const chartJSON = chartElement.getAttribute('data-chart');
    if (!chartJSON) return;
    
    try {
        const chartData = JSON.parse(chartJSON);
        Plotly.newPlot('inventory-chart', chartData.data, chartData.layout);
        
        // Make the chart responsive
        window.addEventListener('resize', function() {
            Plotly.relayout('inventory-chart', {
                'width': chartElement.offsetWidth
            });
        });
    } catch (e) {
        console.error('Error initializing inventory chart:', e);
    }
}

// Initialize Transactions Chart
function initTransactionsChart() {
    const chartElement = document.getElementById('transactions-chart');
    if (!chartElement) return;
    
    const chartJSON = chartElement.getAttribute('data-chart');
    if (!chartJSON) return;
    
    try {
        const chartData = JSON.parse(chartJSON);
        Plotly.newPlot('transactions-chart', chartData.data, chartData.layout);
        
        // Make the chart responsive
        window.addEventListener('resize', function() {
            Plotly.relayout('transactions-chart', {
                'width': chartElement.offsetWidth
            });
        });
    } catch (e) {
        console.error('Error initializing transactions chart:', e);
    }
}

// Initialize Production Progress Chart
function initProductionChart() {
    const chartElement = document.getElementById('production-chart');
    if (!chartElement) return;
    
    const chartJSON = chartElement.getAttribute('data-chart');
    if (!chartJSON) return;
    
    try {
        const chartData = JSON.parse(chartJSON);
        Plotly.newPlot('production-chart', chartData.data, chartData.layout);
        
        // Make the chart responsive
        window.addEventListener('resize', function() {
            Plotly.relayout('production-chart', {
                'width': chartElement.offsetWidth
            });
        });
    } catch (e) {
        console.error('Error initializing production chart:', e);
    }
}

// Create an animated 3D donut chart
function create3DDonutChart(elementId, data) {
    const chartElement = document.getElementById(elementId);
    if (!chartElement) return;
    
    const labels = data.map(item => item.label);
    const values = data.map(item => item.value);
    const colors = data.map(item => item.color);
    
    const layout = {
        title: {
            text: chartElement.getAttribute('data-title') || 'نمودار 3D',
            font: {
                family: 'Tahoma, Arial, sans-serif',
                size: 18,
                color: '#374151'
            }
        },
        paper_bgcolor: 'rgba(245, 247, 252, 0.8)',
        plot_bgcolor: 'rgba(245, 247, 252, 0)',
        margin: {t: 60, r: 40, b: 60, l: 40},
        height: 400,
        scene: {
            xaxis: {title: ''},
            yaxis: {title: ''},
            zaxis: {title: ''},
            camera: {
                eye: {x: 1.25, y: 1.25, z: 1.25}
            }
        }
    };
    
    // Create 3D donut points
    const chartData = [];
    
    // Generate points for each segment
    let segmentIndex = 0;
    data.forEach((segment, index) => {
        const segmentSize = segment.value;
        const totalSegments = values.reduce((a, b) => a + b, 0);
        const segmentPercentage = segmentSize / totalSegments;
        const segmentAngle = segmentPercentage * Math.PI * 2;
        
        const startAngle = segmentIndex * Math.PI * 2 / totalSegments;
        const endAngle = startAngle + segmentAngle;
        
        // Generate points for a donut segment
        const x = [];
        const y = [];
        const z = [];
        
        // Outer and inner radiuses
        const outerRadius = 5;
        const innerRadius = 2;
        
        // Number of points to generate
        const numPoints = Math.max(10, Math.floor(segmentPercentage * 50));
        
        // Generate points along the segment
        for (let i = 0; i <= numPoints; i++) {
            const angle = startAngle + (i / numPoints) * (endAngle - startAngle);
            
            // Outer points
            x.push(Math.cos(angle) * outerRadius);
            y.push(Math.sin(angle) * outerRadius);
            z.push(0);
            
            // Inner points
            x.push(Math.cos(angle) * innerRadius);
            y.push(Math.sin(angle) * innerRadius);
            z.push(0);
        }
        
        // Add segment to chart data
        chartData.push({
            type: 'scatter3d',
            mode: 'lines',
            x: x,
            y: y,
            z: z.map(val => val + Math.random() * 0.5), // Add slight variation for 3D effect
            line: {
                color: segment.color,
                width: 8
            },
            name: segment.label,
            hoverinfo: 'name+text',
            text: `${segment.value} (${Math.round(segmentPercentage * 100)}%)`
        });
        
        segmentIndex += segmentSize;
    });
    
    Plotly.newPlot(elementId, chartData, layout);
    
    // Add rotation animation
    let angle = 0;
    function rotate() {
        angle += 0.01;
        
        Plotly.relayout(elementId, {
            'scene.camera.eye.x': 1.25 * Math.cos(angle),
            'scene.camera.eye.y': 1.25 * Math.sin(angle),
            'scene.camera.eye.z': 1.25
        });
        
        requestAnimationFrame(rotate);
    }
    
    // Start rotation animation
    rotate();
}

// Initialize a custom 3D chart for material analytics
function initMaterialAnalyticsChart(elementId, materialData) {
    const chartElement = document.getElementById(elementId);
    if (!chartElement) return;
    
    if (!materialData || !materialData.length) {
        console.error('No material data provided for 3D chart');
        return;
    }
    
    // Prepare data for 3D visualization
    const x = materialData.map((_, index) => index);
    const y = materialData.map(item => parseFloat(item.quantity));
    const z = materialData.map(_ => 0);
    
    // Max quantity for normalization
    const maxQuantity = Math.max(...y);
    
    // Set up the colors based on quantity level
    const colors = y.map(qty => {
        const percentage = qty / maxQuantity;
        if (percentage < 0.3) return 'rgb(239, 68, 68)'; // Red
        if (percentage < 0.6) return 'rgb(249, 115, 22)'; // Orange
        return 'rgb(16, 185, 129)'; // Green
    });
    
    // Text for hover information
    const text = materialData.map(item => 
        `${item.name}: ${item.quantity} ${item.unit}`
    );
    
    // 3D Bar chart
    const trace = {
        type: 'scatter3d',
        mode: 'markers',
        x: x,
        y: y,
        z: z,
        marker: {
            size: y.map(qty => (qty / maxQuantity) * 30 + 5),
            color: colors,
            opacity: 0.8,
            symbol: 'circle'
        },
        text: text,
        hoverinfo: 'text'
    };
    
    const layout = {
        title: 'تحلیل موجودی مواد اولیه',
        showlegend: false,
        autosize: true,
        height: 500,
        scene: {
            xaxis: {
                title: '',
                showticklabels: false,
                showgrid: false,
                zeroline: false,
                showline: false
            },
            yaxis: {
                title: 'موجودی',
                showgrid: true,
                zeroline: true
            },
            zaxis: {
                title: '',
                showticklabels: false,
                showgrid: false,
                zeroline: false,
                showline: false
            },
            camera: {
                eye: {x: 1.5, y: 1.5, z: 1}
            }
        },
        paper_bgcolor: 'rgba(245, 247, 252, 0.8)',
        plot_bgcolor: 'rgba(245, 247, 252, 0)',
        margin: {t: 60, r: 20, b: 40, l: 20}
    };
    
    Plotly.newPlot(elementId, [trace], layout);
    
    // Add animation - floating effect
    let frame = 0;
    function animate() {
        frame += 0.05;
        
        const newZ = z.map((_, i) => Math.sin(frame + i * 0.3) * 0.5);
        
        Plotly.update(elementId, {
            z: [newZ]
        }, {}, [0]);
        
        requestAnimationFrame(animate);
    }
    
    // Start animation
    animate();
}
