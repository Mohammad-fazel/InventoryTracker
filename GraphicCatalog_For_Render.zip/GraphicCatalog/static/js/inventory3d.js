// 3D Visualization for Inventory using Three.js

let scene, camera, renderer, controls;
let materials = []; // Will store the inventory data
let materialMeshes = []; // Will store the 3D objects

// Initialize the 3D visualization
function init3DVisualization() {
    // Get container
    const container = document.getElementById('inventory-3d-container');
    if (!container) return;

    // Create scene
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0xf8fafc);

    // Create camera
    camera = new THREE.PerspectiveCamera(
        75, // field of view
        container.clientWidth / container.clientHeight, // aspect ratio
        0.1, // near clipping plane
        1000 // far clipping plane
    );
    camera.position.z = 30;
    camera.position.y = 10;

    // Create renderer
    renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(container.clientWidth, container.clientHeight);
    container.appendChild(renderer.domElement);

    // Add lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
    directionalLight.position.set(1, 1, 1);
    scene.add(directionalLight);

    // Add orbit controls to rotate the view
    controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.screenSpacePanning = false;
    controls.minDistance = 10;
    controls.maxDistance = 100;
    controls.maxPolarAngle = Math.PI / 2;

    // Add a grid
    const gridHelper = new THREE.GridHelper(50, 50, 0x3b82f6, 0xdbeafe);
    gridHelper.position.y = -5;
    scene.add(gridHelper);

    // Load data and create visualization
    loadInventoryData();

    // Handle window resize
    window.addEventListener('resize', onWindowResize, false);

    // Start animation loop
    animate();
}

// Fetch inventory data from the API
function loadInventoryData() {
    fetch('/api/materials_for_3d')
        .then(response => response.json())
        .then(data => {
            materials = data;
            createMaterialVisualizations();
        })
        .catch(error => {
            console.error('Error loading inventory data:', error);
        });
}

// Create 3D objects based on inventory data
function createMaterialVisualizations() {
    // Clear existing objects
    materialMeshes.forEach(mesh => scene.remove(mesh));
    materialMeshes = [];

    if (!materials.length) return;

    // Find max quantity for scaling
    const maxQuantity = Math.max(...materials.map(m => m.quantity));
    
    // Arrange materials in a grid
    const gridSize = Math.ceil(Math.sqrt(materials.length));
    const spacing = 10;
    const startX = -((gridSize - 1) * spacing) / 2;
    const startZ = -((gridSize - 1) * spacing) / 2;

    materials.forEach((material, index) => {
        const row = Math.floor(index / gridSize);
        const col = index % gridSize;
        
        // Scale height based on quantity
        const height = (material.quantity / maxQuantity) * 15 + 1;
        
        // Create a material type
        const geometry = new THREE.BoxGeometry(5, height, 5);
        
        // Create different colors based on quantity percentage
        const percentage = material.quantity / maxQuantity;
        let color;
        
        if (percentage < 0.3) {
            // Red for low inventory
            color = new THREE.Color(0xef4444);
        } else if (percentage < 0.6) {
            // Orange for medium inventory
            color = new THREE.Color(0xf97316);
        } else {
            // Green for high inventory
            color = new THREE.Color(0x10b981);
        }
        
        const threeMaterial = new THREE.MeshPhongMaterial({ 
            color: color,
            transparent: true,
            opacity: 0.8,
            specular: 0x111111,
            shininess: 30
        });
        
        const mesh = new THREE.Mesh(geometry, threeMaterial);
        
        // Position the mesh
        mesh.position.x = startX + col * spacing;
        mesh.position.y = height / 2;
        mesh.position.z = startZ + row * spacing;
        
        // Add data to the mesh for hover effects
        mesh.userData = {
            name: material.name,
            quantity: material.quantity,
            unit: material.unit
        };
        
        // Add to scene
        scene.add(mesh);
        materialMeshes.push(mesh);
        
        // Add a text label for the material name
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        canvas.width = 256;
        canvas.height = 128;
        
        context.fillStyle = '#ffffff';
        context.fillRect(0, 0, canvas.width, canvas.height);
        
        context.font = '24px Arial';
        context.fillStyle = '#333333';
        context.textAlign = 'center';
        context.textBaseline = 'middle';
        
        // Truncate name if too long
        let displayName = material.name;
        if (displayName.length > 10) {
            displayName = displayName.substring(0, 9) + '...';
        }
        
        context.fillText(displayName, canvas.width / 2, canvas.height / 2);
        
        const texture = new THREE.CanvasTexture(canvas);
        const labelMaterial = new THREE.MeshBasicMaterial({
            map: texture,
            transparent: true,
            side: THREE.DoubleSide
        });
        
        const labelGeometry = new THREE.PlaneGeometry(5, 2.5);
        const label = new THREE.Mesh(labelGeometry, labelMaterial);
        
        label.position.set(mesh.position.x, -4, mesh.position.z);
        label.rotation.x = -Math.PI / 2;
        
        scene.add(label);
        materialMeshes.push(label);
    });
}

// Handle window resize
function onWindowResize() {
    const container = document.getElementById('inventory-3d-container');
    if (!container) return;
    
    camera.aspect = container.clientWidth / container.clientHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(container.clientWidth, container.clientHeight);
}

// Animation loop
function animate() {
    requestAnimationFrame(animate);
    
    // Update controls
    controls.update();
    
    // Rotate each material slightly for animation
    materialMeshes.forEach((mesh, index) => {
        if (mesh.geometry instanceof THREE.BoxGeometry) {
            mesh.rotation.y += 0.002;
        }
    });
    
    renderer.render(scene, camera);
}
