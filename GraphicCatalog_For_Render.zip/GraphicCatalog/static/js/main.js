// Main JavaScript for Inventory Management System

// Auto-close alerts after 5 seconds
document.addEventListener('DOMContentLoaded', function() {
    // Auto close alerts
    setTimeout(function() {
        const alerts = document.querySelectorAll('.alert:not(.alert-persistent)');
        alerts.forEach(alert => {
            alert.classList.add('fade');
            setTimeout(() => {
                alert.remove();
            }, 500);
        });
    }, 5000);

    // Enable tooltips
    const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl));

    // Raw materials page functionality
    setupRawMaterialsPage();
    
    // Products page functionality
    setupProductsPage();
    
    // Production page functionality
    setupProductionPage();
    
    // Transactions page functionality
    setupTransactionsPage();
    
    // Dashboard page - Initialize charts if elements exist
    initializeCharts();
});

// Setup Raw Materials Page
function setupRawMaterialsPage() {
    // Edit raw material modal
    const editMaterialButtons = document.querySelectorAll('.edit-material-btn');
    if (editMaterialButtons.length) {
        editMaterialButtons.forEach(button => {
            button.addEventListener('click', function() {
                const materialId = this.getAttribute('data-id');
                
                // Fetch material data and populate form
                fetch(`/raw_materials/get/${materialId}`)
                    .then(response => response.json())
                    .then(material => {
                        document.getElementById('edit-id').value = material.id;
                        document.getElementById('edit-name').value = material.name;
                        document.getElementById('edit-quantity').value = material.quantity;
                        document.getElementById('edit-unit').value = material.unit;
                        
                        // Show modal
                        const editModal = new bootstrap.Modal(document.getElementById('editMaterialModal'));
                        editModal.show();
                    })
                    .catch(error => {
                        console.error('Error fetching material data:', error);
                        alert('خطا در دریافت اطلاعات ماده اولیه');
                    });
            });
        });
    }

    // Update quantity form
    const updateQuantityForm = document.getElementById('updateQuantityForm');
    if (updateQuantityForm) {
        updateQuantityForm.addEventListener('submit', function(e) {
            const quantityChange = parseFloat(document.getElementById('quantity_change').value);
            if (isNaN(quantityChange) || quantityChange === 0) {
                e.preventDefault();
                alert('لطفاً مقدار تغییر معتبر وارد کنید');
            }
        });
    }

    // Delete confirmation
    const deleteMaterialButtons = document.querySelectorAll('.delete-material-btn');
    if (deleteMaterialButtons.length) {
        deleteMaterialButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                if (!confirm('آیا از حذف این ماده اولیه اطمینان دارید؟')) {
                    e.preventDefault();
                }
            });
        });
    }
}

// Setup Products Page
function setupProductsPage() {
    // Edit product modal
    const editProductButtons = document.querySelectorAll('.edit-product-btn');
    if (editProductButtons.length) {
        editProductButtons.forEach(button => {
            button.addEventListener('click', function() {
                const productId = this.getAttribute('data-id');
                
                // Fetch product data and populate form
                fetch(`/products/get/${productId}`)
                    .then(response => response.json())
                    .then(product => {
                        document.getElementById('edit-product-id').value = product.id;
                        document.getElementById('edit-product-name').value = product.name;
                        document.getElementById('edit-product-materials').value = product.materials;
                        
                        // Show modal
                        const editModal = new bootstrap.Modal(document.getElementById('editProductModal'));
                        editModal.show();
                    })
                    .catch(error => {
                        console.error('Error fetching product data:', error);
                        alert('خطا در دریافت اطلاعات محصول');
                    });
            });
        });
    }

    // Delete confirmation
    const deleteProductButtons = document.querySelectorAll('.delete-product-btn');
    if (deleteProductButtons.length) {
        deleteProductButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                if (!confirm('آیا از حذف این محصول اطمینان دارید؟')) {
                    e.preventDefault();
                }
            });
        });
    }

    // Materials helper for products
    const addMaterialBtn = document.getElementById('add-material-to-list');
    if (addMaterialBtn) {
        addMaterialBtn.addEventListener('click', function() {
            const materialSelect = document.getElementById('material-select');
            const materialQuantity = document.getElementById('material-quantity');
            
            if (materialSelect.value && materialQuantity.value) {
                const materialName = materialSelect.options[materialSelect.selectedIndex].text;
                const quantity = parseFloat(materialQuantity.value);
                
                if (isNaN(quantity) || quantity <= 0) {
                    alert('لطفاً مقدار معتبر وارد کنید');
                    return;
                }
                
                let materialsInput = document.getElementById('product-materials');
                
                // Add the material to the list
                if (materialsInput.value) {
                    materialsInput.value += `, ${materialName}:${quantity}`;
                } else {
                    materialsInput.value = `${materialName}:${quantity}`;
                }
                
                // Clear the inputs
                materialQuantity.value = '';
            } else {
                alert('لطفاً ماده اولیه و مقدار را وارد کنید');
            }
        });
    }
}

// Setup Production Page
function setupProductionPage() {
    // Update status modal
    const updateStatusButtons = document.querySelectorAll('.update-status-btn');
    if (updateStatusButtons.length) {
        updateStatusButtons.forEach(button => {
            button.addEventListener('click', function() {
                const itemId = this.getAttribute('data-id');
                const currentStatus = this.getAttribute('data-status');
                
                document.getElementById('status-item-id').value = itemId;
                
                const statusSelect = document.getElementById('item-status');
                for (let i = 0; i < statusSelect.options.length; i++) {
                    if (statusSelect.options[i].value === currentStatus) {
                        statusSelect.selectedIndex = i;
                        break;
                    }
                }
                
                // Show modal
                const statusModal = new bootstrap.Modal(document.getElementById('updateStatusModal'));
                statusModal.show();
            });
        });
    }

    // Delete confirmation
    const deleteProductionButtons = document.querySelectorAll('.delete-production-btn');
    if (deleteProductionButtons.length) {
        deleteProductionButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                if (!confirm('آیا از حذف این مورد از لیست تولید اطمینان دارید؟')) {
                    e.preventDefault();
                }
            });
        });
    }
}

// Setup Transactions Page
function setupTransactionsPage() {
    // Transaction filter functionality
    const filterForm = document.getElementById('transaction-filter');
    if (filterForm) {
        filterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const type = document.getElementById('filter-type').value;
            const item = document.getElementById('filter-item').value;
            const startDate = document.getElementById('filter-start-date').value;
            const endDate = document.getElementById('filter-end-date').value;
            
            // Filter table rows
            const rows = document.querySelectorAll('#transactions-table tbody tr');
            
            rows.forEach(row => {
                const rowType = row.querySelector('td:nth-child(3)').textContent;
                const rowItem = row.querySelector('td:nth-child(4)').textContent;
                const rowDate = row.querySelector('td:nth-child(2)').textContent;
                
                let typeMatch = true;
                let itemMatch = true;
                let dateMatch = true;
                
                if (type && type !== 'all') {
                    typeMatch = rowType === type;
                }
                
                if (item) {
                    itemMatch = rowItem.includes(item);
                }
                
                if (startDate && endDate) {
                    const date = new Date(rowDate.split(' ')[0]);
                    const start = new Date(startDate);
                    const end = new Date(endDate);
                    
                    dateMatch = date >= start && date <= end;
                } else if (startDate) {
                    const date = new Date(rowDate.split(' ')[0]);
                    const start = new Date(startDate);
                    
                    dateMatch = date >= start;
                } else if (endDate) {
                    const date = new Date(rowDate.split(' ')[0]);
                    const end = new Date(endDate);
                    
                    dateMatch = date <= end;
                }
                
                if (typeMatch && itemMatch && dateMatch) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
        
        // Reset filter
        const resetBtn = document.getElementById('reset-filter');
        if (resetBtn) {
            resetBtn.addEventListener('click', function() {
                document.getElementById('filter-type').value = 'all';
                document.getElementById('filter-item').value = '';
                document.getElementById('filter-start-date').value = '';
                document.getElementById('filter-end-date').value = '';
                
                // Show all rows
                const rows = document.querySelectorAll('#transactions-table tbody tr');
                rows.forEach(row => {
                    row.style.display = '';
                });
            });
        }
    }
}

// Initialize charts if elements exist
function initializeCharts() {
    // These functions will be defined in charts.js
    // They're called here to ensure DOM is loaded
    if (typeof initInventoryChart === 'function' && document.getElementById('inventory-chart')) {
        initInventoryChart();
    }
    
    if (typeof initTransactionsChart === 'function' && document.getElementById('transactions-chart')) {
        initTransactionsChart();
    }
    
    if (typeof initProductionChart === 'function' && document.getElementById('production-chart')) {
        initProductionChart();
    }
    
    // 3D Visualization
    if (typeof init3DVisualization === 'function' && document.getElementById('inventory-3d-container')) {
        init3DVisualization();
    }
}

// Add 3D hover effect to cards
document.addEventListener('DOMContentLoaded', function() {
    const cards = document.querySelectorAll('.card-3d');
    
    cards.forEach(card => {
        card.addEventListener('mousemove', function(e) {
            const rect = this.getBoundingClientRect();
            const x = e.clientX - rect.left; // x position within the element
            const y = e.clientY - rect.top;  // y position within the element
            
            const centerX = rect.width / 2;
            const centerY = rect.height / 2;
            
            const deltaX = (x - centerX) / centerX * 5; // max rotation 5deg
            const deltaY = (y - centerY) / centerY * 5;
            
            this.style.transform = `perspective(1000px) rotateX(${-deltaY}deg) rotateY(${deltaX}deg)`;
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'perspective(1000px) rotateX(0) rotateY(0)';
        });
    });
});
