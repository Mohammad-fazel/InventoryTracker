#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, Response, make_response
import sqlite3
import json
import plotly
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
from datetime import datetime
import os
import csv
import io
import logging

# Set up logging
logging.basicConfig(level=logging.DEBUG)

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "inventory_management_system")
app.config['DATABASE'] = 'inventory.db'

def get_db_connection():
    conn = sqlite3.connect(app.config['DATABASE'])
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # جدول مواد اولیه
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS raw_materials (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL,
        quantity REAL NOT NULL,
        unit TEXT NOT NULL
    )
    """)
    
    # جدول محصولات
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL,
        materials TEXT NOT NULL
    )
    """)
    
    # جدول تراکنش‌ها
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        date TEXT NOT NULL,
        type TEXT NOT NULL,
        item TEXT NOT NULL,
        change REAL NOT NULL,
        remaining REAL,
        notes TEXT
    )
    """)
    
    # جدول قطعات در حال تولید
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS in_production_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER NOT NULL,
        quantity INTEGER NOT NULL,
        start_date TEXT NOT NULL,
        estimated_completion_date TEXT,
        status TEXT NOT NULL,
        notes TEXT,
        FOREIGN KEY (product_id) REFERENCES products(id)
    )
    """)
    
    conn.commit()
    conn.close()

# تابع افزودن ماده اولیه
def add_raw_material(name, quantity, unit):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute(
            "INSERT INTO raw_materials (name, quantity, unit) VALUES (?, ?, ?)",
            (name, quantity, unit)
        )
        conn.commit()
        
        # ثبت تراکنش
        add_transaction("ورود", name, quantity, quantity, "افزودن ماده اولیه جدید")
        
        conn.close()
        return True, "ماده اولیه با موفقیت اضافه شد"
    except sqlite3.IntegrityError:
        return False, "نام ماده اولیه تکراری است"
    except Exception as e:
        return False, f"خطا در افزودن ماده اولیه: {str(e)}"

# تابع به‌روزرسانی موجودی ماده اولیه
def update_raw_material(name, quantity_change, note=""):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT quantity FROM raw_materials WHERE name=?", (name,))
        result = cursor.fetchone()
        
        if not result:
            conn.close()
            return False, "ماده اولیه یافت نشد"
        
        current_quantity = float(result['quantity'])
        new_quantity = current_quantity + float(quantity_change)
        
        if new_quantity < 0:
            conn.close()
            return False, "موجودی کافی نیست"
        
        cursor.execute(
            "UPDATE raw_materials SET quantity=? WHERE name=?",
            (new_quantity, name)
        )
        conn.commit()
        
        # ثبت تراکنش
        trans_type = "ورود" if quantity_change > 0 else "خروج"
        add_transaction(trans_type, name, quantity_change, new_quantity, note)
        
        conn.close()
        return True, "موجودی با موفقیت به‌روز شد"
    except Exception as e:
        return False, f"خطا در به‌روزرسانی موجودی: {str(e)}"

# تابع ویرایش ماده اولیه
def edit_raw_material(id, name, quantity, unit):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get current data to check for changes
        cursor.execute("SELECT * FROM raw_materials WHERE id=?", (id,))
        current = cursor.fetchone()
        
        if not current:
            conn.close()
            return False, "ماده اولیه یافت نشد"
        
        # Check if name is being changed and is unique
        if current['name'] != name:
            cursor.execute("SELECT id FROM raw_materials WHERE name=? AND id!=?", (name, id))
            if cursor.fetchone():
                conn.close()
                return False, "نام ماده اولیه تکراری است"
        
        # Calculate quantity difference for transaction log
        quantity_diff = float(quantity) - float(current['quantity'])
        
        # Update the raw material
        cursor.execute(
            "UPDATE raw_materials SET name=?, quantity=?, unit=? WHERE id=?",
            (name, quantity, unit, id)
        )
        conn.commit()
        
        # Record transaction if quantity changed
        if quantity_diff != 0:
            trans_type = "ورود" if quantity_diff > 0 else "خروج"
            add_transaction(trans_type, name, abs(quantity_diff), quantity, "ویرایش ماده اولیه")
        
        conn.close()
        return True, "ماده اولیه با موفقیت ویرایش شد"
    except Exception as e:
        return False, f"خطا در ویرایش ماده اولیه: {str(e)}"

# تابع حذف ماده اولیه
def delete_raw_material(id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get the material info for the transaction record
        cursor.execute("SELECT * FROM raw_materials WHERE id=?", (id,))
        material = cursor.fetchone()
        
        if not material:
            conn.close()
            return False, "ماده اولیه یافت نشد"
        
        # Check if this material is used in any product
        cursor.execute("SELECT * FROM products")
        products = cursor.fetchall()
        
        for product in products:
            materials_list = product['materials'].split(',')
            for material_str in materials_list:
                parts = material_str.strip().split(':')
                if len(parts) == 2 and parts[0].strip() == material['name']:
                    conn.close()
                    return False, f"این ماده اولیه در محصول {product['name']} استفاده شده و قابل حذف نیست"
        
        # Delete the material
        cursor.execute("DELETE FROM raw_materials WHERE id=?", (id,))
        
        # Add a deletion transaction record
        add_transaction("حذف", material['name'], -material['quantity'], 0, "حذف ماده اولیه")
        
        conn.commit()
        conn.close()
        return True, "ماده اولیه با موفقیت حذف شد"
    except Exception as e:
        return False, f"خطا در حذف ماده اولیه: {str(e)}"

# تابع دریافت لیست تمام مواد اولیه
def get_all_raw_materials():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM raw_materials ORDER BY name")
    results = cursor.fetchall()
    conn.close()
    return results

# تابع دریافت اطلاعات یک ماده اولیه
def get_raw_material(name=None, id=None):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    if id:
        cursor.execute("SELECT * FROM raw_materials WHERE id=?", (id,))
    elif name:
        cursor.execute("SELECT * FROM raw_materials WHERE name=?", (name,))
    else:
        conn.close()
        return None
        
    result = cursor.fetchone()
    conn.close()
    return result

# تابع افزودن محصول جدید
def add_product(name, materials):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute(
            "INSERT INTO products (name, materials) VALUES (?, ?)",
            (name, materials)
        )
        conn.commit()
        conn.close()
        return True, "محصول با موفقیت ثبت شد"
    except sqlite3.IntegrityError:
        return False, "نام محصول تکراری است"
    except Exception as e:
        return False, f"خطا در افزودن محصول: {str(e)}"

# تابع ویرایش محصول
def edit_product(id, name, materials):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if product exists
        cursor.execute("SELECT * FROM products WHERE id=?", (id,))
        current = cursor.fetchone()
        
        if not current:
            conn.close()
            return False, "محصول یافت نشد"
        
        # Check if name is being changed and is unique
        if current['name'] != name:
            cursor.execute("SELECT id FROM products WHERE name=? AND id!=?", (name, id))
            if cursor.fetchone():
                conn.close()
                return False, "نام محصول تکراری است"
        
        # Validate materials format
        try:
            materials_list = materials.split(',')
            for material_str in materials_list:
                parts = material_str.strip().split(':')
                if len(parts) != 2:
                    return False, "فرمت مواد اولیه صحیح نیست"
                
                material_name = parts[0].strip()
                material_qty = float(parts[1].strip())
                
                # Check if material exists
                cursor.execute("SELECT * FROM raw_materials WHERE name=?", (material_name,))
                if not cursor.fetchone():
                    conn.close()
                    return False, f"ماده اولیه {material_name} وجود ندارد"
        except ValueError:
            conn.close()
            return False, "مقدار مواد باید عددی باشد"
        
        # Update the product
        cursor.execute(
            "UPDATE products SET name=?, materials=? WHERE id=?",
            (name, materials, id)
        )
        conn.commit()
        conn.close()
        return True, "محصول با موفقیت ویرایش شد"
    except Exception as e:
        return False, f"خطا در ویرایش محصول: {str(e)}"

# تابع حذف محصول
def delete_product(id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if product exists
        cursor.execute("SELECT * FROM products WHERE id=?", (id,))
        product = cursor.fetchone()
        
        if not product:
            conn.close()
            return False, "محصول یافت نشد"
        
        # Check if product is used in any production transaction
        cursor.execute("SELECT * FROM transactions WHERE type='تولید' AND item=?", (product['name'],))
        if cursor.fetchone():
            conn.close()
            return False, "این محصول در تاریخچه تولید استفاده شده و قابل حذف نیست"
        
        # Delete the product
        cursor.execute("DELETE FROM products WHERE id=?", (id,))
        conn.commit()
        conn.close()
        return True, "محصول با موفقیت حذف شد"
    except Exception as e:
        return False, f"خطا در حذف محصول: {str(e)}"

# تابع دریافت لیست تمام محصولات
def get_all_products():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM products ORDER BY name")
    results = cursor.fetchall()
    conn.close()
    return results

# تابع دریافت اطلاعات یک محصول
def get_product(name=None, id=None):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    if id:
        cursor.execute("SELECT * FROM products WHERE id=?", (id,))
    elif name:
        cursor.execute("SELECT * FROM products WHERE name=?", (name,))
    else:
        conn.close()
        return None
        
    result = cursor.fetchone()
    conn.close()
    return result

# تابع ثبت تراکنش جدید
def add_transaction(trans_type, item, change, remaining, notes=""):
    date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute(
            "INSERT INTO transactions (date, type, item, change, remaining, notes) VALUES (?, ?, ?, ?, ?, ?)",
            (date, trans_type, item, change, remaining, notes)
        )
        conn.commit()
        conn.close()
        return True, "تراکنش با موفقیت ثبت شد"
    except Exception as e:
        return False, f"خطا در ثبت تراکنش: {str(e)}"

# تابع حذف تراکنش
def delete_transaction(id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if transaction exists
        cursor.execute("SELECT * FROM transactions WHERE id=?", (id,))
        transaction = cursor.fetchone()
        
        if not transaction:
            conn.close()
            return False, "تراکنش یافت نشد"
        
        # If it's a material transaction, we need to revert the quantity
        if transaction['type'] in ['ورود', 'خروج']:
            material_name = transaction['item']
            change_amount = transaction['change']
            
            # For safety, get the latest material data
            cursor.execute("SELECT * FROM raw_materials WHERE name=?", (material_name,))
            material = cursor.fetchone()
            
            if material:
                # Reverse the change (subtract for entry, add for exit)
                if transaction['type'] == 'ورود':
                    new_quantity = max(0, float(material['quantity']) - float(change_amount))
                else:  # خروج
                    new_quantity = float(material['quantity']) + abs(float(change_amount))
                
                # Update the material quantity
                cursor.execute(
                    "UPDATE raw_materials SET quantity=? WHERE name=?",
                    (new_quantity, material_name)
                )
                
                # Add a reversal transaction
                cursor.execute(
                    "INSERT INTO transactions (date, type, item, change, remaining, notes) VALUES (?, ?, ?, ?, ?, ?)",
                    (
                        datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        "برگشت",
                        material_name,
                        -change_amount if transaction['type'] == 'ورود' else abs(change_amount),
                        new_quantity,
                        f"برگشت تراکنش {id}"
                    )
                )
        
        # Delete the transaction
        cursor.execute("DELETE FROM transactions WHERE id=?", (id,))
        conn.commit()
        conn.close()
        return True, "تراکنش با موفقیت حذف شد"
    except Exception as e:
        return False, f"خطا در حذف تراکنش: {str(e)}"

# تابع دریافت تراکنش‌ها
def get_transactions(item=None, trans_type=None, limit=100):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    query = "SELECT * FROM transactions"
    params = []
    
    # اعمال فیلترها
    conditions = []
    if item:
        conditions.append("item=?")
        params.append(item)
    if trans_type:
        conditions.append("type=?")
        params.append(trans_type)
    
    if conditions:
        query += " WHERE " + " AND ".join(conditions)
    
    query += " ORDER BY date DESC LIMIT ?"
    params.append(limit)
    
    cursor.execute(query, params)
    results = cursor.fetchall()
    conn.close()
    return results

# تابع دریافت یک تراکنش
def get_transaction(id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM transactions WHERE id=?", (id,))
    result = cursor.fetchone()
    conn.close()
    return result

# توابع مدیریت قطعات در حال تولید

# افزودن قطعه در حال تولید جدید
def add_in_production_item(product_id, quantity, start_date, estimated_completion_date=None, notes=""):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # بررسی وجود محصول
        cursor.execute("SELECT * FROM products WHERE id=?", (product_id,))
        product = cursor.fetchone()
        if not product:
            conn.close()
            return False, "محصول مورد نظر یافت نشد"
        
        # تجزیه لیست مواد مصرفی
        materials_list = product['materials'].split(',')
        materials_dict = {}
        
        for material_str in materials_list:
            parts = material_str.strip().split(':')
            if len(parts) != 2:
                continue
            
            material_name = parts[0].strip()
            material_qty = float(parts[1].strip())
            materials_dict[material_name] = material_qty
        
        # بررسی موجودی کافی برای همه مواد
        for material_name, material_qty in materials_dict.items():
            cursor.execute("SELECT * FROM raw_materials WHERE name=?", (material_name,))
            raw_material = cursor.fetchone()
            if not raw_material:
                conn.close()
                return False, f"ماده اولیه {material_name} یافت نشد"
            
            total_needed = material_qty * float(quantity)
            if raw_material['quantity'] < total_needed:
                conn.close()
                return False, f"موجودی {material_name} کافی نیست"
        
        # کاهش موجودی مواد اولیه
        for material_name, material_qty in materials_dict.items():
            total_needed = material_qty * float(quantity)
            
            # محاسبه موجودی جدید
            cursor.execute("SELECT quantity FROM raw_materials WHERE name=?", (material_name,))
            current_qty = cursor.fetchone()['quantity']
            new_qty = current_qty - total_needed
            
            # به‌روزرسانی موجودی
            cursor.execute(
                "UPDATE raw_materials SET quantity=? WHERE name=?",
                (new_qty, material_name)
            )
            
            # ثبت تراکنش مصرف
            cursor.execute(
                "INSERT INTO transactions (date, type, item, change, remaining, notes) VALUES (?, ?, ?, ?, ?, ?)",
                (
                    datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "خروج",
                    material_name,
                    -total_needed,
                    new_qty,
                    f"مصرف در شروع تولید {product['name']} - تعداد: {quantity}"
                )
            )
        
        # افزودن قطعه به لیست در حال تولید
        cursor.execute(
            """
            INSERT INTO in_production_items 
            (product_id, quantity, start_date, estimated_completion_date, status, notes) 
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                product_id, 
                quantity, 
                start_date, 
                estimated_completion_date, 
                "در حال تولید", 
                notes
            )
        )
        
        conn.commit()
        conn.close()
        return True, "قطعه با موفقیت به لیست تولید اضافه شد"
    except Exception as e:
        return False, f"خطا در افزودن قطعه به لیست تولید: {str(e)}"

# دریافت لیست قطعات در حال تولید
def get_in_production_items():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT i.*, p.name as product_name 
        FROM in_production_items i
        JOIN products p ON i.product_id = p.id
        ORDER BY i.start_date DESC
    """)
    results = cursor.fetchall()
    conn.close()
    return results

# دریافت اطلاعات یک قطعه در حال تولید
def get_in_production_item(id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT i.*, p.name as product_name, p.materials 
        FROM in_production_items i
        JOIN products p ON i.product_id = p.id
        WHERE i.id = ?
    """, (id,))
    result = cursor.fetchone()
    conn.close()
    return result

# به‌روزرسانی وضعیت تولید
def update_production_status(id, status, notes=None):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # بررسی وجود قطعه در حال تولید
        cursor.execute("""
            SELECT i.*, p.name as product_name 
            FROM in_production_items i
            JOIN products p ON i.product_id = p.id
            WHERE i.id = ?
        """, (id,))
        item = cursor.fetchone()
        
        if not item:
            conn.close()
            return False, "قطعه در حال تولید یافت نشد"
        
        # ویرایش یادداشت‌ها اگر وجود داشته باشد
        if notes:
            note_update = f", notes = '{notes}'" 
        else:
            note_update = ""
        
        # به‌روزرسانی وضعیت
        cursor.execute(
            f"UPDATE in_production_items SET status = ? {note_update} WHERE id = ?",
            (status, id)
        )
        
        # اگر وضعیت "تکمیل شده" باشد، ثبت تراکنش تولید
        if status == "تکمیل شده":
            # ثبت تراکنش تولید
            cursor.execute(
                "INSERT INTO transactions (date, type, item, change, remaining, notes) VALUES (?, ?, ?, ?, ?, ?)",
                (
                    datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "تولید",
                    item['product_name'],
                    item['quantity'],
                    None,
                    f"تکمیل تولید شروع شده در تاریخ {item['start_date']}"
                )
            )
        
        conn.commit()
        conn.close()
        return True, "وضعیت تولید با موفقیت به‌روز شد"
    except Exception as e:
        return False, f"خطا در به‌روزرسانی وضعیت تولید: {str(e)}"

# حذف قطعه در حال تولید
def delete_in_production_item(id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # بررسی وجود قطعه در حال تولید
        cursor.execute("""
            SELECT i.*, p.name as product_name 
            FROM in_production_items i
            JOIN products p ON i.product_id = p.id
            WHERE i.id = ?
        """, (id,))
        item = cursor.fetchone()
        
        if not item:
            conn.close()
            return False, "قطعه در حال تولید یافت نشد"
        
        # حذف قطعه
        cursor.execute("DELETE FROM in_production_items WHERE id = ?", (id,))
        
        conn.commit()
        conn.close()
        return True, "قطعه از لیست تولید حذف شد"
    except Exception as e:
        return False, f"خطا در حذف قطعه از لیست تولید: {str(e)}"

# تابع ثبت تولید
def record_production(product_name, quantity, date, notes=""):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # دریافت اطلاعات محصول
        cursor.execute("SELECT * FROM products WHERE name=?", (product_name,))
        product = cursor.fetchone()
        if not product:
            conn.close()
            return False, "محصول یافت نشد"
        
        # تجزیه لیست مواد مصرفی
        materials_list = product['materials'].split(',')
        materials_dict = {}
        
        for material_str in materials_list:
            parts = material_str.strip().split(':')
            if len(parts) != 2:
                continue
            
            material_name = parts[0].strip()
            material_qty = float(parts[1].strip())
            materials_dict[material_name] = material_qty
        
        # بررسی موجودی کافی برای همه مواد
        for material_name, material_qty in materials_dict.items():
            cursor.execute("SELECT * FROM raw_materials WHERE name=?", (material_name,))
            raw_material = cursor.fetchone()
            if not raw_material:
                conn.close()
                return False, f"ماده اولیه {material_name} یافت نشد"
            
            total_needed = material_qty * float(quantity)
            if raw_material['quantity'] < total_needed:
                conn.close()
                return False, f"موجودی {material_name} کافی نیست"
        
        # کاهش موجودی مواد اولیه
        for material_name, material_qty in materials_dict.items():
            total_needed = material_qty * float(quantity)
            
            # محاسبه موجودی جدید
            cursor.execute("SELECT quantity FROM raw_materials WHERE name=?", (material_name,))
            current_qty = cursor.fetchone()['quantity']
            new_qty = current_qty - total_needed
            
            # به‌روزرسانی موجودی
            cursor.execute(
                "UPDATE raw_materials SET quantity=? WHERE name=?",
                (new_qty, material_name)
            )
            
            # ثبت تراکنش مصرف
            cursor.execute(
                "INSERT INTO transactions (date, type, item, change, remaining, notes) VALUES (?, ?, ?, ?, ?, ?)",
                (
                    datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "خروج",
                    material_name,
                    -total_needed,
                    new_qty,
                    f"مصرف در تولید {product_name} - تعداد: {quantity}"
                )
            )
        
        # ثبت تراکنش تولید
        cursor.execute(
            "INSERT INTO transactions (date, type, item, change, remaining, notes) VALUES (?, ?, ?, ?, ?, ?)",
            (
                datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "تولید",
                product_name,
                quantity,
                None,
                f"تولید در تاریخ {date} - {notes}"
            )
        )
        
        conn.commit()
        conn.close()
        return True, "تولید با موفقیت ثبت شد"
    except Exception as e:
        return False, f"خطا در ثبت تولید: {str(e)}"

# تابع گزارش تولید
def get_production_report(limit=100):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT * FROM transactions WHERE type='تولید' ORDER BY date DESC LIMIT ?", 
        (limit,)
    )
    results = cursor.fetchall()
    conn.close()
    return results

# تابع گزارش موجودی
def get_inventory_report():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM raw_materials ORDER BY name")
    results = cursor.fetchall()
    conn.close()
    return results

# تابع تهیه نمودار موجودی
def create_inventory_chart():
    materials = get_all_raw_materials()
    
    if not materials:
        return None
    
    # تبدیل به DataFrame
    df = pd.DataFrame([(m['name'], float(m['quantity']), m['unit']) for m in materials], 
                     columns=['name', 'quantity', 'unit'])
    
    # ایجاد نمودار میله‌ای با رنگ آبی
    fig = go.Figure()
    fig.add_trace(go.Bar(
        x=df['name'],
        y=df['quantity'],
        text=[f"{q} {u}" for q, u in zip(df['quantity'], df['unit'])],
        textposition='auto',
        marker_color='rgba(13, 110, 253, 0.7)',
        marker_line_color='rgba(12, 99, 228, 1.0)',
        marker_line_width=1.5,
        hoverinfo='x+y',
        hovertemplate='<b>%{x}</b><br>موجودی: %{text}<extra></extra>'
    ))
    
    fig.update_layout(
        title={
            'text': 'موجودی مواد اولیه',
            'y': 0.95,
            'x': 0.5,
            'xanchor': 'center',
            'yanchor': 'top',
            'font': dict(size=20, color='#0d6efd')
        },
        xaxis_title='ماده اولیه',
        yaxis_title='مقدار',
        template='plotly_white',
        height=500,
        plot_bgcolor='rgba(240, 249, 255, 0.5)',
        paper_bgcolor='rgba(255, 255, 255, 0.0)',
        font=dict(family="Tahoma, Arial, sans-serif", color="#333"),
        xaxis=dict(tickangle=-45),
        yaxis=dict(gridcolor='rgba(230, 230, 230, 0.5)'),
        hoverlabel=dict(
            bgcolor="white",
            font_size=14,
            font_family="Tahoma, Arial, sans-serif"
        )
    )
    
    # افزودن رنگ قرمز برای موجودی کم
    for i, qty in enumerate(df['quantity']):
        if qty < 10:  # آستانه موجودی کم
            fig.add_shape(
                type="rect",
                x0=i-0.4, x1=i+0.4,
                y0=0, y1=qty,
                fillcolor="rgba(220, 53, 69, 0.3)",
                line_width=0,
                layer="below"
            )
    
    return json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)

# تابع ایجاد نمودار دایره‌ای موجودی
def create_inventory_pie_chart():
    materials = get_all_raw_materials()
    
    if not materials:
        return None
    
    # انتخاب ۱۰ ماده اولیه با بیشترین موجودی
    materials_sorted = sorted(materials, key=lambda x: float(x['quantity']), reverse=True)
    top_materials = materials_sorted[:10]
    
    # آماده‌سازی داده‌ها
    labels = [m['name'] for m in top_materials]
    values = [float(m['quantity']) for m in top_materials]
    units = [m['unit'] for m in top_materials]
    
    # ایجاد رنگ‌های مناسب با تم آبی
    colors = [
        '#0d6efd', '#3d8bfd', '#6ea8fe', '#9ec5fe', '#c5e0ff',
        '#0a58ca', '#084298', '#cfe2ff', '#0dcaf0', '#9eeaf9'
    ]
    
    # ایجاد نمودار دایره‌ای
    fig = go.Figure()
    fig.add_trace(go.Pie(
        labels=labels,
        values=values,
        textinfo='label+percent',
        hovertemplate='<b>%{label}</b><br>مقدار: %{value} %{text}<extra></extra>',
        text=units,  # واحد در متن نمایش داده می‌شود
        marker=dict(colors=colors),
        hole=0.3
    ))
    
    fig.update_layout(
        title={
            'text': 'توزیع موجودی مواد اولیه (۱۰ مورد برتر)',
            'y': 0.95,
            'x': 0.5,
            'xanchor': 'center',
            'yanchor': 'top',
            'font': dict(size=20, color='#0d6efd')
        },
        template='plotly_white',
        height=500,
        plot_bgcolor='rgba(240, 249, 255, 0.5)',
        paper_bgcolor='rgba(255, 255, 255, 0.0)',
        font=dict(family="Tahoma, Arial, sans-serif", color="#333"),
        hoverlabel=dict(
            bgcolor="white",
            font_size=14,
            font_family="Tahoma, Arial, sans-serif"
        ),
        legend=dict(
            orientation="h",
            y=-0.1
        )
    )
    
    return json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)

# تابع تهیه نمودار تراکنش‌ها
def create_transactions_chart(days=30):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # دریافت تراکنش‌های ورود و خروج در بازه زمانی
    query = """
    SELECT date, type, SUM(change) as total_change
    FROM transactions
    WHERE type IN ('ورود', 'خروج') AND date >= date('now', ?)
    GROUP BY date(date), type
    ORDER BY date
    """
    cursor.execute(query, (f'-{days} days',))
    results = cursor.fetchall()
    conn.close()
    
    if not results:
        return None
    
    # تبدیل به DataFrame
    df = pd.DataFrame([(r['date'][:10], r['type'], float(r['total_change'])) for r in results],
                     columns=['date', 'type', 'change'])
    
    # پرداز داده‌ها برای نمودار
    df_pivot = df.pivot_table(index='date', columns='type', values='change', aggfunc='sum').fillna(0)
    
    # اطمینان از وجود ستون‌های مورد نیاز
    if 'ورود' not in df_pivot.columns:
        df_pivot['ورود'] = 0
    if 'خروج' not in df_pivot.columns:
        df_pivot['خروج'] = 0
    
    # تبدیل مقادیر منفی خروج به مثبت برای نمایش
    if 'خروج' in df_pivot.columns:
        df_pivot['خروج'] = df_pivot['خروج'].abs()
    
    # ایجاد نمودار
    fig = make_subplots(specs=[[{"secondary_y": True}]])
    
    fig.add_trace(
        go.Bar(
            x=df_pivot.index,
            y=df_pivot['ورود'],
            name='ورود',
            marker_color='rgba(13, 110, 253, 0.7)',
            marker_line_color='rgba(13, 110, 253, 1.0)',
            marker_line_width=1.5,
            hovertemplate='<b>%{x}</b><br>ورود: %{y}<extra></extra>'
        ),
        secondary_y=False
    )
    
    fig.add_trace(
        go.Bar(
            x=df_pivot.index,
            y=df_pivot['خروج'],
            name='خروج',
            marker_color='rgba(220, 53, 69, 0.7)',
            marker_line_color='rgba(220, 53, 69, 1.0)',
            marker_line_width=1.5,
            hovertemplate='<b>%{x}</b><br>خروج: %{y}<extra></extra>'
        ),
        secondary_y=False
    )
    
    fig.update_layout(
        title={
            'text': f'تراکنش‌های {days} روز اخیر',
            'y': 0.95,
            'x': 0.5,
            'xanchor': 'center',
            'yanchor': 'top',
            'font': dict(size=20, color='#0d6efd')
        },
        xaxis_title='تاریخ',
        yaxis_title='مقدار',
        barmode='group',
        template='plotly_white',
        plot_bgcolor='rgba(240, 249, 255, 0.5)',
        paper_bgcolor='rgba(255, 255, 255, 0.0)',
        hoverlabel=dict(
            bgcolor="white",
            font_size=14,
            font_family="Tahoma, Arial, sans-serif"
        ),
        height=500
    )
    
    return json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)

# ------------------ ROUTES ------------------

@app.route('/')
def index():
    # Initialize database if it doesn't exist
    init_db()
    
    raw_materials = get_all_raw_materials()
    products = get_all_products()
    transactions = get_transactions(limit=30)
    productions = get_production_report(5)
    in_production = get_in_production_items()
    
    # نمودار موجودی
    inventory_chart = create_inventory_chart()
    
    # نمودار تراکنش‌ها
    transactions_chart = create_transactions_chart()
    
    return render_template('index.html', 
                          raw_materials=raw_materials,
                          products=products,
                          transactions=transactions,
                          productions=productions,
                          in_production=in_production,
                          inventory_chart=inventory_chart,
                          transactions_chart=transactions_chart)

# مدیریت مواد اولیه
@app.route('/raw_materials')
def raw_materials():
    materials = get_all_raw_materials()
    return render_template('raw_materials.html', materials=materials)

@app.route('/raw_materials/add', methods=['POST'])
def add_raw_material_route():
    name = request.form.get('name')
    quantity = request.form.get('quantity')
    unit = request.form.get('unit')
    
    if not name or not quantity or not unit:
        flash('تمام فیلدها را پر کنید', 'error')
        return redirect(url_for('raw_materials'))
    
    try:
        quantity = float(quantity)
    except ValueError:
        flash('مقدار باید عددی باشد', 'error')
        return redirect(url_for('raw_materials'))
    
    success, message = add_raw_material(name, quantity, unit)
    
    if success:
        flash(message, 'success')
    else:
        flash(message, 'error')
    
    return redirect(url_for('raw_materials'))

@app.route('/raw_materials/update', methods=['POST'])
def update_raw_material_route():
    name = request.form.get('name')
    quantity_change = request.form.get('quantity_change')
    note = request.form.get('note', '')
    
    if not name or not quantity_change:
        flash('نام و مقدار تغییر را وارد کنید', 'error')
        return redirect(url_for('raw_materials'))
    
    try:
        quantity_change = float(quantity_change)
    except ValueError:
        flash('مقدار تغییر باید عددی باشد', 'error')
        return redirect(url_for('raw_materials'))
    
    success, message = update_raw_material(name, quantity_change, note)
    
    if success:
        flash(message, 'success')
    else:
        flash(message, 'error')
    
    return redirect(url_for('raw_materials'))

@app.route('/raw_materials/edit/<int:id>', methods=['GET', 'POST'])
def edit_raw_material_route(id):
    if request.method == 'POST':
        name = request.form.get('name')
        quantity = request.form.get('quantity')
        unit = request.form.get('unit')
        
        if not name or not quantity or not unit:
            flash('تمام فیلدها را پر کنید', 'error')
            return redirect(url_for('raw_materials'))
        
        try:
            quantity = float(quantity)
        except ValueError:
            flash('مقدار باید عددی باشد', 'error')
            return redirect(url_for('raw_materials'))
        
        success, message = edit_raw_material(id, name, quantity, unit)
        
        if success:
            flash(message, 'success')
        else:
            flash(message, 'error')
        
        return redirect(url_for('raw_materials'))
    else:
        material = get_raw_material(id=id)
        if not material:
            flash('ماده اولیه یافت نشد', 'error')
            return redirect(url_for('raw_materials'))
        
        return render_template('raw_materials.html', 
                              materials=get_all_raw_materials(), 
                              edit_material=material)

@app.route('/raw_materials/delete/<int:id>', methods=['GET', 'POST'])
def delete_raw_material_route(id):
    if request.method == 'POST':
        if request.form.get('confirm') == 'yes':
            success, message = delete_raw_material(id)
            
            if success:
                flash(message, 'success')
            else:
                flash(message, 'error')
        
        return redirect(url_for('raw_materials'))
    else:
        material = get_raw_material(id=id)
        if not material:
            flash('ماده اولیه یافت نشد', 'error')
            return redirect(url_for('raw_materials'))
        
        return render_template('confirm_delete.html', 
                              item=material, 
                              item_type='raw_material',
                              redirect_url=url_for('raw_materials'))

# مدیریت محصولات
@app.route('/products')
def products():
    all_products = get_all_products()
    materials = get_all_raw_materials()
    return render_template('products.html', products=all_products, materials=materials)

@app.route('/products/add', methods=['POST'])
def add_product_route():
    name = request.form.get('name')
    materials = request.form.get('materials')
    
    if not name or not materials:
        flash('تمام فیلدها را پر کنید', 'error')
        return redirect(url_for('products'))
    
    success, message = add_product(name, materials)
    
    if success:
        flash(message, 'success')
    else:
        flash(message, 'error')
    
    return redirect(url_for('products'))

@app.route('/products/edit/<int:id>', methods=['GET', 'POST'])
def edit_product_route(id):
    if request.method == 'POST':
        name = request.form.get('name')
        materials = request.form.get('materials')
        
        if not name or not materials:
            flash('تمام فیلدها را پر کنید', 'error')
            return redirect(url_for('products'))
        
        success, message = edit_product(id, name, materials)
        
        if success:
            flash(message, 'success')
        else:
            flash(message, 'error')
        
        return redirect(url_for('products'))
    else:
        product = get_product(id=id)
        if not product:
            flash('محصول یافت نشد', 'error')
            return redirect(url_for('products'))
        
        return render_template('products.html', 
                              products=get_all_products(), 
                              materials=get_all_raw_materials(),
                              edit_product=product)

@app.route('/products/delete/<int:id>', methods=['GET', 'POST'])
def delete_product_route(id):
    if request.method == 'POST':
        if request.form.get('confirm') == 'yes':
            success, message = delete_product(id)
            
            if success:
                flash(message, 'success')
            else:
                flash(message, 'error')
        
        return redirect(url_for('products'))
    else:
        product = get_product(id=id)
        if not product:
            flash('محصول یافت نشد', 'error')
            return redirect(url_for('products'))
        
        return render_template('confirm_delete.html', 
                              item=product, 
                              item_type='product',
                              redirect_url=url_for('products'))

@app.route('/products/view/<int:id>')
def view_product(id):
    product = get_product(id=id)
    if not product:
        flash('محصول یافت نشد', 'error')
        return redirect(url_for('products'))
    
    # تجزیه لیست مواد مصرفی
    materials_list = product['materials'].split(',')
    materials_info = []
    
    for material_str in materials_list:
        parts = material_str.strip().split(':')
        if len(parts) != 2:
            continue
        
        material_name = parts[0].strip()
        material_qty = float(parts[1].strip())
        
        # دریافت اطلاعات ماده اولیه
        material = get_raw_material(name=material_name)
        if material:
            materials_info.append({
                'name': material_name,
                'quantity': material_qty,
                'unit': material['unit'],
                'available': material['quantity']
            })
    
    return render_template('product_details.html', product=product, materials=materials_info)

# مدیریت تولیدات
@app.route('/production')
def production():
    products = get_all_products()
    productions = get_production_report(10)
    in_production = get_in_production_items()
    return render_template('production.html', products=products, productions=productions, in_production=in_production)

@app.route('/production/record', methods=['POST'])
def record_production_route():
    product_name = request.form.get('product')
    quantity = request.form.get('quantity')
    date = request.form.get('date')
    notes = request.form.get('notes', '')
    
    if not product_name or not quantity or not date:
        flash('تمام فیلدهای ضروری را پر کنید', 'error')
        return redirect(url_for('production'))
    
    try:
        quantity = float(quantity)
        if quantity <= 0:
            flash('مقدار تولید باید عددی مثبت باشد', 'error')
            return redirect(url_for('production'))
    except ValueError:
        flash('مقدار تولید باید عددی باشد', 'error')
        return redirect(url_for('production'))
    
    success, message = record_production(product_name, quantity, date, notes)
    
    if success:
        flash(message, 'success')
    else:
        flash(message, 'error')
    
    return redirect(url_for('production'))

# مدیریت قطعات در حال تولید
@app.route('/in-production')
def in_production():
    products = get_all_products()
    in_production_items = get_in_production_items()
    return render_template('in_production.html', products=products, in_production=in_production_items)

@app.route('/in-production/add', methods=['POST'])
def add_in_production_route():
    product_id = request.form.get('product_id')
    quantity = request.form.get('quantity')
    start_date = request.form.get('start_date')
    estimated_completion_date = request.form.get('estimated_completion_date', '')
    notes = request.form.get('notes', '')
    
    if not product_id or not quantity or not start_date:
        flash('لطفاً تمام فیلدهای الزامی را وارد کنید', 'error')
        return redirect(url_for('in_production'))
    
    try:
        quantity = int(quantity)
        if quantity <= 0:
            flash('تعداد باید عددی مثبت باشد', 'error')
            return redirect(url_for('in_production'))
    except ValueError:
        flash('تعداد باید عددی صحیح باشد', 'error')
        return redirect(url_for('in_production'))
    
    success, message = add_in_production_item(product_id, quantity, start_date, estimated_completion_date, notes)
    
    if success:
        flash(message, 'success')
    else:
        flash(message, 'error')
    
    return redirect(url_for('in_production'))

@app.route('/in-production/view/<int:id>')
def view_in_production(id):
    item = get_in_production_item(id)
    if not item:
        flash('قطعه در حال تولید یافت نشد', 'error')
        return redirect(url_for('in_production'))
    
    return render_template('view_in_production.html', item=item)

@app.route('/in-production/update/<int:id>', methods=['POST'])
def update_in_production_status_route(id):
    status = request.form.get('status')
    notes = request.form.get('notes', None)
    
    if not status:
        flash('لطفاً وضعیت را وارد کنید', 'error')
        return redirect(url_for('view_in_production', id=id))
    
    success, message = update_production_status(id, status, notes)
    
    if success:
        flash(message, 'success')
    else:
        flash(message, 'error')
    
    return redirect(url_for('in_production'))

@app.route('/in-production/delete/<int:id>', methods=['GET', 'POST'])
def delete_in_production_route(id):
    if request.method == 'POST':
        confirm = request.form.get('confirm')
        
        if confirm != 'yes':
            return redirect(url_for('in_production'))
        
        success, message = delete_in_production_item(id)
        
        if success:
            flash(message, 'success')
        else:
            flash(message, 'error')
        
        return redirect(url_for('in_production'))
    else:
        item = get_in_production_item(id)
        if not item:
            flash('قطعه در حال تولید یافت نشد', 'error')
            return redirect(url_for('in_production'))
        
        return render_template('confirm_delete.html', 
                              item=item, 
                              item_type='in_production', 
                              redirect_url=url_for('in_production'))

# گزارش تراکنش‌ها
@app.route('/transactions')
def transactions():
    item = request.args.get('item')
    trans_type = request.args.get('type')
    
    all_transactions = get_transactions(item, trans_type)
    return render_template('transactions.html', transactions=all_transactions)

@app.route('/transactions/delete/<int:id>', methods=['GET', 'POST'])
def delete_transaction_route(id):
    if request.method == 'POST':
        if request.form.get('confirm') == 'yes':
            success, message = delete_transaction(id)
            
            if success:
                flash(message, 'success')
            else:
                flash(message, 'error')
        
        return redirect(url_for('transactions'))
    else:
        transaction = get_transaction(id)
        if not transaction:
            flash('تراکنش یافت نشد', 'error')
            return redirect(url_for('transactions'))
        
        return render_template('confirm_delete.html', 
                              item=transaction, 
                              item_type='transaction',
                              redirect_url=url_for('transactions'))

# گزارشات
@app.route('/report')
def report():
    inventory_chart = create_inventory_chart()
    transactions_chart = create_transactions_chart()
    pie_chart = create_inventory_pie_chart()
    
    materials = get_all_raw_materials()
    productions = get_production_report(10)
    recent_transactions = get_transactions(limit=10)
    
    return render_template('report.html', 
                         inventory_chart=inventory_chart,
                         transactions_chart=transactions_chart,
                         pie_chart=pie_chart,
                         materials=materials,
                         productions=productions,
                         transactions=recent_transactions)

# خروجی CSV
@app.route('/export_inventory_csv')
def export_inventory_csv():
    materials = get_all_raw_materials()
    
    si = io.StringIO()
    writer = csv.writer(si)
    writer.writerow(['نام', 'مقدار', 'واحد'])
    
    for material in materials:
        writer.writerow([material['name'], material['quantity'], material['unit']])
    
    output = make_response(si.getvalue())
    output.headers["Content-Disposition"] = "attachment; filename=inventory.csv"
    output.headers["Content-type"] = "text/csv"
    
    return output

@app.route('/export_transactions_csv')
def export_transactions_csv():
    transactions = get_transactions(limit=1000)
    
    si = io.StringIO()
    writer = csv.writer(si)
    writer.writerow(['تاریخ', 'نوع', 'آیتم', 'مقدار تغییر', 'مقدار باقیمانده', 'توضیحات'])
    
    for trans in transactions:
        writer.writerow([
            trans['date'], 
            trans['type'], 
            trans['item'], 
            trans['change'],
            trans['remaining'] if trans['remaining'] is not None else '',
            trans['notes']
        ])
    
    output = make_response(si.getvalue())
    output.headers["Content-Disposition"] = "attachment; filename=transactions.csv"
    output.headers["Content-type"] = "text/csv"
    
    return output

if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=5000, debug=True)
