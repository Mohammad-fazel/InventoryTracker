#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, Response, make_response
import sqlite3
import json
import plotly
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
from datetime import datetime, date
import os
import csv
import io
import logging

# Set up logging
logging.basicConfig(level=logging.DEBUG)

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "inventory_management_system")
app.config['DATABASE'] = 'inventory.db'

def get_db_connection():
    conn = sqlite3.connect(app.config['DATABASE'])
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # جدول مواد اولیه
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS raw_materials (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL,
        quantity REAL NOT NULL,
        unit TEXT NOT NULL
    )
    """)
    
    # جدول محصولات
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL,
        materials TEXT NOT NULL
    )
    """)
    
    # جدول تراکنش‌ها
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        date TEXT NOT NULL,
        type TEXT NOT NULL,
        item TEXT NOT NULL,
        change REAL NOT NULL,
        remaining REAL,
        notes TEXT
    )
    """)
    
    # جدول قطعات در حال تولید
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS in_production_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER NOT NULL,
        quantity INTEGER NOT NULL,
        start_date TEXT NOT NULL,
        estimated_completion_date TEXT,
        status TEXT NOT NULL,
        notes TEXT,
        FOREIGN KEY (product_id) REFERENCES products(id)
    )
    """)
    
    conn.commit()
    conn.close()

# تابع افزودن ماده اولیه
def add_raw_material(name, quantity, unit):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute(
            "INSERT INTO raw_materials (name, quantity, unit) VALUES (?, ?, ?)",
            (name, quantity, unit)
        )
        conn.commit()
        
        # ثبت تراکنش
        add_transaction("ورود", name, quantity, quantity, "افزودن ماده اولیه جدید")
        
        conn.close()
        return True, "ماده اولیه با موفقیت اضافه شد"
    except sqlite3.IntegrityError:
        return False, "نام ماده اولیه تکراری است"
    except Exception as e:
        return False, f"خطا در افزودن ماده اولیه: {str(e)}"

# تابع به‌روزرسانی موجودی ماده اولیه
def update_raw_material(name, quantity_change, note=""):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT quantity FROM raw_materials WHERE name=?", (name,))
        result = cursor.fetchone()
        
        if not result:
            conn.close()
            return False, "ماده اولیه یافت نشد"
        
        current_quantity = float(result['quantity'])
        new_quantity = current_quantity + float(quantity_change)
        
        if new_quantity < 0:
            conn.close()
            return False, "موجودی کافی نیست"
        
        cursor.execute(
            "UPDATE raw_materials SET quantity=? WHERE name=?",
            (new_quantity, name)
        )
        conn.commit()
        
        # ثبت تراکنش
        trans_type = "ورود" if quantity_change > 0 else "خروج"
        add_transaction(trans_type, name, quantity_change, new_quantity, note)
        
        conn.close()
        return True, "موجودی با موفقیت به‌روز شد"
    except Exception as e:
        return False, f"خطا در به‌روزرسانی موجودی: {str(e)}"

# تابع ویرایش ماده اولیه
def edit_raw_material(id, name, quantity, unit):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get current data to check for changes
        cursor.execute("SELECT * FROM raw_materials WHERE id=?", (id,))
        current = cursor.fetchone()
        
        if not current:
            conn.close()
            return False, "ماده اولیه یافت نشد"
        
        # Check if name is being changed and is unique
        if current['name'] != name:
            cursor.execute("SELECT id FROM raw_materials WHERE name=? AND id!=?", (name, id))
            if cursor.fetchone():
                conn.close()
                return False, "نام ماده اولیه تکراری است"
        
        # Calculate quantity difference for transaction log
        quantity_diff = float(quantity) - float(current['quantity'])
        
        # Update the raw material
        cursor.execute(
            "UPDATE raw_materials SET name=?, quantity=?, unit=? WHERE id=?",
            (name, quantity, unit, id)
        )
        conn.commit()
        
        # Record transaction if quantity changed
        if quantity_diff != 0:
            trans_type = "ورود" if quantity_diff > 0 else "خروج"
            add_transaction(trans_type, name, abs(quantity_diff), quantity, "ویرایش ماده اولیه")
        
        conn.close()
        return True, "ماده اولیه با موفقیت ویرایش شد"
    except Exception as e:
        return False, f"خطا در ویرایش ماده اولیه: {str(e)}"

# تابع حذف ماده اولیه
def delete_raw_material(id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get the material info for the transaction record
        cursor.execute("SELECT * FROM raw_materials WHERE id=?", (id,))
        material = cursor.fetchone()
        
        if not material:
            conn.close()
            return False, "ماده اولیه یافت نشد"
        
        # Check if this material is used in any product
        cursor.execute("SELECT * FROM products")
        products = cursor.fetchall()
        
        for product in products:
            materials_list = product['materials'].split(',')
            for material_str in materials_list:
                parts = material_str.strip().split(':')
                if len(parts) == 2 and parts[0].strip() == material['name']:
                    conn.close()
                    return False, f"این ماده اولیه در محصول {product['name']} استفاده شده و قابل حذف نیست"
        
        # Check if this material has any transaction history
        cursor.execute("SELECT * FROM transactions WHERE item=?", (material['name'],))
        if cursor.fetchone():
            # Update material name in transactions to indicate it was deleted
            cursor.execute(
                "UPDATE transactions SET item=? WHERE item=?", 
                (f"[حذف شده] {material['name']}", material['name'])
            )
        
        # Delete the material
        cursor.execute("DELETE FROM raw_materials WHERE id=?", (id,))
        
        # Add a deletion transaction record
        add_transaction("حذف", material['name'], -material['quantity'], 0, "حذف ماده اولیه")
        
        conn.commit()
        conn.close()
        return True, "ماده اولیه با موفقیت حذف شد"
    except Exception as e:
        return False, f"خطا در حذف ماده اولیه: {str(e)}"

# تابع دریافت لیست تمام مواد اولیه
def get_all_raw_materials():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM raw_materials ORDER BY name")
    results = cursor.fetchall()
    conn.close()
    return results

# تابع دریافت اطلاعات یک ماده اولیه
def get_raw_material(name=None, id=None):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    if id:
        cursor.execute("SELECT * FROM raw_materials WHERE id=?", (id,))
    elif name:
        cursor.execute("SELECT * FROM raw_materials WHERE name=?", (name,))
    else:
        conn.close()
        return None
        
    result = cursor.fetchone()
    conn.close()
    return result

# تابع افزودن محصول جدید
def add_product(name, materials):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute(
            "INSERT INTO products (name, materials) VALUES (?, ?)",
            (name, materials)
        )
        conn.commit()
        conn.close()
        return True, "محصول با موفقیت ثبت شد"
    except sqlite3.IntegrityError:
        return False, "نام محصول تکراری است"
    except Exception as e:
        return False, f"خطا در افزودن محصول: {str(e)}"

# تابع ویرایش محصول
def edit_product(id, name, materials):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if product exists
        cursor.execute("SELECT * FROM products WHERE id=?", (id,))
        current = cursor.fetchone()
        
        if not current:
            conn.close()
            return False, "محصول یافت نشد"
        
        # Check if name is being changed and is unique
        if current['name'] != name:
            cursor.execute("SELECT id FROM products WHERE name=? AND id!=?", (name, id))
            if cursor.fetchone():
                conn.close()
                return False, "نام محصول تکراری است"
        
        # Validate materials format
        try:
            materials_list = materials.split(',')
            for material_str in materials_list:
                parts = material_str.strip().split(':')
                if len(parts) != 2:
                    return False, "فرمت مواد اولیه صحیح نیست"
                
                material_name = parts[0].strip()
                material_qty = float(parts[1].strip())
                
                # Check if material exists
                cursor.execute("SELECT * FROM raw_materials WHERE name=?", (material_name,))
                if not cursor.fetchone():
                    conn.close()
                    return False, f"ماده اولیه {material_name} وجود ندارد"
        except ValueError:
            conn.close()
            return False, "مقدار مواد باید عددی باشد"
        
        # Update the product
        cursor.execute(
            "UPDATE products SET name=?, materials=? WHERE id=?",
            (name, materials, id)
        )
        
        # Update product name in production items if changed
        if current['name'] != name:
            cursor.execute(
                "UPDATE transactions SET item=? WHERE item=? AND type='تولید'",
                (name, current['name'])
            )
        
        conn.commit()
        conn.close()
        return True, "محصول با موفقیت ویرایش شد"
    except Exception as e:
        return False, f"خطا در ویرایش محصول: {str(e)}"

# تابع حذف محصول
def delete_product(id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if product exists
        cursor.execute("SELECT * FROM products WHERE id=?", (id,))
        product = cursor.fetchone()
        
        if not product:
            conn.close()
            return False, "محصول یافت نشد"
        
        # Check if product is used in any production transaction
        cursor.execute("SELECT * FROM transactions WHERE type='تولید' AND item=?", (product['name'],))
        if cursor.fetchone():
            # Update product name in transactions to indicate it was deleted
            cursor.execute(
                "UPDATE transactions SET item=? WHERE item=? AND type='تولید'", 
                (f"[حذف شده] {product['name']}", product['name'])
            )
        
        # Check if product is in production
        cursor.execute("SELECT * FROM in_production_items WHERE product_id=?", (id,))
        if cursor.fetchone():
            # Update in_production_items status to indicate product was deleted
            cursor.execute(
                "UPDATE in_production_items SET status=? WHERE product_id=?", 
                ("محصول حذف شده", id)
            )
        
        # Delete the product
        cursor.execute("DELETE FROM products WHERE id=?", (id,))
        conn.commit()
        conn.close()
        return True, "محصول با موفقیت حذف شد"
    except Exception as e:
        return False, f"خطا در حذف محصول: {str(e)}"

# تابع دریافت لیست تمام محصولات
def get_all_products():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM products ORDER BY name")
    results = cursor.fetchall()
    conn.close()
    return results

# تابع دریافت اطلاعات یک محصول
def get_product(name=None, id=None):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    if id:
        cursor.execute("SELECT * FROM products WHERE id=?", (id,))
    elif name:
        cursor.execute("SELECT * FROM products WHERE name=?", (name,))
    else:
        conn.close()
        return None
        
    result = cursor.fetchone()
    conn.close()
    return result

# تابع ثبت تراکنش جدید
def add_transaction(trans_type, item, change, remaining, notes=""):
    date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute(
            "INSERT INTO transactions (date, type, item, change, remaining, notes) VALUES (?, ?, ?, ?, ?, ?)",
            (date, trans_type, item, change, remaining, notes)
        )
        conn.commit()
        conn.close()
        return True, "تراکنش با موفقیت ثبت شد"
    except Exception as e:
        return False, f"خطا در ثبت تراکنش: {str(e)}"

# تابع دریافت لیست تمام تراکنش‌ها
def get_all_transactions():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM transactions ORDER BY date DESC")
    results = cursor.fetchall()
    conn.close()
    return results

# تابع تولید محصول
def produce_product(product_id, quantity, notes=""):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if product exists
        cursor.execute("SELECT * FROM products WHERE id=?", (product_id,))
        product = cursor.fetchone()
        
        if not product:
            conn.close()
            return False, "محصول یافت نشد"
        
        # Parse materials list
        materials_list = product['materials'].split(',')
        materials_dict = {}
        
        for material_str in materials_list:
            parts = material_str.strip().split(':')
            if len(parts) != 2:
                conn.close()
                return False, "فرمت مواد اولیه صحیح نیست"
            
            material_name = parts[0].strip()
            material_qty = float(parts[1].strip())
            materials_dict[material_name] = material_qty * quantity
        
        # Check if enough materials are available
        for material, required_qty in materials_dict.items():
            cursor.execute("SELECT quantity FROM raw_materials WHERE name=?", (material,))
            result = cursor.fetchone()
            
            if not result:
                conn.close()
                return False, f"ماده اولیه {material} یافت نشد"
            
            if float(result['quantity']) < required_qty:
                conn.close()
                return False, f"موجودی {material} کافی نیست"
        
        # Subtract materials
        for material, required_qty in materials_dict.items():
            update_raw_material(material, -required_qty, f"استفاده در تولید محصول {product['name']}")
        
        # Record production transaction
        add_transaction("تولید", product['name'], quantity, quantity, notes)
        
        conn.close()
        return True, "محصول با موفقیت تولید شد"
    except Exception as e:
        return False, f"خطا در تولید محصول: {str(e)}"

# تابع افزودن قطعه در حال تولید
def add_in_production(product_id, quantity, start_date, estimated_completion_date, notes=""):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Set initial status based on estimated_completion_date
        initial_status = 'تکمیل شده' if not estimated_completion_date else 'در حال تولید'
        
        cursor.execute(
            "INSERT INTO in_production_items (product_id, quantity, start_date, estimated_completion_date, status, notes) VALUES (?, ?, ?, ?, ?, ?)",
            (product_id, quantity, start_date, estimated_completion_date, initial_status, notes)
        )
        
        # Get the ID of the newly inserted row
        production_id = cursor.lastrowid
        
        conn.commit()
        
        # Get product name for transaction record
        cursor.execute("SELECT name FROM products WHERE id=?", (product_id,))
        product = cursor.fetchone()
        
        # Record transaction
        status_text = "تکمیل تولید" if initial_status == "تکمیل شده" else "شروع تولید"
        add_transaction(status_text, product['name'], quantity, quantity, f"{status_text} {quantity} عدد {product['name']}")
        
        # If it's added as completed (no estimated completion date), reduce raw materials immediately
        if initial_status == "تکمیل شده":
            # Get product details to find materials
            cursor.execute("""
                SELECT pm.raw_material_id, pm.quantity, rm.name, rm.quantity as current_quantity
                FROM product_materials pm
                JOIN raw_materials rm ON pm.raw_material_id = rm.id
                WHERE pm.product_id = ?
            """, (product_id,))
            
            materials = cursor.fetchall()
            
            # Reduce raw materials quantities
            for material in materials:
                material_id = material['raw_material_id']
                needed_quantity = material['quantity'] * quantity  # Material per product * number of products
                current_quantity = material['current_quantity']
                new_quantity = max(0, current_quantity - needed_quantity)  # Don't go below 0
                
                # Update raw material quantity
                cursor.execute(
                    "UPDATE raw_materials SET quantity = ? WHERE id = ?",
                    (new_quantity, material_id)
                )
                
                # Record transaction for material reduction
                add_transaction(
                    "مصرف ماده اولیه", 
                    material['name'], 
                    -needed_quantity, 
                    new_quantity, 
                    f"استفاده در تولید {quantity} عدد {product['name']}"
                )
            
            conn.commit()
        
        conn.close()
        return True, "قطعه به لیست تولید اضافه شد", production_id
    except Exception as e:
        return False, f"خطا در افزودن قطعه به لیست تولید: {str(e)}", None

# تابع دریافت لیست تمام قطعات در حال تولید
def get_all_in_production():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT i.*, p.name as product_name 
        FROM in_production_items i 
        JOIN products p ON i.product_id = p.id
        ORDER BY i.start_date DESC
    """)
    results = cursor.fetchall()
    conn.close()
    return results

# تابع تغییر وضعیت قطعه در حال تولید
def update_in_production_status(id, status, notes=None):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get current data
        cursor.execute("""
            SELECT i.*, p.name as product_name 
            FROM in_production_items i 
            JOIN products p ON i.product_id = p.id
            WHERE i.id=?
        """, (id,))
        item = cursor.fetchone()
        
        if not item:
            conn.close()
            return False, "قطعه در حال تولید یافت نشد"
        
        # Update notes if provided
        if notes:
            cursor.execute(
                "UPDATE in_production_items SET status=?, notes=? WHERE id=?",
                (status, notes, id)
            )
        else:
            cursor.execute(
                "UPDATE in_production_items SET status=? WHERE id=?",
                (status, id)
            )
        
        conn.commit()
        
        # If status changed to 'تکمیل شده', do these tasks:
        if status == "تکمیل شده":
            # 1. Record transaction for completing production
            add_transaction("تکمیل تولید", item['product_name'], item['quantity'], item['quantity'], f"تکمیل تولید {item['quantity']} عدد {item['product_name']}")
            
            # 2. Get product details to find materials
            cursor.execute("""
                SELECT pm.raw_material_id, pm.quantity, rm.name, rm.quantity as current_quantity
                FROM product_materials pm
                JOIN raw_materials rm ON pm.raw_material_id = rm.id
                WHERE pm.product_id = ?
            """, (item['product_id'],))
            
            materials = cursor.fetchall()
            
            # 3. Reduce raw materials quantities
            for material in materials:
                material_id = material['raw_material_id']
                needed_quantity = material['quantity'] * item['quantity']  # Material per product * number of products
                current_quantity = material['current_quantity']
                new_quantity = max(0, current_quantity - needed_quantity)  # Don't go below 0
                
                # Update raw material quantity
                cursor.execute(
                    "UPDATE raw_materials SET quantity = ? WHERE id = ?",
                    (new_quantity, material_id)
                )
                
                # Record transaction for material reduction
                add_transaction(
                    "مصرف ماده اولیه", 
                    material['name'], 
                    -needed_quantity, 
                    new_quantity, 
                    f"استفاده در تولید {item['quantity']} عدد {item['product_name']}"
                )
            
            conn.commit()
        
        conn.close()
        return True, "وضعیت قطعه در حال تولید به‌روز شد"
    except Exception as e:
        return False, f"خطا در به‌روزرسانی وضعیت: {str(e)}"

# تابع حذف قطعه از لیست در حال تولید
def delete_in_production(id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get data for transaction record
        cursor.execute("""
            SELECT i.*, p.name as product_name 
            FROM in_production_items i 
            JOIN products p ON i.product_id = p.id
            WHERE i.id=?
        """, (id,))
        item = cursor.fetchone()
        
        if not item:
            conn.close()
            return False, "قطعه در حال تولید یافت نشد"
        
        # Delete the item
        cursor.execute("DELETE FROM in_production_items WHERE id=?", (id,))
        conn.commit()
        
        # Record cancellation transaction
        add_transaction("لغو تولید", item['product_name'], -item['quantity'], 0, f"لغو تولید {item['quantity']} عدد {item['product_name']}")
        
        conn.close()
        return True, "قطعه از لیست در حال تولید حذف شد"
    except Exception as e:
        return False, f"خطا در حذف قطعه از لیست تولید: {str(e)}"

# تابع تحلیل داده‌ها برای داشبورد
def get_dashboard_data():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Total raw materials
    cursor.execute("SELECT COUNT(*) as count FROM raw_materials")
    raw_materials_count = cursor.fetchone()['count']
    
    # Total products
    cursor.execute("SELECT COUNT(*) as count FROM products")
    products_count = cursor.fetchone()['count']
    
    # Items in production
    cursor.execute("SELECT COUNT(*) as count FROM in_production_items WHERE status='در حال تولید'")
    in_production_count = cursor.fetchone()['count']
    
    # Recent transactions
    cursor.execute("SELECT * FROM transactions ORDER BY date DESC LIMIT 5")
    recent_transactions = cursor.fetchall()
    
    # Low inventory items (less than 10 units)
    cursor.execute("SELECT * FROM raw_materials WHERE quantity < 10 ORDER BY quantity ASC")
    low_inventory = cursor.fetchall()
    
    # Monthly transaction statistics
    cursor.execute("""
        SELECT strftime('%Y-%m', date) as month, COUNT(*) as count
        FROM transactions
        GROUP BY month
        ORDER BY month DESC
        LIMIT 6
    """)
    monthly_stats = cursor.fetchall()
    
    # Convert to lists for easy plotting
    months = []
    counts = []
    for stat in monthly_stats:
        months.append(stat['month'])
        counts.append(stat['count'])
    
    # Reverse for chronological order
    months = months[::-1]
    counts = counts[::-1]
    
    conn.close()
    
    return {
        'raw_materials_count': raw_materials_count,
        'products_count': products_count,
        'in_production_count': in_production_count,
        'recent_transactions': recent_transactions,
        'low_inventory': low_inventory,
        'months': months,
        'counts': counts
    }

# تابع رسم نمودار موجودی مواد اولیه
def create_inventory_chart():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("SELECT name, quantity FROM raw_materials ORDER BY quantity DESC LIMIT 10")
    materials = cursor.fetchall()
    
    conn.close()
    
    if not materials:
        return None
    
    names = [m['name'] for m in materials]
    quantities = [m['quantity'] for m in materials]
    
    fig = go.Figure(data=[
        go.Bar(
            x=names,
            y=quantities,
            marker_color='rgba(59, 130, 246, 0.7)',
            hoverinfo='y',
            textposition='auto',
            marker=dict(
                line=dict(
                    color='rgba(59, 130, 246, 1)',
                    width=1
                )
            )
        )
    ])
    
    fig.update_layout(
        title='موجودی مواد اولیه',
        xaxis_title='ماده اولیه',
        yaxis_title='موجودی',
        plot_bgcolor='rgba(245, 247, 252, 1)',
        paper_bgcolor='rgba(245, 247, 252, 1)',
        margin=dict(l=40, r=40, t=60, b=40),
        height=400,
        font=dict(
            family="Tahoma, Arial, sans-serif",
            size=14,
            color="#374151"
        )
    )
    
    return json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)

# تابع رسم نمودار تراکنش‌ها
def create_transactions_chart():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT strftime('%Y-%m', date) as month, type, COUNT(*) as count
        FROM transactions
        GROUP BY month, type
        ORDER BY month
        LIMIT 30
    """)
    
    data = cursor.fetchall()
    conn.close()
    
    if not data:
        return None
    
    # Convert to pandas DataFrame for easier manipulation
    df = pd.DataFrame([dict(d) for d in data])
    
    # Pivot to get types as columns
    pivot_df = pd.pivot_table(df, values='count', index=['month'], columns=['type'], aggfunc='sum')
    
    # Replace NaN with 0
    pivot_df = pivot_df.fillna(0)
    
    # Create the figure
    fig = go.Figure()
    
    # Add trace for each transaction type
    colors = {
        'ورود': 'rgba(16, 185, 129, 0.7)',
        'خروج': 'rgba(239, 68, 68, 0.7)',
        'تولید': 'rgba(59, 130, 246, 0.7)',
        'شروع تولید': 'rgba(139, 92, 246, 0.7)',
        'تکمیل تولید': 'rgba(245, 158, 11, 0.7)',
        'لغو تولید': 'rgba(107, 114, 128, 0.7)',
        'حذف': 'rgba(107, 114, 128, 0.7)'
    }
    
    for col in pivot_df.columns:
        fig.add_trace(go.Bar(
            x=pivot_df.index,
            y=pivot_df[col],
            name=col,
            marker_color=colors.get(col, 'rgba(107, 114, 128, 0.7)')
        ))
    
    fig.update_layout(
        title='تراکنش‌ها بر اساس ماه',
        xaxis_title='ماه',
        yaxis_title='تعداد تراکنش',
        barmode='stack',
        plot_bgcolor='rgba(245, 247, 252, 1)',
        paper_bgcolor='rgba(245, 247, 252, 1)',
        margin=dict(l=40, r=40, t=60, b=40),
        height=400,
        font=dict(
            family="Tahoma, Arial, sans-serif",
            size=14,
            color="#374151"
        ),
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="right",
            x=1
        )
    )
    
    return json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)

# تابع رسم نمودار پیشرفت تولید
def create_production_progress_chart():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT status, COUNT(*) as count 
        FROM in_production_items 
        GROUP BY status
    """)
    
    data = cursor.fetchall()
    conn.close()
    
    if not data:
        return None
    
    labels = [d['status'] for d in data]
    values = [d['count'] for d in data]
    
    # Color map for different statuses
    colors = {
        'در حال تولید': 'rgba(59, 130, 246, 0.8)',
        'تکمیل شده': 'rgba(16, 185, 129, 0.8)',
        'متوقف شده': 'rgba(239, 68, 68, 0.8)',
        'محصول حذف شده': 'rgba(107, 114, 128, 0.8)'
    }
    
    color_values = [colors.get(label, 'rgba(107, 114, 128, 0.8)') for label in labels]
    
    fig = go.Figure(data=[go.Pie(
        labels=labels,
        values=values,
        hole=.4,
        textinfo='label+percent',
        marker=dict(colors=color_values)
    )])
    
    fig.update_layout(
        title='وضعیت قطعات در حال تولید',
        plot_bgcolor='rgba(245, 247, 252, 1)',
        paper_bgcolor='rgba(245, 247, 252, 1)',
        margin=dict(l=40, r=40, t=60, b=40),
        height=400,
        font=dict(
            family="Tahoma, Arial, sans-serif",
            size=14,
            color="#374151"
        )
    )
    
    return json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)

# تابع صادرات داده‌ها به CSV
def export_data_to_csv(table_name):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get all data from the requested table
        cursor.execute(f"SELECT * FROM {table_name}")
        data = cursor.fetchall()
        
        if not data:
            conn.close()
            return False, "داده‌ای برای صادرات وجود ندارد", None
        
        # Create a CSV in memory
        si = io.StringIO()
        writer = csv.writer(si)
        
        # Write header
        header = [description[0] for description in cursor.description]
        writer.writerow(header)
        
        # Write data
        for row in data:
            writer.writerow(dict(row).values())
        
        output = si.getvalue()
        
        conn.close()
        
        filename = f"{table_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        
        return True, "داده‌ها با موفقیت به CSV تبدیل شدند", (output, filename)
    except Exception as e:
        return False, f"خطا در صادرات داده‌ها: {str(e)}", None

# تابع دریافت آمار مواد اولیه برای نمایش سه‌بعدی
def get_materials_for_3d():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("SELECT name, quantity, unit FROM raw_materials ORDER BY quantity DESC")
    materials = cursor.fetchall()
    
    conn.close()
    
    return [dict(m) for m in materials]

# Routes - Flask routing functions

@app.route('/')
def index():
    dashboard_data = get_dashboard_data()
    inventory_chart = create_inventory_chart()
    transactions_chart = create_transactions_chart()
    production_chart = create_production_progress_chart()
    
    return render_template(
        'index.html',
        dashboard_data=dashboard_data,
        inventory_chart=inventory_chart,
        transactions_chart=transactions_chart,
        production_chart=production_chart
    )

@app.route('/dashboard')
def dashboard():
    dashboard_data = get_dashboard_data()
    inventory_chart = create_inventory_chart()
    transactions_chart = create_transactions_chart()
    production_chart = create_production_progress_chart()
    
    return render_template(
        'dashboard.html',
        dashboard_data=dashboard_data,
        inventory_chart=inventory_chart,
        transactions_chart=transactions_chart,
        production_chart=production_chart
    )

@app.route('/raw_materials')
def raw_materials():
    materials = get_all_raw_materials()
    return render_template('raw_materials.html', materials=materials)

@app.route('/raw_materials/add', methods=['POST'])
def add_raw_material_route():
    name = request.form.get('name')
    quantity = request.form.get('quantity')
    unit = request.form.get('unit')
    
    if not name or not quantity or not unit:
        flash('لطفاً تمام فیلدها را پر کنید', 'danger')
        return redirect(url_for('raw_materials'))
    
    try:
        quantity = float(quantity)
        if quantity < 0:
            flash('مقدار باید بزرگتر یا مساوی صفر باشد', 'danger')
            return redirect(url_for('raw_materials'))
    except ValueError:
        flash('مقدار باید عددی باشد', 'danger')
        return redirect(url_for('raw_materials'))
    
    success, message = add_raw_material(name, quantity, unit)
    
    if success:
        flash(message, 'success')
    else:
        flash(message, 'danger')
    
    return redirect(url_for('raw_materials'))

@app.route('/raw_materials/edit/<int:id>', methods=['POST'])
def edit_raw_material_route(id):
    name = request.form.get('name')
    quantity = request.form.get('quantity')
    unit = request.form.get('unit')
    
    if not name or not quantity or not unit:
        flash('لطفاً تمام فیلدها را پر کنید', 'danger')
        return redirect(url_for('raw_materials'))
    
    try:
        quantity = float(quantity)
        if quantity < 0:
            flash('مقدار باید بزرگتر یا مساوی صفر باشد', 'danger')
            return redirect(url_for('raw_materials'))
    except ValueError:
        flash('مقدار باید عددی باشد', 'danger')
        return redirect(url_for('raw_materials'))
    
    success, message = edit_raw_material(id, name, quantity, unit)
    
    if success:
        flash(message, 'success')
    else:
        flash(message, 'danger')
    
    return redirect(url_for('raw_materials'))

@app.route('/raw_materials/update', methods=['POST'])
def update_raw_material_route():
    name = request.form.get('name')
    quantity_change = request.form.get('quantity_change')
    note = request.form.get('note', '')
    
    if not name or not quantity_change:
        flash('لطفاً نام و مقدار تغییر را وارد کنید', 'danger')
        return redirect(url_for('raw_materials'))
    
    try:
        quantity_change = float(quantity_change)
    except ValueError:
        flash('مقدار تغییر باید عددی باشد', 'danger')
        return redirect(url_for('raw_materials'))
    
    success, message = update_raw_material(name, quantity_change, note)
    
    if success:
        flash(message, 'success')
    else:
        flash(message, 'danger')
    
    return redirect(url_for('raw_materials'))

@app.route('/raw_materials/delete/<int:id>')
def delete_raw_material_route(id):
    success, message = delete_raw_material(id)
    
    if success:
        flash(message, 'success')
    else:
        flash(message, 'danger')
    
    return redirect(url_for('raw_materials'))

@app.route('/raw_materials/get/<int:id>')
def get_raw_material_route(id):
    material = get_raw_material(id=id)
    
    if material:
        return jsonify(dict(material))
    else:
        return jsonify({'error': 'ماده اولیه یافت نشد'}), 404

@app.route('/products')
def products():
    products_list = get_all_products()
    raw_materials = get_all_raw_materials()
    return render_template('products.html', products=products_list, raw_materials=raw_materials)

@app.route('/products/add', methods=['POST'])
def add_product_route():
    name = request.form.get('name')
    materials = request.form.get('materials')
    
    if not name or not materials:
        flash('لطفاً تمام فیلدها را پر کنید', 'danger')
        return redirect(url_for('products'))
    
    success, message = add_product(name, materials)
    
    if success:
        flash(message, 'success')
    else:
        flash(message, 'danger')
    
    return redirect(url_for('products'))

@app.route('/products/edit/<int:id>', methods=['POST'])
def edit_product_route(id):
    name = request.form.get('name')
    materials = request.form.get('materials')
    
    if not name or not materials:
        flash('لطفاً تمام فیلدها را پر کنید', 'danger')
        return redirect(url_for('products'))
    
    success, message = edit_product(id, name, materials)
    
    if success:
        flash(message, 'success')
    else:
        flash(message, 'danger')
    
    return redirect(url_for('products'))

@app.route('/products/delete/<int:id>')
def delete_product_route(id):
    success, message = delete_product(id)
    
    if success:
        flash(message, 'success')
    else:
        flash(message, 'danger')
    
    return redirect(url_for('products'))

@app.route('/products/get/<int:id>')
def get_product_route(id):
    product = get_product(id=id)
    
    if product:
        return jsonify(dict(product))
    else:
        return jsonify({'error': 'محصول یافت نشد'}), 404

@app.route('/products/produce', methods=['POST'])
def produce_product_route():
    product_id = request.form.get('product_id')
    quantity = request.form.get('quantity')
    notes = request.form.get('notes', '')
    
    if not product_id or not quantity:
        flash('لطفاً محصول و تعداد را وارد کنید', 'danger')
        return redirect(url_for('products'))
    
    try:
        product_id = int(product_id)
        quantity = int(quantity)
        
        if quantity <= 0:
            flash('تعداد باید بزرگتر از صفر باشد', 'danger')
            return redirect(url_for('products'))
    except ValueError:
        flash('تعداد باید عدد صحیح باشد', 'danger')
        return redirect(url_for('products'))
    
    success, message = produce_product(product_id, quantity, notes)
    
    if success:
        flash(message, 'success')
    else:
        flash(message, 'danger')
    
    return redirect(url_for('products'))

@app.route('/transactions')
def transactions():
    transactions_list = get_all_transactions()
    return render_template('transactions.html', transactions=transactions_list)

@app.route('/production')
def production():
    # Filter production items by status
    all_production_items = get_all_in_production()
    
    # If estimated_completion_date is empty, consider it as completed
    in_progress_items = []
    completed_items = []
    other_items = []
    
    for item in all_production_items:
        # Convert sqlite3.Row to dict for manipulation
        item_dict = dict(item)
        
        if item_dict['status'] == 'تکمیل شده' or not item_dict['estimated_completion_date']:
            # Items with status 'completed' or without estimated date are considered completed
            if item_dict['status'] != 'تکمیل شده':
                # Update status in database if it's not already marked as completed
                update_in_production_status(item_dict['id'], 'تکمیل شده', "تکمیل شده بر اساس تاریخ تخمینی خالی")
                item_dict['status'] = 'تکمیل شده'  # Update status in memory
            completed_items.append(item_dict)
        elif item_dict['status'] == 'در حال تولید':
            in_progress_items.append(item_dict)
        else:
            other_items.append(item_dict)
    
    products_list = get_all_products()
    today = date.today().strftime('%Y-%m-%d')
    
    return render_template('production.html', 
                           in_progress_items=in_progress_items,
                           completed_items=completed_items, 
                           other_items=other_items,
                           products=products_list, 
                           today=today)

@app.route('/production/add', methods=['POST'])
def add_in_production_route():
    product_id = request.form.get('product_id')
    quantity = request.form.get('quantity')
    start_date = request.form.get('start_date')
    estimated_completion_date = request.form.get('estimated_completion_date')
    notes = request.form.get('notes', '')
    
    if not product_id or not quantity or not start_date:
        flash('لطفاً فیلدهای اجباری را پر کنید', 'danger')
        return redirect(url_for('production'))
    
    try:
        product_id = int(product_id)
        quantity = int(quantity)
        
        # Set initial status based on estimated_completion_date
        initial_status = 'تکمیل شده' if not estimated_completion_date else 'در حال تولید'
        
        if quantity <= 0:
            flash('تعداد باید بزرگتر از صفر باشد', 'danger')
            return redirect(url_for('production'))
    except ValueError:
        flash('تعداد باید عدد صحیح باشد', 'danger')
        return redirect(url_for('production'))
    
    # Add to production with appropriate status
    success, message, production_id = add_in_production(product_id, quantity, start_date, estimated_completion_date, notes)
    
    # If it should be completed and was successfully added, update the status
    if success and not estimated_completion_date:
        update_in_production_status(production_id, 'تکمیل شده', "تکمیل شده بر اساس تاریخ تخمینی خالی")
    
    if success:
        flash(message, 'success')
    else:
        flash(message, 'danger')
    
    return redirect(url_for('production'))

@app.route('/production/update_status/<int:id>', methods=['POST'])
def update_in_production_status_route(id):
    status = request.form.get('status')
    notes = request.form.get('notes')
    
    if not status:
        flash('لطفاً وضعیت را وارد کنید', 'danger')
        return redirect(url_for('production'))
    
    success, message = update_in_production_status(id, status, notes)
    
    if success:
        flash(message, 'success')
    else:
        flash(message, 'danger')
    
    return redirect(url_for('production'))

@app.route('/production/delete/<int:id>')
def delete_in_production_route(id):
    success, message = delete_in_production(id)
    
    if success:
        flash(message, 'success')
    else:
        flash(message, 'danger')
    
    return redirect(url_for('production'))

@app.route('/export/<table_name>')
def export_data(table_name):
    allowed_tables = ['raw_materials', 'products', 'transactions', 'in_production_items']
    
    # Special handling for filtered exports
    if table_name == 'in_production_items_in_progress':
        # Get in-progress items
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM in_production_items WHERE status='در حال تولید'")
        data = cursor.fetchall()
        conn.close()
        
        if not data:
            flash('هیچ داده‌ای برای دریافت وجود ندارد', 'warning')
            return redirect(url_for('production'))
            
        # Create CSV output
        output = io.StringIO()
        writer = csv.writer(output)
        
        # Write header
        header = list(data[0].keys())
        writer.writerow(header)
        
        # Write data rows
        for row in data:
            writer.writerow([row[column] for column in header])
            
        # Prepare response
        output.seek(0)
        
        response = make_response(output.getvalue())
        response.headers["Content-Disposition"] = f"attachment; filename=in_progress_production_items.csv"
        response.headers["Content-type"] = "text/csv; charset=utf-8"
        
        return response
        
    elif table_name == 'in_production_items_completed':
        # Get completed items
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM in_production_items WHERE status='تکمیل شده'")
        data = cursor.fetchall()
        conn.close()
        
        if not data:
            flash('هیچ داده‌ای برای دریافت وجود ندارد', 'warning')
            return redirect(url_for('production'))
            
        # Create CSV output
        output = io.StringIO()
        writer = csv.writer(output)
        
        # Write header
        header = list(data[0].keys())
        writer.writerow(header)
        
        # Write data rows
        for row in data:
            writer.writerow([row[column] for column in header])
            
        # Prepare response
        output.seek(0)
        
        response = make_response(output.getvalue())
        response.headers["Content-Disposition"] = f"attachment; filename=completed_production_items.csv"
        response.headers["Content-type"] = "text/csv; charset=utf-8"
        
        return response
    
    elif table_name not in allowed_tables:
        flash('جدول مورد نظر معتبر نیست', 'danger')
        return redirect(url_for('index'))
    
    success, message, data = export_data_to_csv(table_name)
    
    if success:
        output, filename = data
        response = make_response(output)
        response.headers["Content-Disposition"] = f"attachment; filename={filename}"
        response.headers["Content-type"] = "text/csv"
        return response
    else:
        flash(message, 'danger')
        return redirect(url_for('index'))

@app.route('/api/materials_for_3d')
def api_materials_for_3d():
    materials = get_materials_for_3d()
    return jsonify(materials)

# Create database tables if they don't exist
init_db()

# Uncomment if __name__ == "__main__": section if running directly
if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000, debug=True)
